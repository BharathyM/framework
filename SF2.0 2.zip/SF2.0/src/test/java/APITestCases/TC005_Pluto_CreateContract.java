package APITestCases;

import org.testng.annotations.BeforeTest;
import com.ms.ui.RestAssuredBase.RESTAssuredBase;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import com.ms.ui.RestAssuredBase.RESTAssuredBase;

public class TC005_Pluto_CreateContract extends RESTAssuredBase{
	
	static String plutoToken;
	
	 @BeforeTest
	    public void setValues() {
			
			
			  testCaseName = "Pluto Contract creation"; testDescription = "Post contract to downstream"; nodes =
			  "Pluto Contract creation"; authors = "Saveetha"; category = "API"; dataFileName = "";
			 
	    }
	 
	 	@Test
	 	public static void TokenForPluto(){

			Response withBodyURLENC = getTokenForPluto("http://10.230.0.64/mplutowebapi/token");
			int statusCode = withBodyURLENC.getStatusCode();
			JsonPath jsonPath = withBodyURLENC.jsonPath();
			String accessToken = jsonPath.get("access_token");
			System.out.println("Pluto Access token is" + accessToken );
			 plutoToken = "Bearer " +accessToken;
		}
	   
	    @Test
			    public void UpdateSFQuoteLineDetails() {
	    	        
	    	       
	    	
	    			File file = new File(".//src/test/testdata/Pluto_UpdateSFQuoteLineDetails.json");
			        Map<String, String> headers = new HashMap<String, String>();
			        RestAssured.useRelaxedHTTPSValidation();
			        headers.put("accept", "application/json");
			        headers.put("Content-Type", "application/json");
			        headers.put("Authorization", plutoToken);
			        Response response = postWithBodyAndHeaderParam(headers, file, "http://10.230.0.64/mplutowebapi/SFPlutoContract/UpdateSFQuoteLineDetails");
			        reportRequest(" The response " + response.prettyPrint(), "INFO");
			        int statusCode = response.getStatusCode();
			        System.out.println(statusCode);
			        verifyResponseCode(response, 200);
			        
			    }
	    
	    @Test
	    public void SendQuoteDetails() {
	        
	       
	
			File file = new File(".//src/test/testdata/Pluto_SendQuoteDetails.json");
	        Map<String, String> headers = new HashMap<String, String>();
	        RestAssured.useRelaxedHTTPSValidation();
	        headers.put("accept", "application/json");
	        headers.put("Content-Type", "application/json");
	        headers.put("Authorization", plutoToken);
	        Response response = postWithBodyAndHeaderParam(headers, file, "http://10.230.0.64/mplutowebapi/SFPlutoContract/SendQuoteDetails");
	        reportRequest(" The response " + response.prettyPrint(), "INFO");
	        int statusCode = response.getStatusCode();
	        System.out.println(statusCode);
	        verifyResponseCode(response, 200);
	        
	    }

			}


