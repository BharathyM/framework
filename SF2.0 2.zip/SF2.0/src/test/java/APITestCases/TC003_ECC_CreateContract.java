package APITestCases;

import org.testng.annotations.BeforeTest;
import com.ms.ui.RestAssuredBase.RESTAssuredBase;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import com.ms.ui.RestAssuredBase.RESTAssuredBase;

public class TC003_ECC_CreateContract extends RESTAssuredBase{
	
	 @BeforeTest
	    public void setValues() {
			
			
			  testCaseName = "ECC Contract creation"; testDescription = "Post contract to downstream"; nodes =
			  "ECC Contract creation"; authors = "Saveetha"; category = "API"; dataFileName = "";
			 
	    }
	 
	   
	    @Test
			    public void createcontract() {
	    	        
	    	
	    			File file = new File(".//src/test/testdata/PostContractECC.json");
			        Map<String, String> headers = new HashMap<String, String>();
			        RestAssured.useRelaxedHTTPSValidation();
			        headers.put("accept", "application/json");
			        headers.put("Content-Type", "application/xml");
			        headers.put("Authorization", TOKEN);
			        Response response = postWithBodyAndHeaderParam(headers, file, "/ofi/Salesforce_Contract_Creation");
			        reportRequest(" The response " + response.prettyPrint(), "INFO");
			        int statusCode = response.getStatusCode();
			        System.out.println(statusCode);
			        verifyResponseCode(response, 200);
			        
			    }

			}


