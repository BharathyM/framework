package APITestCases;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.annotations.BeforeTest;

import com.ms.ui.RestAssuredBase.RESTAssuredBase;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.Test;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class TC004_NegativeScenarios extends RESTAssuredBase{
	
	Object obj;
	JSONObject jObject;
	
	 @BeforeTest
	    public void setValues() {
			
			  testCaseName = "NegativeScenario"; testDescription = "Post invalid division and company data to downstream"; nodes =
			  "Negative Scenario"; authors = "Saveetha"; category = "API"; dataFileName = "";
	    }
	 
	 public void jsonParser() throws IOException, ParseException {
		 
		    FileReader filereader = new FileReader(".//src/test/testdata/NegativeScenario.json");
		    JSONParser parser= new JSONParser();
			 obj = parser.parse(filereader);
		     jObject  = (JSONObject)obj;
	 }

	 @Test
			public void invalidDivisionField() throws IOException, ParseException {
		 
		    jsonParser();
		    JSONObject OPPORTUNITY_RECORDS = (JSONObject) jObject.get("OPPORTUNITY_RECORDS");
		    JSONObject CONTRACT_REQUEST = (JSONObject) OPPORTUNITY_RECORDS.get("CONTRACT_REQUEST");
		    JSONObject HEADER = (JSONObject) CONTRACT_REQUEST.get("HEADER");
		   	HEADER.replace("DIVISION", "0000");
		    String DIVISION = HEADER.get("DIVISION").toString();
		    String jsonObjectAsString  = obj.toString();
		    System.out.println(DIVISION);
		   	
		   	File file = new File(".//src/test/testdata/NegativeScenarios.json");
		   	Map<String, String> headers = new HashMap<String, String>();
	        RestAssured.useRelaxedHTTPSValidation();
	        headers.put("accept", "application/json");
	        headers.put("Content-Type", "application/xml");
	        headers.put("Authorization", TOKEN);
	        Response response = postWithHeaderAndJsonBody(headers, jsonObjectAsString, "/ofi/Salesforce_Contract_Creation");
	        reportRequest(" The response " + response.prettyPrint(), "INFO");
	        int statusCode = response.getStatusCode();
	        System.out.println(statusCode);
	        verifyResponseCode(response, 500);
		    
			}
	   
	 @Test
		public void invalidCompanyField() throws IOException, ParseException {
		 
		 
			jsonParser();
		    JSONObject OPPORTUNITY_RECORDS = (JSONObject) jObject.get("OPPORTUNITY_RECORDS");
		    JSONObject CONTRACT_REQUEST = (JSONObject) OPPORTUNITY_RECORDS.get("CONTRACT_REQUEST");
		    JSONObject HEADER = (JSONObject) CONTRACT_REQUEST.get("HEADER");
		   	HEADER.replace("COMPANY", "A123");
		    String COMPANY = HEADER.get("COMPANY").toString();
		    String jsonObjectAsString  = obj.toString();
		    System.out.println(COMPANY);
		   	
		 File file = new File(".//src/test/testdata/NegativeScenarios.json");
		 Map<String, String> headers = new HashMap<String, String>();
	     RestAssured.useRelaxedHTTPSValidation();
	     headers.put("accept", "application/json");
	     headers.put("Content-Type", "application/xml");
	     headers.put("Authorization", TOKEN);
	     Response response = postWithHeaderAndJsonBody(headers, jsonObjectAsString, "/ofi/Salesforce_Contract_Creation");
	     reportRequest(" The response " + response.prettyPrint(), "INFO");
	     int statusCode = response.getStatusCode();
	     System.out.println(statusCode);
	     verifyResponseCode(response, 500);
	    
		}
 }
 
	 

