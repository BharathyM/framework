package APITestCases;

import org.testng.annotations.BeforeTest;
import com.ms.ui.RestAssuredBase.RESTAssuredBase;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.io.File;
import java.util.HashMap;
import java.util.Map;


public class TC001_SKORE_CreateContract extends RESTAssuredBase{
	
	 @BeforeTest
	    public void setValues() {
			
			
			  testCaseName = "SKORE Contract creation"; testDescription = "Post contract to downstream SKORE"; nodes =
			  "SKORE contract creation"; authors = "Saveetha"; category = "API"; dataFileName = "";
			 
	    }
	 
	   
	    @Test
	 public void createcontractScore() {
	    	        
	    	
	    			File file = new File(".//src/test/testdata/PostContractScore.json");
			        Map<String, String> headers = new HashMap<String, String>();
			        RestAssured.useRelaxedHTTPSValidation();
			        headers.put("accept", "application/json");
			        headers.put("Content-Type", "application/xml");
			        headers.put("Authorization", TOKEN);
			        Response response = postWithBodyAndHeaderParam(headers, file, "/ofi/Salesforce_Contract_Creation");
			        reportRequest(" The response " + response.prettyPrint(), "INFO");
			        int statusCode = response.getStatusCode();
			        System.out.println(statusCode);
			        verifyResponseCode(response, 200);
			        
			    }
	    @Test
	    public void SCORE_SF_V7_D_Multiple_Success() {
	        
	
			File file = new File(".//src/test/testdata/SCORE_SF_PAYLOAD_V7_D_Multiple_Success.json");
	        Map<String, String> headers = new HashMap<String, String>();
	        RestAssured.useRelaxedHTTPSValidation();
	        headers.put("accept", "application/json");
	        headers.put("Content-Type", "application/xml");
	        headers.put("Authorization", TOKEN);
	        Response response = postWithBodyAndHeaderParam(headers, file, "/ofi/Salesforce_Contract_Creation");
	        reportRequest(" The response " + response.prettyPrint(), "INFO");
	        int statusCode = response.getStatusCode();
	        System.out.println(statusCode);
	        verifyResponseCode(response, 200);
	        
	    }

	    @Test
	    public void SCORE_SF_V7_D_Single_Success() {
	        
	
			File file = new File(".//src/test/testdata/SCORE_SF_PAYLOAD_V7_D_Single_Success.json");
	        Map<String, String> headers = new HashMap<String, String>();
	        RestAssured.useRelaxedHTTPSValidation();
	        headers.put("accept", "application/json");
	        headers.put("Content-Type", "application/xml");
	        headers.put("Authorization", TOKEN);
	        Response response = postWithBodyAndHeaderParam(headers, file, "/ofi/Salesforce_Contract_Creation");
	        reportRequest(" The response " + response.prettyPrint(), "INFO");
	        int statusCode = response.getStatusCode();
	        System.out.println(statusCode);
	        verifyResponseCode(response, 200);
	        
	    }
	    
	    @Test
	    public void SCORE_SF_V7_F_Single_Success() {
	        
	    	
			File file = new File(".//src/test/testdata/SCORE_SF_PAYLOAD_V7_F_Single_Success.json");
	        Map<String, String> headers = new HashMap<String, String>();
	        RestAssured.useRelaxedHTTPSValidation();
	        headers.put("accept", "application/json");
	        headers.put("Content-Type", "application/xml");
	        headers.put("Authorization", TOKEN);
	        Response response = postWithBodyAndHeaderParam(headers, file, "/ofi/Salesforce_Contract_Creation");
	        reportRequest(" The response " + response.prettyPrint(), "INFO");
	        int statusCode = response.getStatusCode();
	        System.out.println(statusCode);
	        verifyResponseCode(response, 200);
	        
	    }

			}


