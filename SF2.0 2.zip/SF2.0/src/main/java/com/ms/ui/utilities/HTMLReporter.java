package com.ms.ui.utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.model.Media;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public abstract class HTMLReporter  {

    public static ExtentReports extent;
    public static ExtentTest svcTest;
    public ExtentTest testSuite, test;
    public String testCaseName, testDescription, nodes, authors, category;

    public void startReport() throws IOException {
        extent = new ExtentReports();
        ExtentSparkReporter spark = new ExtentSparkReporter("./reports/result-" + createFileName() + "Spark.html");
        extent.attachReporter(spark);
        spark.loadXMLConfig("./Config/extent-config.xml");
    }

    public ExtentTest startTestCase(String testCaseName, String testDescription) {
        testSuite = extent.createTest(testCaseName, testDescription);
        return testSuite;
    }

    public ExtentTest startTestModule(String nodes) {
        test = testSuite.createNode(nodes);
        return test;
    }

    public void endResult() {
        extent.flush();
    }

    public abstract long takeSnap();

    public void reportStep(String desc, String status, boolean bSnap) throws IOException {
        Media img = null;
        if (bSnap && !status.equalsIgnoreCase("INFO")) {
            long snapNumber = 100000L;
            snapNumber = takeSnap();
          MediaEntityBuilder.createScreenCaptureFromPath("./../reports/images/" + snapNumber + ".png").build();
        }

        if (status.equalsIgnoreCase("PASS")) {
            test.pass(desc);
        } else if (status.equalsIgnoreCase("FAIL")) {
            test.fail(desc);
            throw new RuntimeException();
        } else if (status.equalsIgnoreCase("WARNING")) {
            test.warning(desc);
        } else {
            test.info(desc);
        }
    }

    public void reportStep(String desc, String status) throws IOException {
        reportStep(desc, status, true);
    }

    public static void reportRequest(String desc, String status) {
        Media img = null;
        if (status.equalsIgnoreCase("PASS")) {
            svcTest.pass(desc);
        } else if (status.equalsIgnoreCase("FAIL")) {
            svcTest.fail(desc);
            throw new RuntimeException();
        } else if (status.equalsIgnoreCase("WARNING")) {
            svcTest.warning(desc);
        } else {
            svcTest.info(desc);
        }
    }

    public static String createFileName() {
        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
        return format.format(date);
    }
}
