package com.ms.ui.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

public class UserRegistration_CreateID extends UserRegistration_uploadDoc{

	public UserRegistration_CreateID(RemoteWebDriver getDriver) {
		super(getDriver);
		// TODO Auto-generated constructor stub
	}

}
