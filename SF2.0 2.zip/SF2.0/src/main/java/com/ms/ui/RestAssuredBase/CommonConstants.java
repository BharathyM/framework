package com.ms.ui.RestAssuredBase;

public final class CommonConstants {

    public static String BASEURI;
    public static Object clientId;
    public static Object userName;
    public static Object grantType = "password";
    public static Object password;
    public static Object scope = "offline_access";
    public static Object client_secret;
}
