package com.ms.ui.utilities;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.IOException;

public class ReadExcelData {
    public static Object[][] readData(String excelFileName) {
        try {
            XSSFWorkbook book = new XSSFWorkbook("C:\\Users\\bharathy.perumal\\IdeaProjects\\demo\\MS_WebUI_Automation-Multilingual\\src\\test\\testdata\\"+excelFileName+".xlsx");
            XSSFSheet sheet = book.getSheetAt(0);
            // Getting row count and column count for iteration
            int rowCount = sheet.getLastRowNum();
            int colCount = sheet.getRow(0).getLastCellNum();

            // Creating 2D array to return data to the @DataProvider
            Object[][] array = new Object[rowCount][colCount];

            // Iteration Part
            for (int i = 1; i <= rowCount; i++) {
                XSSFRow row = sheet.getRow(i);
                for (int j = 0; j < colCount; j++) {
                    XSSFCell cell = row.getCell(j);
                    String data = cell.getStringCellValue();
                    array[i-1][j] = data;
                }
            }
            book.close();
            return array;

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
