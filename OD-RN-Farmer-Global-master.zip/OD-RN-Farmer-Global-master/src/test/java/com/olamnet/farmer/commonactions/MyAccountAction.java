package com.olamnet.farmer.commonactions;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.stream.IntStream;

import org.openqa.selenium.Point;

import com.cucumber.listener.Reporter;
import com.olamnet.farmer.utilities.AppiumUtil;
import com.olamnet.farmer.utilities.AppiumServerTest;
import com.olamnet.farmer.utilities.BaseStepAction;
import com.olamnet.farmer.utilities.Constants;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.offset.PointOption;
import javafx.util.Pair;

@SuppressWarnings("restriction")
public class MyAccountAction extends BaseStepAction {

	AndroidDriver driver;
	public static MyAccountAction inst_MyAccountAction = null;
	private static Properties farmerProp = new Properties();

	public MyAccountAction(AndroidDriver driver) {
		this.driver = driver;
	}

	public static MyAccountAction getInstance() {
		if (inst_MyAccountAction == null)
			inst_MyAccountAction = new MyAccountAction(AppiumUtil.driver);
		return inst_MyAccountAction;
	}

	public static String backendFarmerId;
	public static Pair[] profileDetails;
	public static Map<String, String> personalDetails;
	public static ArrayList<String> addressDetails;

	public String getDisplayFarmerIdFromDB() {

		String displayFarmerId = "";

		try {
			farmerProp.load(ClassLoader.getSystemResource("farmer.properties").openStream());
			System.out.println("farmer id from properties file: " + farmerProp.getProperty("farmerId"));
			String farmerId = addChar(farmerProp.getProperty("farmerId"), '-', 4);
			displayFarmerId = getDatabaseUtil().getDisplayFarmerId(farmerId);
			System.out.println("disp farmer id from db: " + displayFarmerId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return displayFarmerId;
	}

	public String addChar(String str, char ch, int position) {
		StringBuilder sb = new StringBuilder(str);
		sb.insert(position, ch);
		return sb.toString();
	}

	public void verifyMyAccountDetails() {
				
		verifyPersonalDetails();
	//	verifyPhoneNo();
		verifyAddressDetails();
		verifyFLDetailsOfFarmer();
		//verifyBankAccountDetails();
		//verifyLanguage();
		//getActionItemsInstance().isDisplayedAction("Logout", getMyAccountRepoInstance().lnkLogout);
		//viewUploadedDocs();
		getActionItemsInstance().reportStepLog("Farmer details in My account is verified");
	}

	private void verifyPersonalDetails() {

		getActionItemsInstance().addLogWithScreenShot("View Profile Screen-1 ");
		//getActionItemsInstance().isDisplayedAction(getMyAccountRepoInstance().imgFarmer);		
		if(getMyAccountRepoInstance().profileImageView.isDisplayed()) 		{
			getActionItemsInstance().reportStepLog("Profile image is dispalyed");	
		}
		
	//	System.out.println("Gender in View Profile :"+getMyAccountRepoInstance().txtGenderView.getText());
//	System.out.println("GenderinDB :"+personalDetails.get("gender"));
		
	//	assertTrue(getMyAccountRepoInstance().txtGenderView.getText().equals(personalDetails.get("gender")));
		//	getActionItemsInstance().reportStepLog(getMyAccountRepoInstance().txtGenderView.getText()+"*****"+(personalDetails.get("gender")));	
			
			getActionItemsInstance().reportStepLog("Gender:: "+getMyAccountRepoInstance().txtGenderView.getText());
			
			
		//assertTrue(getMyAccountRepoInstance().txtFarmerNameView.getText().equals(personalDetails.get("farmerName")));
//	System.out.println(getMyAccountRepoInstance().txtFarmerNameView.getText()+" *****  "+ personalDetails.get("farmerName") );
		//getActionItemsInstance().reportStepLog(getMyAccountRepoInstance().txtFarmerNameView.getText()+" *****  "+ personalDetails.get("farmerName"));	

		getActionItemsInstance().reportStepLog("Full Name:: "+getMyAccountRepoInstance().txtFarmerNameView.getText());
		//assertTrue(getMyAccountRepoInstance().txtDOBview.getText()
			//	.equals(getActionItemsInstance().epochToDate(personalDetails.get("dateOfBirth"))));
		
	//	assertTrue(
			//	getMyAccountRepoInstance().txtPhonenumberview.getText().replaceAll("\\s", "")
						//.equals(personalDetails.get("phoneNo")),
			//	"Phone no in app: " + getMyAccountRepoInstance().txtPhonenumberview.getText().replaceAll("\\s", "")
					//	+ " Phone no from api: " + personalDetails.get("phoneNo"));
		getActionItemsInstance().reportStepLog("Phone Number:: "+getMyAccountRepoInstance().txtPhonenumberview.getText());
		
		
		getActionItemsInstance().reportStepLog("Date of Birth:: "+getMyAccountRepoInstance().txtDOBview.getText());
		
	//	assertTrue(getMyAccountRepoInstance().txtEmailView.getText().equals(personalDetails.get("email")));
	//	getActionItemsInstance().reportStepLog(getMyAccountRepoInstance().txtEmailView.getText()+"*****"+(personalDetails.get("email")));
		
		getActionItemsInstance().reportStepLog("Email:: "+getMyAccountRepoInstance().txtEmailView.getText());
		getActionItemsInstance().addLogWithScreenShot("View profile screen-2");
		
		getActionItemsInstance().scrollDownViewByXpath("//*[@text='Unique ID']");
		
		//assertTrue(getMyAccountRepoInstance().txtUniqueIdView.getText().equals(personalDetails.get("uniqueId")));
	//	getActionItemsInstance().reportStepLog(getMyAccountRepoInstance().txtUniqueIdView.getText()+"*****"+(personalDetails.get("uniqueId")));	
		getActionItemsInstance().reportStepLog("Unique ID :: "+getMyAccountRepoInstance().txtUniqueIdView.getText());
				
		/*assertTrue(
				getMyAccountRepoInstance().txtUniqueIdExpiryDate.getText()
						.equals(getActionItemsInstance().epochToDate(personalDetails.get("uniqueIdExpiryDate"))),
				"Exp id in app: " + getMyAccountRepoInstance().txtUniqueIdExpiryDate.getText() + " Exp id in api: "
						+ getActionItemsInstance().epochToDate(personalDetails.get("uniqueIdExpiryDate")));*/
		
		
		if(getMyAccountRepoInstance().txtUniqueIDCopyview.isDisplayed()) 		{
			getActionItemsInstance().reportStepLog("Unique ID Scan copy image is dispalyed");	
		}
		getActionItemsInstance().reportStepLog("Personal details have been verified");
		getActionItemsInstance().addLogWithScreenShot("View Profile Screen-3");
	}

	private void verifyPhoneNo() {
		//assertTrue(
				//getMyAccountRepoInstance().txtPhonenumberview.getText().replaceAll("\\s", "")
				//		.equals(personalDetails.get("phoneNo")),
			//	"Phone no in app: " + getMyAccountRepoInstance().txtPhonenumberview.getText().replaceAll("\\s", "")
					//	+ " Phone no from api: " + personalDetails.get("phoneNo"));
		getActionItemsInstance().reportStepLog(getMyAccountRepoInstance().txtPhonenumberview.getText());
		getActionItemsInstance().reportStepLog("Phone number is verified");
	}

	private void verifyAddressDetails() {
		//addressDetails.forEach(txt -> getMyAccountRepoInstance().txtFarmerAddress.getText().contains(txt));
		//getActionItemsInstance().scrollUntilVisibleText("Country");
		getActionItemsInstance().reportStepLog("Address :: "+getMyAccountRepoInstance().txtCountryview.getText());
		getActionItemsInstance().addLogWithScreenShot("View profile screen-4");
		
		getActionItemsInstance().scrollDownViewByXpath("//*[@text='District']");
		
		getActionItemsInstance().reportStepLog("State/Province:: "+getMyAccountRepoInstance().txtStateView.getText());
	
		getActionItemsInstance().reportStepLog("District:: "+getMyAccountRepoInstance().txtDistview.getText());
	
		getActionItemsInstance().reportStepLog("Sub District:: "+getMyAccountRepoInstance().txtSubDistView.getText());		
	
		getActionItemsInstance().reportStepLog("City:: "+getMyAccountRepoInstance().txtCityView.getText());	
	
		getActionItemsInstance().reportStepLog("Address:: "+getMyAccountRepoInstance().txtAddressView.getText());
		getActionItemsInstance().addLogWithScreenShot("View Profile Screen-5");
		getActionItemsInstance().scrollDownViewByXpath("//*[@text='Farmer Lead Name']");
	
		getActionItemsInstance().reportStepLog("Zipcode:: "+getMyAccountRepoInstance().txtZipcodeView.getText());
		
		getActionItemsInstance().reportStepLog("Address details are verified");
	}
	
	private void verifyFLDetailsOfFarmer() {
		
		
		getActionItemsInstance().reportStepLog("Farmer Lead ID :: "+getMyAccountRepoInstance().txtFLIDview.getText());
	
		getActionItemsInstance().reportStepLog("Farmer Lead Name:: "+getMyAccountRepoInstance().txtFLNameview.getText());
		getActionItemsInstance().addLogWithScreenShot("View Profile Screen-6");
	
		getActionItemsInstance().reportStepLog("Famer Lead details are verified");
	
	}

	private void verifyBankAccountDetails() {
		getActionItemsInstance().scrollUntilVisibleText("Bank name");
		getMyAccountRepoInstance().txtAccHolderName.getText().equals(personalDetails.get("accountHolderName"));
		getMyAccountRepoInstance().txtBankName.getText().equals(personalDetails.get("bankName"));
		getMyAccountRepoInstance().txtBankAccNo.getText().equals(personalDetails.get("accountNo"));
		getMyAccountRepoInstance().txtAccType.getText().equals(personalDetails.get("accountType"));
		getActionItemsInstance().reportStepLog("Bank account details are verified");
	}

	public void verifyOtherDocuments() {
		getActionItemsInstance().scrollUntilVisibleText("Change Language");
		IntStream.rangeClosed(1, getMyAccountRepoInstance().UploadDoc.size()).filter(i -> i % 2 == 0)
				.forEach(i -> uploadDocument(i));
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNext);
		assertTrue(getActionItemsInstance().isDisplayedAction(getMyAccountRepoInstance().txtUpdateSubmissionStatus));
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnOk);
		getActionItemsInstance().reportStepLog("Other documents section is verified");
	}

	private void verifyLanguage() {
		getActionItemsInstance().scrollUntilVisibleText("Logout");
		getActionItemsInstance().isDisplayedAction(getMyAccountRepoInstance().txtLanguage);
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().imgEditLanguage);
		boolean popupStatus = getActionItemsInstance()
				.isDisplayedAction(getMyAccountRepoInstance().txtLanguagePopupTitle);
		if (popupStatus == true) {
			getActionItemsInstance().clickAction(getAndroidRepoInstance().btnOk);
		}
		getActionItemsInstance().reportStepLog("Language section is verified");
	}

	public void uploadSignature() {
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().imgAddSignature);
		getActionItemsInstance().isDisplayedAction(getMyAccountRepoInstance().titleSignature);
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().lnkEndUserPolicy);
		getActionItemsInstance().isDisplayedAction(getMyAccountRepoInstance().titleEndUserLicense);
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNavigateUp);
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().lnkPrivacyPolicyFr);
		getActionItemsInstance().isDisplayedAction(getMyAccountRepoInstance().titlePrivacyPolicy);
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNavigateUp);
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().chkPrivacyPolicy);
		getMyAccountActionInstance().geoSign();
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnUpload);
		getActionItemsInstance().isDisplayedAction(getMyAccountRepoInstance().txtSuccessfully);
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnOk);
		getActionItemsInstance().reportStepLog("Upload signature verified");
	}

	public void uploadDocument(int index) {

		{
			int warningCount = 0;
			if (index == 2)
				warningCount = getMyAccountRepoInstance().txtPendingVerification1.size();
			else if (index == 4)
				warningCount = getMyAccountRepoInstance().txtPendingVerification2.size();
			if (!(warningCount > 0)) {
				getActionItemsInstance().clickAction(getMyAccountRepoInstance().UploadDoc.get(index - 2));
				getActionItemsInstance().uploadImage();
				getActionItemsInstance().reportStepLog("Document upload is verified");
			} else {
				getActionItemsInstance().reportStepLog("Document is pending for verification");
			}
		}
	}

	public void geoSign() {

		Point center = getMyAccountRepoInstance().geoSignArea.getCenter();
		int x = center.x;
		int y = center.y;
		int newx = (center.x + 5) / 2;
		int newy = (center.y + 5) / 2;
		TouchAction ta = new TouchAction(driver);
		ta.tap(PointOption.point(newx, newy)).perform();
		ta.tap(PointOption.point(newx + 2, newy + 2)).perform();
		getActionItemsInstance().reportStepLog("Signed successfuly");
	}

	public void navigateToMyAccount() {		
		
		getActionItemsInstance().clickAction(getAndroidRepoInstance().imgHomeMenu);
		//getActionItemsInstance().scrollUpViewByXpath("//*[contains(@text,'My account')]");
		//getActionItemsInstance().clickByVisibleText("//*[contains(@text,'My account')]");
		getActionItemsInstance().clickAction(getHomeRepoInstance().btnHome);
		getActionItemsInstance().clickAction(getAndroidRepoInstance().imgHomeMenu);
		getActionItemsInstance().waitForProgressBar();	
		getActionItemsInstance().clickAction(getHomeRepoInstance().viewProfileMenu);
		getActionItemsInstance().addLogWithScreenShot("User is navigated to login screen");
		getActionItemsInstance().waitForProgressBar();			
		getActionItemsInstance().verifyText(getAndroidRepoInstance().txtHeadTitle.getText(),"Profile");
		getActionItemsInstance().addLogWithScreenShot("User is navigated to login screen");
	}

	public void logout() {
		getActionItemsInstance().clickAction(getAndroidRepoInstance().imgHomeMenu);
		//getActionItemsInstance().scrollDownViewByXpath("//*[contains(@text,'LOGOUT')]");
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().lnkLogout);
		//getActionItemsInstance().clickAction(getMyAccountRepoInstance().btnLogout);
		//assertFalse(getActionItemsInstance().isDisplayedAction(getMyAccountRepoInstance().lnkLogout));
		getActionItemsInstance().reportStepLog("Farmer is logged out successfully");
	}

	public void editPersonalDetails(String gender,String fullName,String dob,String email) throws ParseException, InterruptedException {
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().editBtn);
		getActionItemsInstance().addLogWithScreenShot("Clicked the EDIT button");
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().changeProfileImagelink);
		//getActionItemsInstance().clickAction(getLoginRepoInstance().imgProfilePik);
		getActionItemsInstance().uploadImage();
		//getActionItemsInstance().clickAction(getLoginRepoInstance().btnMrs);
		getActionItemsInstance().clearAction(getMyAccountRepoInstance().editFullName);
		getActionItemsInstance().sendKeysAction(getMyAccountRepoInstance().editFullName, fullName);
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().editDob);
		// getLoginActionInstance().selectDate(Constants.FARMER_DOB);
		getLoginActionInstance().selectCompleteDate(dob);
		getActionItemsInstance().addLogWithScreenShot("EditPersonalDetails1");
		getActionItemsInstance().scrollDownViewByXpath("//*[@text='Email*']");
		getActionItemsInstance().clearAction(getMyAccountRepoInstance().editEmail);
		getActionItemsInstance().sendKeysAction(getMyAccountRepoInstance().editEmail, email);
		getActionItemsInstance().scrollDownViewByXpath("//*[@text='Add Scan Copy Of Unique Id']");
		getActionItemsInstance().clearAction(getMyAccountRepoInstance().editUniqueID);
		getActionItemsInstance().sendKeysAction(getMyAccountRepoInstance().editUniqueID,
				String.valueOf(getActionItemsInstance().getRandomNumber(10)));
		//getActionItemsInstance().scrollUntilVisibleText("Add Scan Copy of Unique Id");
		//getActionItemsInstance().clickAction(getLoginRepoInstance().calendarNationalIdExpiry);
		// getLoginActionInstance().selectDate(Constants.NATIONAL_ID_EXPIRY);
		//getLoginActionInstance().selectCompleteDate(Constants.NATIONAL_ID_EXPIRY);
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().editScanCopy);
		getActionItemsInstance().uploadImage();
		getActionItemsInstance().addLogWithScreenShot("Edit Personal Details2");
		updateAndVerifySuccessMsg();
		// TODO - defect
	}

	public void editBankAccountDetails() {
		getActionItemsInstance().scrollDownViewByXpath("//*[contains(@resource-id,'edit_img1')]");
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().imgEditBankDetails);
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().txtBankName);
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().ddFirstOption);
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNext);
		getActionItemsInstance().sendKeysAction(getMyAccountRepoInstance().txtBankAccNo,
				String.valueOf(getActionItemsInstance().getRandomNumber(10)));
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().txtAccType);
		getActionItemsInstance().clickByVisibleText("OTHERS");
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNext);
		getActionItemsInstance().sendKeysAction(getMyAccountRepoInstance().editAccHolderName, "EditedName");
		getActionItemsInstance().scrollDownViewByXpath("//*[contains(@resource-id,'txtReTakektp')]");
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().imgRetakeUniqueId);
		getActionItemsInstance().uploadImage();
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNext);
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNext);
		assertTrue(getActionItemsInstance().isDisplayedAction(getMyAccountRepoInstance().txtUpdateSubmissionStatus));
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnOk);
		getActionItemsInstance().reportStepLog("Bank account details are added successfully");
	}

	public void editPhoneNo(String phoneNum,String OTP) throws ClassNotFoundException, SQLException, InterruptedException {		
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().editBtn);
		//getActionItemsInstance().clickAction(getMyAccountRepoInstance().imgEditPhoneNo);
		getActionItemsInstance().clearAction(getMyAccountRepoInstance().editPhoneNum);
		getActionItemsInstance().sendKeysAction(getMyAccountRepoInstance().editPhoneNum,phoneNum);
				//String.format("%10d", getActionItemsInstance().getRandomNumber(10)));
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().editSubmitBtn);		
		
		if(getActionItemsInstance().isDisplayedAction(getMyAccountRepoInstance().alertPopup))
		{			
			getActionItemsInstance().addLogWithScreenShot("Alert when OTP not received from Firebase");
			getActionItemsInstance().reportStepLog("Phone Number not Edited Due to this Error ::"+getMyAccountRepoInstance().alertPopupMsg);
			getActionItemsInstance().clickAction(getMyAccountRepoInstance().okBtninAlert);
		}	
		
		// one more error popup code need to add here when same phone is updating 
		//else if(){ }
		
		else if(getActionItemsInstance().isDisplayedAction(getMyAccountRepoInstance().editPopupSuccessMsg)) {			
			getActionItemsInstance().addLogWithScreenShot("Profile Updated Popup");
			getActionItemsInstance().clickAction(getMyAccountRepoInstance().editedPopupOkbtn);			
			getActionItemsInstance().reportStepLog("Phone number is Edited with same number and verified ");
		}
		
		else { //commenting below OTP enter when phone number update
			//enterOTP();
			enterOTPReact(OTP);
			getActionItemsInstance().clickAction(getAndroidRepoInstance().btnConfirm);		
			Thread.sleep(1000);
			//Below code need to change after enter OTP and confirm
		//assertTrue(getActionItemsInstance().isDisplayedAction(getMyAccountRepoInstance().txtPhoneNoChangeStatus));
		//String txtUpdatedPhoneNo = getMyAccountRepoInstance().txtUpdatedPhoneNo.getText();		
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnOk);
		//assertTrue(getMyAccountRepoInstance().txtFarmerPhoneNo.getText().replaceAll("(^\\+[0-9]*)|(\\s+)", "")
			//	.equals(txtUpdatedPhoneNo.replaceAll("\\s", "")));
		getActionItemsInstance().reportStepLog("Phone number is Edited and verified");
		}
	}

	public void editAddress() throws ParseException, InterruptedException {
		getActionItemsInstance().scrollDownViewByXpath("//*[@text='Address*']");		
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().editBtn);
		getActionItemsInstance().clearAction(getMyAccountRepoInstance().editAdd);
		getActionItemsInstance().sendKeysAction(getMyAccountRepoInstance().editAdd,"Editing Address");
		getActionItemsInstance().clearAction(getMyAccountRepoInstance().editZipcode);
		getActionItemsInstance().sendKeysAction(getMyAccountRepoInstance().editZipcode,String.valueOf(getActionItemsInstance().getRandomNumber(6)));
		
		updateAndVerifySuccessMsg();
		
		// TODO - defect edit address button not appearing
	}
	
	public void enterOTPReact(String OTP) throws ClassNotFoundException, SQLException {
		char[] otpArr = OTP.toCharArray();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
		for (int i = 0; i<otpArr.length; i++) {
			driver.findElementByXPath("(//*[@resource-id='textInput'])["+ (i+1)  +"]")
				.sendKeys(Character.toString(otpArr[i]));		
		}
	}

	public void verifySignature() {
		try {
			TouchAction touchAction = new TouchAction(driver);
			touchAction.tap(PointOption.point(803, 511)).perform();
			getActionItemsInstance().scrollUntilVisibleText("Signature");
		} catch (Exception e) {
			e.printStackTrace();
			getActionItemsInstance().reportStepLog("Signature is not visible");
		}

		if (getMyAccountRepoInstance().txtSignatureStatus.size() > 0) {
			String statusText = getMyAccountRepoInstance().txtSignatureStatus.get(0).getText();
			getActionItemsInstance().reportStepLog("Captured signature status text is - " + statusText);

			if (statusText.contains("resubmit")) {
				getActionItemsInstance().reportStepLog("Signature was not approved by admin. Please resubmit");
				uploadSignature();
			} else if (statusText.contains("waiting for approval")) {
				getActionItemsInstance()
						.reportStepLog("Signature has been submitted and is waiting for approval from admin");
			} else if (getMyAccountRepoInstance().txtSignatureStatus.get(0).getText().contains("verified")) {
				getActionItemsInstance().reportStepLog("Signature and coordinates have been verified by admin");
			}
		} else {
			uploadSignature();
		}

	}

	public void enterOTP() throws ClassNotFoundException, SQLException {

		char[] arrOtp = getDatabaseUtil().getVerificationOtp().toCharArray();
		for (int i = 0; i < arrOtp.length; i++) {
			getActionItemsInstance().sendKeysAction(getHomeRepoInstance().tbOtp.get(i), Character.toString(arrOtp[i]));
		}
		getActionItemsInstance().reportStepLog("OTP entered");
	}

	private void updateAndVerifySuccessMsg() {
		//getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNext);
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().editSubmitBtn);
		if(getActionItemsInstance().isDisplayedAction(getMyAccountRepoInstance().popupMsgEditAdd))
		{
			getActionItemsInstance().reportStepLog("Error Popup Message:  "+getMyAccountRepoInstance().popupMsgEditAdd.getText());
			getActionItemsInstance().addLogWithScreenShot("Error poup when proifle not updating");
			getActionItemsInstance().clickAction(getMyAccountRepoInstance().okBtnInPopup);
			
			}
		else {
		assertTrue(getActionItemsInstance().isDisplayedAction(getMyAccountRepoInstance().editPopupSuccessMsg));
		getActionItemsInstance().addLogWithScreenShot("Profile Updated Popup");
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().editedPopupOkbtn);
		//getActionItemsInstance().clickAction(getMyAccountRepoInstance().editPopupClsbtn); //Close popup btn
		getActionItemsInstance().reportStepLog("Data edited Successfully");
		}
	}

	private void viewUploadedDocs() {
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().lnkViewUploadedDocs);
		getActionItemsInstance().verifyText(getAndroidRepoInstance().txtHeadTitle.getText(), "Documents");
		getActionItemsInstance().clickAction(getMyAccountRepoInstance().lnkFirstDoc);
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNavigateUp);
		getActionItemsInstance().verifyText(getAndroidRepoInstance().txtHeadTitle.getText(), "Documents");

	}

	public void getProfileDetailsFromWebService() throws ClassNotFoundException, SQLException {
		backendFarmerId = getDatabaseUtil().getBackendFarmerId(getMyAccountActionInstance().getDisplayFarmerIdFromDB());
		profileDetails = getApiActions().getProfileDetails(backendFarmerId);
		personalDetails = (Map<String, String>) profileDetails[0].getValue();
		addressDetails = (ArrayList<String>) profileDetails[1].getValue();
	}

}
