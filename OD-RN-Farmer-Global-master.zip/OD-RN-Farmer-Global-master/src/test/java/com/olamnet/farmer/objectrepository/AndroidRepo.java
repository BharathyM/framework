package com.olamnet.farmer.objectrepository;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindAll;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;

import com.olamnet.farmer.utilities.AppiumUtil;

import java.net.MalformedURLException;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class AndroidRepo extends AbstractRepository {

	public static AndroidRepo androidRepo = null;

	public AndroidRepo(AndroidDriver driver) {
		super(driver);
	}

	public static AndroidRepo getInstance() {
		if (androidRepo == null)
			androidRepo = new AndroidRepo(AppiumUtil.driver);
		return androidRepo;
	}
	
	
	//Permission text-Allow Farmer - SIT to take pictures and record video?
		@AndroidFindBy(xpath = "//*[@text='Allow Olam Direct - UAT to take pictures and record video?']")
		public AndroidElement permissionpopupBytext1;
		
		//Permission text-Allow Farmer - SIT to access photos and media on your device?
		@AndroidFindBy(xpath = "//*[@text='Allow Olam Direct - UAT to access this device’s location?']")
		public AndroidElement permissionpopupBytext2;	
		
		@AndroidFindBy(xpath = "//*[@text='While using the app']")
		public AndroidElement permissionAllowforCamera;
		
		//*[@text='While using the app']
		
		//Permission text-Allow FARMER - MANNA UAT to access photos and media on your device?
		@AndroidFindBy(xpath = "//*[@text='Allow Olam Direct - UAT to access photos and media on your device?']")
		public AndroidElement permissionpopupBytext3;
				
		// App permission - Allow
		@AndroidFindBy(xpath = "//*[@text='Allow']")
		public AndroidElement permissionAllowforStorage;
				//*[@text='Allow']

		
		

	// App permission - Allow
	@AndroidFindBy(id = "permission_allow_button")
	public AndroidElement permissionAllow;

	// App permission - Deny
	@AndroidFindBy(id = "permission_deny_button")
	public AndroidElement permissionDeny;

	// App permission - Message
	@AndroidFindBy(id = "permission_message")
	public AndroidElement permissionMessage;

	// App permission - pager text
	@AndroidFindBy(id = "current_page_text")
	public AndroidElement permissionPagerText;

	// Toast
	@AndroidFindBy(xpath = "//android.widget.Toast[@text='Please enter the valid enumerator Id']")
	public AndroidElement toast;

	// Pop-up Cancel
	@AndroidFindAll({ @AndroidBy(uiAutomator = "new UiSelector().resourceId(\"android:id/button2\")"),
			@AndroidBy(id = "button2") })
	public AndroidElement cancelButton;

	// Calender previous
	@AndroidFindAll({ @AndroidBy(uiAutomator = "new UiSelector().resourceId(\"android:id/prev\")"),
			@AndroidBy(id = "prev") })
	public AndroidElement prev;

	// Calender Date
	@AndroidFindBy(xpath = "//*[@text='1']")
	public AndroidElement date1;

	// Progress bar widget
	@AndroidFindBy(className = "android.widget.ProgressBar")
	public AndroidElement progressBar;

	// Shutter button
	@AndroidFindAll({ @AndroidBy(id = "com.android.camera3:id/shutter_button_photo"),
			@AndroidBy(xpath = "//*[@text='Shutter']") })
	public AndroidElement shutterButton;

	// Camera - Dismiss
	@AndroidFindAll({ @AndroidBy(id = "com.android.camera3:id/btn_cancel"),
			@AndroidBy(id = "com.sec.android.app.camera:id/retry") })
	public AndroidElement shutterCancel;

	// Camera - Done
	@AndroidFindAll({ @AndroidBy(id = "com.android.camera3:id/btn_done"),
			@AndroidBy(id = "com.sec.android.app.camera:id/okay") })
	public AndroidElement shutterDone;

	// Select source of image - Camera
	@AndroidFindBy(xpath = "//*[@text='Camera']")
	public AndroidElement camera;

	// Select source of image - Gallery
	@AndroidFindBy(xpath = "//*[@text='Gallery']")
	public AndroidElement gallery;

	// Select source of image - Photo
	@AndroidFindBy(id = "com.google.android.apps.photos:id/image")
	public AndroidElement images;

	// Snack bar
	@AndroidFindBy(id = "snackbar_text")
	public AndroidElement snackbar_text;

	// backButton
	@AndroidFindBy(className = "android.widget.ImageButton")
	public AndroidElement backButton;

	// backButton
	@AndroidFindAll({ @AndroidBy(uiAutomator = "new UiSelector().resourceId(\"android:id/message\")"),
			@AndroidBy(id = "message") })
	public AndroidElement message;

	// No
	@AndroidFindBy(xpath = "//*[@text='No']")
	public AndroidElement no;

	// Yes
	@AndroidFindAll({ @AndroidBy(uiAutomator = "new UiSelector().resourceId(\"android:id/button1\")"),
			@AndroidBy(id = "button1") })
	public AndroidElement button1;

	// text1
	@AndroidFindAll({ @AndroidBy(uiAutomator = "new UiSelector().resourceId(\"android:id/text1\")"),
			@AndroidBy(id = "text1") })
	public List<AndroidElement> text;

	@AndroidFindBy(id = "text1")
	public AndroidElement text1;

	@AndroidFindBy(id = "toolbar_dial")
	public AndroidElement imgHelpline;

	@AndroidFindBy(xpath = "(((//*[@class='android.view.ViewGroup' and ./parent::*[@class='android.view.ViewGroup' and ./parent::*[@class='android.view.ViewGroup' and ./parent::*[@class='android.view.ViewGroup' and ./parent::*[@class='android.view.ViewGroup' and ./parent::*[@class='android.widget.FrameLayout' "
			+ "and ./parent::*[(./preceding-sibling::* | ./following-sibling::*)[@class='android.view.ViewGroup'] and ./parent::*[./parent::*[./parent::*[./parent::*[@class='android.view.ViewGroup']]]]]]]]]]]/*/*[@class='android.view.ViewGroup' and ./parent::*[@class='android.view.ViewGroup']])[1]/*[@class='android.view.ViewGroup'])[2]/*/*/*[@class='android.view.ViewGroup' "
			+ "and ./parent::*[@class='android.view.ViewGroup' and ./parent::*[@class='android.view.ViewGroup']]])[1]")
	public AndroidElement imgHomeMenu;
	
	
	
	
	
	//*
	
	@AndroidFindBy(xpath = "//*[@text='Logout']")
	public AndroidElement logoutlink;
	
	@AndroidFindBy(xpath = "//*[@text='Are you sure you want to exit the application?']")
	public AndroidElement logoutPopup;
	
	@AndroidFindBy(xpath = "//*[@text='Yes']")
	public AndroidElement logoutYes;
	
	@AndroidFindBy(xpath = "//*[@text='No']")
	public AndroidElement logoutNo;	
	

	@AndroidFindBy(xpath = "//*[@resource-id='com.olam.fsp.farmertest:id/backIcon']")
	public AndroidElement btnNavigateUp;
	
	@AndroidFindBy(xpath="//*[@class='android.widget.ImageView' and ./parent::*[@contentDescription='Legal, back']]")
	public AndroidElement btnNavigateback;
	
	@AndroidFindBy(id = "txtFilter")
	public AndroidElement btnFilter;

	@AndroidFindBy(id = "toolbar_logo")
	public AndroidElement logoToolbar;

	@AndroidFindBy(id = "prevMonth")
	public AndroidElement btnPrevMonth;

	@AndroidFindBy(id = "nextMonth")
	public AndroidElement btnNextMonth;

	@AndroidFindBy(xpath = "//*[@text='Upload'] | //*[@text='UPLOAD'] ")
	public AndroidElement btnUpload;

	@AndroidFindBy(xpath = "//*[@text='OK']")
	public AndroidElement btnOk;

	@AndroidFindBy(xpath = "//*[@text='DONE']")
	public AndroidElement btnDone;

	@AndroidFindBy(xpath = "//*[@text='SUBMIT']")
	public AndroidElement btnSubmit;

	@AndroidFindBy(xpath = "//*[@text='CONFIRM']")
	public AndroidElement btnConfirm;

	@AndroidFindBy(xpath = "//*[@text='FINISH']")
	public AndroidElement btnFinish;
	
	@AndroidFindBy(xpath = "//*[@text='NEXT']")
	public AndroidElement btnNEXT;	

	@AndroidFindBy(xpath = "//*[@text='Next']")
	public AndroidElement btnNext;	
	
	@AndroidFindBy(xpath = "//*[@text='Profile']") 
	public AndroidElement txtHeadTitle;
	
	@AndroidFindBy(xpath = "//*[@id='country_name'])[1]")
	public AndroidElement commodityddSelecitonSignup;
	
	//*[@text='SELECT COMMODITY']
			
	@AndroidFindBy(xpath = "//*[@text='Camera']")
	public AndroidElement btnCamera;

	@AndroidFindAll({ @AndroidBy(xpath = "//*[contains(@resource-id,'preview_btn_done')]"),
			@AndroidBy(xpath = "//*[contains(@resource-id,'review_ok_button')]") })
	public AndroidElement btnShutterDone;

	@AndroidFindBy(xpath = "//*[@text='ALLOW']")
	public AndroidElement btnAllow;

}
