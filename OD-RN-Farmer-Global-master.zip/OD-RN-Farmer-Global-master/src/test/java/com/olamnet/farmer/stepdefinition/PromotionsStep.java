package com.olamnet.farmer.stepdefinition;

import com.olamnet.farmer.utilities.BaseStepAction;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class PromotionsStep extends BaseStepAction{
	
		@Given("^the user is on promotions screen$")
		public void the_user_is_on_promotions_screen() throws Throwable {
			
			getActionItemsInstance().clickAction(getAndroidRepoInstance().imgHomeMenu);	
			getActionItemsInstance().clickAction(getPromotionsRepoInstance().promotionsInMenu);
			getActionItemsInstance().waitForProgressBar();	
			getActionItemsInstance().addLogWithScreenShot("Share with Olam screen...");			
			
			//getActionItemsInstance().clickAction(getAndroidRepoInstance().imgHomeMenu.get(0));
			//getActionItemsInstance().scrollDownViewByXpath("//*[@text='Crop Feedback']");
			//getActionItemsInstance().clickAction(getHomeRepoInstance().btnCropFeedback);
			//getActionItemsInstance().verifyText(getAndroidRepoInstance().txtTitle.getText(), "Crop Feedback");
		}		

		@Then("^verify UI elements in promotions$")
		public void verify_UI_elements_in_promotions() throws Throwable {
			getPromotionsActionInstance().verifyUIElemtnsinPromotions();

		}
	}


