package com.olamnet.farmer.utilities;

import static com.olamnet.farmer.utilities.Constants.*;
import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.gson.JsonSyntaxException;
import com.olamnet.farmer.utilities.AppiumServerTest;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import javafx.util.Pair;

@SuppressWarnings("restriction")
public class ApiActions extends BaseStepAction {

	public static ApiActions apiActions = null;
	private AtomicBoolean alreadyExecuted = new AtomicBoolean(false);

	public static ApiActions getInstance() {
		if (apiActions == null)
			apiActions = new ApiActions();
		return apiActions;
	}

	Headers portalHeaders;
	Headers appHeaders;
	public static Response response;
	public static String responseString;
	public static List<String> listValueString;
	public static List<Integer> listValueInt;
	public static String value;
	int size = 0;
	String restApiTokenType = "Bearer";
	public Map<String, List<String>> mlMapInputParam = new LinkedHashMap<>();

	// Header list
	public void authenticateBaseUrlForPortal() {
		if (alreadyExecuted.compareAndSet(false, true)) {
			List<Header> headerlist = new ArrayList<Header>();
			headerlist.add(new Header("Content-Type", CONTENT_TYPE));
			headerlist.add(new Header("App-Id", APP_ID));
			headerlist.add(new Header("Authorization", getRestAPIAccessTokenForPortal()));
			portalHeaders = new Headers(headerlist);
		}
	}

	public void authenticateBaseUrlForApp(String farmerLeadId) throws JSONException {
		List<Header> headerlist = new ArrayList<Header>();
		headerlist.add(new Header("Content-Type", "application/json"));
		headerlist.add(new Header("Authorization", getRestAPIAccessTokenForMobileApp(farmerLeadId)));
		appHeaders = new Headers(headerlist);
	}

	public String getRestAPIAccessTokenForMobileApp(String farmerLeadId) throws JSONException {
		resetDevice(farmerLeadId, ROLE_ID_FL);
		String accessToken = "";
		try {

			RestAssured.baseURI = AppiumUtil.baseUrl;
			RequestSpecification request = given();
			request.header("Content-Type", "application/json");
			JSONObject jObjReqParams = new JSONObject();
			jObjReqParams.put("clientId", FL_APP_CLIENT_ID);
			jObjReqParams.put("id", farmerLeadId);
			jObjReqParams.put("languageIsoCode", LANG_ISO_CODE);
			jObjReqParams.put("originId", AppiumUtil.originId);
			jObjReqParams.put("password", ADMIN_PASSWORD);
			jObjReqParams.put("roleId", ROLE_ID_FL);
			request.body(jObjReqParams.toString());
			Response response = request.post(URL_AUTHENTICATION);

			int statusCode = response.getStatusCode();
			System.out.println("getRestAPIAccessToken -> Status code is:" + statusCode);
			response.print();
			Assert.assertEquals(statusCode, 200);
			JsonPath jPathEvaluator = response.jsonPath();
			String restApiAccessToken = jPathEvaluator.get("accessToken").toString();
			accessToken = restApiTokenType.concat(" ").concat(restApiAccessToken);
			System.out.println("getRestAPIAccessToken ->AccessToken:" + accessToken);

		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			getActionItemsInstance().reportStepLog("Failed due to Exception " + e.getMessage());
		}
		return accessToken;
	}

	/* get rest API access token */

	public String getRestAPIAccessTokenForPortal() {
		String accessToken = "";
		try {

			RestAssured.baseURI = AppiumUtil.baseUrl;		
			System.out.println("baseURL: "+AppiumUtil.baseUrl);
			RequestSpecification request = given();
			request.header("Content-Type", "application/json");
			JSONObject jObjReqParams = new JSONObject();
			jObjReqParams.put("id", AppiumUtil.userId);
			System.out.println("User ID : "+AppiumUtil.userId);
			jObjReqParams.put("password", ADMIN_PASSWORD);
			System.out.println("AdminPassword : "+ADMIN_PASSWORD);
			jObjReqParams.put("clientId", PORTAL_CLIENT_ID);
			System.out.println("Client ID : "+PORTAL_CLIENT_ID);
			if (AppiumUtil.testEnv.contains("uat")) {
				jObjReqParams.put("originId", AppiumUtil.originId);
				System.out.println("Origin ID : "+AppiumUtil.originId);
			}
			request.body(jObjReqParams.toString());
			System.out.println("getRestAPIAccessToken Req: " + jObjReqParams.toString());
			Response response = request.post(URL_AUTHENTICATION);
			System.out.println("Response : "+response);

			int statusCode = response.getStatusCode();
			response.print();
			Assert.assertEquals(statusCode, RESPONSE_CODE_SUCCESS);
			JsonPath jPathEvaluator = response.jsonPath();
			String restApiAccessToken = jPathEvaluator.get("accessToken").toString();
			accessToken = restApiTokenType.concat(" ").concat(restApiAccessToken);

		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			getActionItemsInstance().reportStepLog("Failed due to Exception " + e.getMessage());
		}
		return accessToken;
	}

	public void acceptTermsAndConditions(String farmerLeadId, String farmerName) throws JSONException {

		authenticateBaseUrlForApp(farmerLeadId);
		RestAssured.baseURI = AppiumUtil.baseUrl;
		int[] arrDoc = { 1, 2 };
		JSONObject jObjReqParams = new JSONObject();
		jObjReqParams.put("documentTypeId", arrDoc);
		jObjReqParams.put("userId", farmerName);
		System.out.println("acceptTermsAndConditions -> Json body:" + jObjReqParams.toString());
		Response response = given().headers(appHeaders).body(jObjReqParams.toString()).when()
				.post("authorization/updateUsersToVersionAcceptance").then().extract().response();

		int statusCode = response.getStatusCode();
		System.out.println("acceptTermsAndConditions ->Status code is:" + statusCode);

		String message = response.jsonPath().get("message");
		System.out.println("acceptTermsAndConditions ->Response message: " + message);
	}

	public List<String> getFLIntentDetails(String farmerLeadId, String backendFarmerLeadId, String farmerName,
			String date) throws JSONException {

		acceptTermsAndConditions(farmerLeadId, farmerName);
		RestAssured.baseURI = AppiumUtil.baseUrl;
		String completeFLIntentUrl = URL_FL_INTENT_DETAILS.concat(backendFarmerLeadId).concat("&date=").concat(date);
		response = given().headers(appHeaders).when().get(completeFLIntentUrl).then().extract().response();
		responseString = response.asString();

		System.out.println("getFLIntentDetails - response body : " + responseString);
		int responseCode = response.getStatusCode();
		Assert.assertEquals(responseCode, 200);

		List<String> txnList = response.jsonPath()
				.getList("farmerLeadOpenDropOffListDTOV2.farmerLeadOpenDropOffList.transactionId");

		System.out.println("Txn list : " + txnList);

		return txnList;
	}

	public String getRegistrationSettings() {
		RestAssured.baseURI = AppiumUtil.baseUrl;
		
		authenticateBaseUrlForPortal();
		response = given().headers(portalHeaders).when().get(URL_REGISTRATION_SETTINGS).then().extract().response();
		responseString = response.asString();

		System.out.println("getRegistrationSettings - response body : " + responseString);
		int responseCode = response.getStatusCode();
		Assert.assertEquals(responseCode, 200);

		String phoneNumberSetting = response.jsonPath().get("phoneNumberStartsWith");

		System.out.println("Phone number starts with : " + phoneNumberSetting);

		return phoneNumberSetting;
	}

	public void resetDevice(String loginId, String roleId) throws JSONException {
		RestAssured.baseURI = AppiumUtil.baseUrl;
		System.out.println("BaseURLResetDevice : " + AppiumUtil.baseUrl);
		authenticateBaseUrlForPortal();

		String jsonBody = getJsonForResetDevice(loginId, roleId).toString();
		System.out.println("Request json: " + jsonBody);
		response = given().headers(portalHeaders).body(jsonBody).when().post(URL_DEVICE_RESET).then().extract()
				.response();
		responseString = response.asString();

		System.out.println("response body : " + responseString);
		int responseCode = response.getStatusCode();
		Assert.assertEquals(responseCode, RESPONSE_CODE_SUCCESS);
	}

	public List<String> getCommoditiesMappedToFL(String displayFLId) throws JSONException {
		RestAssured.baseURI = AppiumUtil.baseUrl;
		authenticateBaseUrlForPortal();

		String jsonBody = getJsonForCommodityMappedToFl(displayFLId).toString();
		response = given().headers(portalHeaders).body(jsonBody).when().post(URL_FL_COMMODITY_MAPPING).then().extract()
				.response();
		responseString = response.asString();

		System.out.println("response body : " + responseString);
		int responseCode = response.getStatusCode();
		Assert.assertEquals(responseCode, 200);

		JsonPath jsonEvaluator = response.jsonPath().setRoot("flProductMapList[0]");

		List<String> commoditiesList = jsonEvaluator.get("flProductList.name");

		System.out.println(commoditiesList);

		return commoditiesList;

	}

	/**
	 * To get active trading product list
	 * 
	 * @param url - url to append with BASE_URL
	 * @return HashMap containing trading product name and trading product id
	 * @throws JSONException
	 */
	public Map<String, Integer> getTradProdList(String url, String displayFLId) throws JSONException {
		RestAssured.baseURI = AppiumUtil.baseUrl;
		Map<String, Integer> hmTradProd = new HashMap<String, Integer>();

		authenticateBaseUrlForPortal();

		String jsonBody = getJsonForCommodityMappedToFl(displayFLId).toString();
		response = given().headers(portalHeaders).when().get(url).then().extract().response();
		responseString = response.asString();

		System.out.println("response body : " + responseString);
		int responseCode = response.getStatusCode();
		Assert.assertEquals(responseCode, 200);

		JsonPath jsonEvaluator = response.jsonPath();

		int countTradProd = response.jsonPath().getList("$").size();

		for (int i = 0; i < countTradProd; i++) {

			hmTradProd.put(jsonEvaluator.get("[" + i + "].name"), jsonEvaluator.get("[" + i + "].tradingProductId"));

		}

		System.out.println(hmTradProd);

		return hmTradProd;

	}

	/**
	 * Gets the json response via API, extract the fields parameter name, min, max
	 * range values and insert them into a multimap
	 * 
	 * @param url - url to append with BASE_URL
	 * @return LinkedHashMap containing parameter name as keys & min, max of
	 *         parameter as values
	 */

	public Map<String, List<String>> getInputParamsAndLimits(String url) {

		try {
			RestAssured.baseURI = AppiumUtil.baseUrl;
			authenticateBaseUrlForPortal();
			response = given().headers(portalHeaders).when().get(url).then().extract().response();
			responseString = response.asString();
			System.out.println("response body : " + responseString);
			int responseCode = response.getStatusCode();
			Assert.assertEquals(responseCode, RESPONSE_CODE_SUCCESS);

			int countParam = response.jsonPath().getList("$").size();

			// traverse through the array and get parameter name

			for (int i = 0; i < countParam; i++) {

				String paramName = response.jsonPath().get("[" + i + "].parameterName");

				/* get min & max values and convert them from float to string */

				float floatMinVal = response.jsonPath().get("[" + i + "].valueLimitsDTOs[0].value");
				float floatMaxVal = response.jsonPath().get("[" + i + "].valueLimitsDTOs[1].value");
				String minVal = Integer.toString((int) floatMinVal);
				String maxVal = Integer.toString((int) floatMaxVal);

				/* put the key & values in multimap */

				put(paramName, minVal);
				System.out.println(paramName + minVal);
				put(paramName, maxVal);
				System.out.println(paramName + maxVal);

			}
		} catch (JsonSyntaxException e) {
			e.printStackTrace();
		}

		return mlMapInputParam;

	}

	/* insert key & corresponding values in map */
	public void put(String key, String value) {
		mlMapInputParam.computeIfAbsent(key, k -> new ArrayList<>()).add(value);
	}

	public void setStdDailyPrice() throws JSONException {

		RestAssured.baseURI = AppiumUtil.baseUrl;
		authenticateBaseUrlForPortal();

		String jsonBody = getJsonForStdDailyPrice().toString();
		response = given().headers(portalHeaders).body(jsonBody).when().post(URL_STD_PRICE_PUBLISH_TIME).then()
				.extract().response();
		responseString = response.asString();

		System.out.println("response body : " + responseString);
		int responseCode = response.getStatusCode();
		Assert.assertEquals(responseCode, 200);
	}

	public void setCommodityBasePrice() throws JSONException {
		RestAssured.baseURI = AppiumUtil.baseUrl;
		authenticateBaseUrlForPortal();

		String jsonBody = getJsonForCommodityBasePrice().toString();
		response = given().headers(portalHeaders).body(jsonBody).when().post(URL_COMMODITY_BASEPRICE).then().extract()
				.response();
		responseString = response.asString();

		System.out.println("response body : " + responseString);
		int responseCode = response.getStatusCode();
		Assert.assertEquals(responseCode, RESPONSE_CODE_SUCCESS);
	}

	public void setTradProdBasePrice() throws JSONException {
		RestAssured.baseURI = AppiumUtil.baseUrl;
		authenticateBaseUrlForPortal();

		String jsonBody = getJsonForTradProdBasePrice().toString();
		response = given().headers(portalHeaders).body(jsonBody).when().post(URL_TRADPROD_BASEPRICE).then().extract()
				.response();
		responseString = response.asString();

		System.out.println("response body : " + responseString);
		int responseCode = response.getStatusCode();
		Assert.assertEquals(responseCode, 200);
	}

	public void publishPrice() throws JSONException {
		RestAssured.baseURI = AppiumUtil.baseUrl;
		authenticateBaseUrlForPortal();

		String jsonBody = getJsonForPublishPrice().toString();
		response = given().headers(portalHeaders).body(jsonBody).when().post(URL_PUBLISH_PRICE).then().extract()
				.response();
		responseString = response.asString();

		System.out.println("response body : " + responseString);
		int responseCode = response.getStatusCode();
		Assert.assertEquals(responseCode, RESPONSE_CODE_SUCCESS);
	}

	@SuppressWarnings("rawtypes")
	public Pair[] getProfileDetails(String farmerId) {
		RestAssured.baseURI = AppiumUtil.baseUrl;
		authenticateBaseUrlForPortal();
		farmerId = getMyAccountActionInstance().getDisplayFarmerIdFromDB();
		response = given().headers(portalHeaders).when().get(URL_PROFILE_DETAILS.concat(farmerId)).then().extract()
				.response();
		responseString = response.asString();
		System.out.println(":::::::::::::::::::::::::::::::::::::::");
		System.out.println("getProfileDetails - response body : " + responseString);
		System.out.println(":::::::::::::::::::::::::::::::::::::::");
		int responseCode = response.getStatusCode();
		Assert.assertEquals(responseCode, RESPONSE_CODE_SUCCESS);
		System.out.println("response code"+responseCode);
		Map<String, String> hmPersonalDetails = new HashMap<String, String>();
		JsonPath jPathEvaluator = response.jsonPath();
		
		hmPersonalDetails.putIfAbsent("gender", jPathEvaluator.get("title").toString());
		hmPersonalDetails.putIfAbsent("farmerName", jPathEvaluator.get("firstName").toString());
		hmPersonalDetails.putIfAbsent("phoneNo", jPathEvaluator.get("contactNo").toString());
		hmPersonalDetails.putIfAbsent("dateOfBirth", jPathEvaluator.get("dateOfBirth").toString());
		hmPersonalDetails.putIfAbsent("email", jPathEvaluator.get("emailid").toString());
		//hmPersonalDetails.putIfAbsent("farmerId", jPathEvaluator.get("displayFarmerId").toString());
		hmPersonalDetails.putIfAbsent("uniqueId", jPathEvaluator.get("ktpId").toString());
		
		//hmPersonalDetails.putIfAbsent("uniqueIdExpiryDate", jPathEvaluator.get("ktpExpiryDate").toString());
		//hmPersonalDetails.putIfAbsent("farmerProgram", jPathEvaluator.get("subProgramName").toString());
		
		hmPersonalDetails.putIfAbsent("address", jPathEvaluator.get("streetAddress").toString());
		//hmPersonalDetails.putIfAbsent("profileVerifyStatus",
				//jPathEvaluator.get("profileVerificationStatus").toString());
		/*int bankDetailsVerifyStatus = jPathEvaluator.get("bankDetailsVerificationStatus");
		hmPersonalDetails.putIfAbsent("bankDetailsVerifyStatus",
				jPathEvaluator.get("bankDetailsVerificationStatus").toString());

		if (bankDetailsVerifyStatus == 3) {
			hmPersonalDetails.putIfAbsent("bankName", jPathEvaluator.get("bankName").toString());
			hmPersonalDetails.putIfAbsent("accountHolderName", jPathEvaluator.get("accountHolderName").toString());
			hmPersonalDetails.putIfAbsent("accountNo", jPathEvaluator.get("accountNumber").toString());
			hmPersonalDetails.putIfAbsent("accountType", jPathEvaluator.get("accountType").toString());
		}*/

		/*hmPersonalDetails.putIfAbsent("signatureVerifyStatus",
				jPathEvaluator.get("signatureVerificationStatus").toString());*/
		System.out.println(hmPersonalDetails);

		ArrayList<String> geoRegions = new ArrayList<String>();
		geoRegions = jPathEvaluator.get("geoDetails.name");
		System.out.println("Geo Regions: " + geoRegions);

		return new Pair[] { new Pair<String, Map<String, String>>("personalDetails", hmPersonalDetails),
				new Pair<String, ArrayList<String>>("geoRegions", geoRegions) };
		
			}

	public Map<String, String> getPremiumLedger() throws JSONException {
		RestAssured.baseURI = AppiumUtil.baseUrl;
		authenticateBaseUrlForPortal();
		String jsonBody = getJsonForFarmerPremiumLedgerView("ID-JBBD-AJAJ-0016").toString(); // TODO parameterize
		response = given().headers(portalHeaders).body(jsonBody).when().post(URL_FARMER_PREMIUM_LEDGER).then().extract()
				.response();
		responseString = response.asString();
		System.out.println("response body : " + responseString);
		int responseCode = response.getStatusCode();
		Assert.assertEquals(responseCode, RESPONSE_CODE_SUCCESS);

		Map<String, String> hmPremiumDetails = new HashMap<String, String>();
		hmPremiumDetails.putIfAbsent("olamOwesAmt", response.jsonPath().get("owedAmount").toString());
		hmPremiumDetails.putIfAbsent("totalPremiumEarned", response.jsonPath().get("totalPremiumEarned").toString());

		int countMonth = response.jsonPath().getList("premiumDetails").size();
		Map<String, String> hmPremiumMonthWise = new HashMap<String, String>();
		// traverse through the array and get parameter name

		for (int i = 0; i < countMonth; i++) {

			String paramName = (response.jsonPath().get("premiumDetails[" + i + "].month").toString());

			String totalPremium = (response.jsonPath().get("premiumDetails[" + i + "].totalPremium").toString());
			hmPremiumMonthWise.put(paramName, totalPremium);
		}

		return hmPremiumMonthWise;

	}

	public Map<String, String> getLedgerTransactionDetails(String farmerId, String transactionId) throws JSONException {
		RestAssured.baseURI = AppiumUtil.baseUrl;
		authenticateBaseUrlForPortal();
		JSONObject jObjReqParams = new JSONObject();
		jObjReqParams.put("farmerId", farmerId);
		jObjReqParams.put("transactionID", transactionId);
		System.out.println(jObjReqParams);
		response = given().headers(portalHeaders).body(jObjReqParams.toString()).when()
				.post(URL_FARMER_TXN_LEDGERDATAVIEW).then().extract().response();
		responseString = response.asString();
		System.out.println("response body : " + responseString);
		int responseCode = response.getStatusCode();
		Assert.assertEquals(responseCode, RESPONSE_CODE_SUCCESS);

		Map<String, String> hmLedgerDetails = new HashMap<String, String>();
		hmLedgerDetails.putIfAbsent("totalAmountValue", response.jsonPath().get("totalAmountValueOfCocoa").toString());
		hmLedgerDetails.putIfAbsent("totalAmountPaid", response.jsonPath().get("totalAmountPaid").toString());

		return hmLedgerDetails;
	}

	public List<String> getOriginCurrencyList() throws JSONException {
		RestAssured.baseURI = AppiumUtil.baseUrl;
		authenticateBaseUrlForPortal();
		response = given().headers(portalHeaders).when().get(URL_ORIGIN_CURRENCY_LIST).then().extract().response();
		responseString = response.asString();
		System.out.println("response body : " + responseString);
		int responseCode = response.getStatusCode();
		Assert.assertEquals(responseCode, RESPONSE_CODE_SUCCESS);

		List<String> currencyList = new ArrayList<String>();
		JsonPath jPathEvaluator = response.jsonPath().setRoot("[0]");
		currencyList.add(jPathEvaluator.get("currencyCode"));
		currencyList.add(jPathEvaluator.get("symbol"));
		currencyList.add(jPathEvaluator.get("decimalPlaces").toString());
		currencyList.add(jPathEvaluator.get("decimalSeparator"));
		currencyList.add(jPathEvaluator.get("numberSeparator"));

		return currencyList;
	}

	public void setOriginBasicDetails(String dtFormat, int deciPlaces, String deciSeparator, String numSeparator)
			throws JSONException {
		RestAssured.baseURI = AppiumUtil.baseUrl;
		authenticateBaseUrlForPortal();
		String jsonBody = getJsonForOriginBasicDetails(dtFormat, deciPlaces, deciSeparator, numSeparator).toString();
		System.out.println("req: " + jsonBody);
		response = given().headers(portalHeaders).body(jsonBody).when().post(URL_ORIGIN_BASIC_DETAILS).then().extract()
				.response();
		responseString = response.asString();
		System.out.println("response body : " + responseString);
		int responseCode = response.getStatusCode();
		Assert.assertEquals(responseCode, RESPONSE_CODE_SUCCESS);
	}

	public Map<String, String> FarmerLedgerSearch() throws JSONException {
		RestAssured.baseURI = AppiumUtil.baseUrl;
		authenticateBaseUrlForPortal();
		String jsonBody = getJsonForFarmerLedgerSearch().toString();
		System.out.println("req: " + jsonBody);
		response = given().headers(portalHeaders).body(jsonBody).when().post(URL_FARMER_LEDGER_SEARCH).then().extract()
				.response();
		responseString = response.asString();
		System.out.println("response body : " + responseString);
		int responseCode = response.getStatusCode();
		Assert.assertEquals(responseCode, RESPONSE_CODE_SUCCESS);

		Map<String, String> hmLedgerDetails = new HashMap<String, String>();
		// JsonPath jPathEvaluator = response.jsonPath().setRoot("[0]");
		hmLedgerDetails.putIfAbsent("olamOwesAmt", response.jsonPath().get("olamOwasAmt").toString());
		hmLedgerDetails.putIfAbsent("totalWeight", response.jsonPath().get("totalWeight").toString());
		hmLedgerDetails.putIfAbsent("transactionAmount",
				response.jsonPath().get("farmerLedgerResponseListDTO[0].transactionAmount").toString());
		hmLedgerDetails.putIfAbsent("amountRecevied",
				response.jsonPath().get("farmerLedgerResponseListDTO[0].amountRecevied").toString());

		return hmLedgerDetails;
	}

	public JSONArray getJsonForStdDailyPrice() throws JSONException {

		JSONObject jObjDropOffStartTime = new JSONObject();

		jObjDropOffStartTime.put("standardSettingId", "70");
		jObjDropOffStartTime.put("name", "DROP_OFF_START_TIME");
		jObjDropOffStartTime.put("value", "00:00:00");
		jObjDropOffStartTime.put("productId", "4");

		JSONObject jObjDropOffEndTime = new JSONObject();

		jObjDropOffEndTime.put("standardSettingId", "71");
		jObjDropOffEndTime.put("name", "DROP_OFF_END_TIME");
		jObjDropOffEndTime.put("value", "23:59:59");
		jObjDropOffEndTime.put("productId", "4");

		JSONObject jObjPricePublishTime = new JSONObject();

		jObjPricePublishTime.put("standardSettingId", "72");
		jObjPricePublishTime.put("name", "PRICE_PUBLISH_TIME");
		jObjPricePublishTime.put("value", "14:46:00");
		jObjPricePublishTime.put("unit", "Time");
		jObjPricePublishTime.put("productId", "4");
		jObjPricePublishTime.put("timezoneCode", "WIB");

		JSONObject jObjPriceExpiryTime = new JSONObject();

		jObjPriceExpiryTime.put("standardSettingId", "73");
		jObjPriceExpiryTime.put("name", "PRICE_EXPIRY_TIME");
		jObjPriceExpiryTime.put("value", "23:46:00");
		jObjPriceExpiryTime.put("unit", "Time");
		jObjPriceExpiryTime.put("productId", "4");
		jObjPriceExpiryTime.put("timezoneCode", "WIB");

		JSONObject jObjRecurringPeriod = new JSONObject();

		jObjRecurringPeriod.put("standardSettingId", "74");
		jObjRecurringPeriod.put("name", "RECURRING_PERIOD");
		jObjRecurringPeriod.put("value", "7");
		jObjRecurringPeriod.put("unit", "Days");
		jObjRecurringPeriod.put("productId", "4");

		JSONArray jArrStdDailyPrice = new JSONArray();

		jArrStdDailyPrice.put(jObjDropOffStartTime);
		jArrStdDailyPrice.put(jObjDropOffEndTime);
		jArrStdDailyPrice.put(jObjPricePublishTime);
		jArrStdDailyPrice.put(jObjPriceExpiryTime);
		jArrStdDailyPrice.put(jObjRecurringPeriod);

		System.out.println(jArrStdDailyPrice);
		return jArrStdDailyPrice;

	}

	public JSONObject getJsonForCommodityBasePrice() throws JSONException {
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		JSONObject jObjLocalWeightUom = new JSONObject();

		jObjLocalWeightUom.put("uomId", 1);
		jObjLocalWeightUom.put("name", "Kilogram");
		jObjLocalWeightUom.put("measurementUnit", "Kg");
		jObjLocalWeightUom.put("conversionToKG", 1);

		JSONObject jObjCommodityBasePrice = new JSONObject();

		jObjCommodityBasePrice.put("productId", 4);
		jObjCommodityBasePrice.put("basisPrice", 3100);
		jObjCommodityBasePrice.put("lastSavedDate", timestamp.getTime());
		jObjCommodityBasePrice.put("localCurrencyCode", "IDR");
		jObjCommodityBasePrice.put("localWeightUOM", jObjLocalWeightUom);

		System.out.println(jObjCommodityBasePrice);

		return jObjCommodityBasePrice;

	}

	public JSONObject getJsonForTradProdBasePrice() throws JSONException {
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		Date today = Calendar.getInstance().getTime();

		long epochTime = today.getTime();
		JSONObject jObjLocalWeightUom = new JSONObject();

		jObjLocalWeightUom.put("uomId", 1);
		jObjLocalWeightUom.put("name", "Kilogram");
		jObjLocalWeightUom.put("measurementUnit", "Kg");
		jObjLocalWeightUom.put("conversionToKG", 1);

		JSONObject jObjRefBasePrice = new JSONObject();

		jObjRefBasePrice.put("productId", 4);
		jObjRefBasePrice.put("basisPrice", 3100);
		jObjRefBasePrice.put("lastSavedDate", epochTime);
		jObjRefBasePrice.put("localWeightUOM", jObjLocalWeightUom);

		Map<String, Integer> hmTradProd = getTradProdList(URL_ACTIVE_TRAD_PROD, "");
		List<String> lst = new ArrayList<String>(hmTradProd.keySet());
		int noOfTradProds = hmTradProd.size();
		System.out.println(noOfTradProds);
		JSONArray jArrTradProdBasePrice = new JSONArray();
		JSONObject jObjTradProd[] = new JSONObject[noOfTradProds];
		for (int i = 0; i < noOfTradProds; i++) {

			System.out.println("index: " + i);
			jObjTradProd[i] = new JSONObject();
			jObjTradProd[i].put("basisPrice", 2000);
			jObjTradProd[i].put("checked", "true");
			jObjTradProd[i].put("name", lst.get(i));
			jObjTradProd[i].put("savedTimestamp", timestamp.getTime());
			jObjTradProd[i].put("tradingProductId", hmTradProd.get(lst.get(i)));

			jArrTradProdBasePrice.put(jObjTradProd[i]);
		}

		JSONObject jObjOuterTradProdBasePrice = new JSONObject();

		jObjOuterTradProdBasePrice.put("productId", 4);
		jObjOuterTradProdBasePrice.put("basisPrice", jObjRefBasePrice);
		jObjOuterTradProdBasePrice.put("tradingProductBasisPrices", jArrTradProdBasePrice);

		System.out.println(jObjOuterTradProdBasePrice);

		return jObjOuterTradProdBasePrice;

	}

	public JSONObject getJsonForPublishPrice() throws JSONException {
		JSONArray jArrTradProdList = new JSONArray();

		jArrTradProdList.put(3);
		jArrTradProdList.put(4);

		JSONObject jObjCommodity = new JSONObject();

		jObjCommodity.put("productId", 4);
		jObjCommodity.put("tradingProductIdList", jArrTradProdList);

		return jObjCommodity;
	}

	public JSONObject getJsonForCommodityMappedToFl(String displayFarmerLeadId) throws JSONException {
		JSONObject jObjInput = new JSONObject();

		jObjInput.put("pageNumber", 1);
		jObjInput.put("pageSize", 10);
		jObjInput.put("flDisplayId", displayFarmerLeadId);

		return jObjInput;

	}

	public JSONObject getJsonForResetDevice(String loginId, String roleId) throws JSONException {
		JSONObject jObjDevice = new JSONObject();

		jObjDevice.put("loginId", loginId);
		jObjDevice.put("roleId", roleId);

		return jObjDevice;
	}

	public JSONObject getJsonForFarmerPremiumLedgerView(String loginId) throws JSONException {
		JSONObject jObjUserIdSearchInput = new JSONObject();

		jObjUserIdSearchInput.put("country", "ID");
		jObjUserIdSearchInput.put("id", "0016");
		jObjUserIdSearchInput.put("province", "JBBD");
		jObjUserIdSearchInput.put("village", "AJAJ");

		JSONObject jObjFarmerPremium = new JSONObject();

		// jObjFarmerPremium.put("month", 10);
		jObjFarmerPremium.put("year", 2019);
		jObjFarmerPremium.put("userIdSearchInputs", jObjUserIdSearchInput);

		return jObjFarmerPremium;
	}

	public JSONObject getJsonForOriginBasicDetails(String dtFormat, int deciPlaces, String deciSeparator,
			String numSeparator) throws JSONException {
		JSONObject jObjOriginBasicDetails = new JSONObject();

		jObjOriginBasicDetails.put("dateFormat", dtFormat);
		jObjOriginBasicDetails.put("decimalPlaces", deciPlaces);
		jObjOriginBasicDetails.put("decimalSeparator", deciSeparator);
		jObjOriginBasicDetails.put("numberSeparator", numSeparator);

		return jObjOriginBasicDetails;
	}

	public JSONObject getJsonForFarmerLedgerSearch() throws JSONException {
		JSONArray jArrProduct = new JSONArray();
		jArrProduct.put(1);
		jArrProduct.put(2);
		jArrProduct.put(3);
		jArrProduct.put(4);
		jArrProduct.put(6);
		jArrProduct.put(8);
		jArrProduct.put(9);

		JSONObject jObjFarmerLedgerSearch = new JSONObject();

		// TODO parameterize date, if needed use date interface
		jObjFarmerLedgerSearch.put("fromDate", "2019-10-01");
		jObjFarmerLedgerSearch.put("toDate", "2019-10-09");
		jObjFarmerLedgerSearch.put("pageNumber", 0);
		jObjFarmerLedgerSearch.put("pageSize", 10);
		jObjFarmerLedgerSearch.put("productId", jArrProduct);
		jObjFarmerLedgerSearch.put("farmerDisplayId", "id-jbbd-ajaj-0016");

		return jObjFarmerLedgerSearch;
	}

}
