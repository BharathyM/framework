package com.olamnet.farmer.objectrepository;

import java.util.List;

import com.olamnet.farmer.utilities.AppiumUtil;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class MyFarmerLeadRepo extends AbstractRepository {

	public static MyFarmerLeadRepo inst_MyFarmerLeadRepo = null;

	public MyFarmerLeadRepo(AndroidDriver driver) {
		super(driver);
	}

	public static MyFarmerLeadRepo getInstance() {
		if (inst_MyFarmerLeadRepo == null)
			inst_MyFarmerLeadRepo = new MyFarmerLeadRepo(AppiumUtil.driver);
		return inst_MyFarmerLeadRepo;
	}

	
	@AndroidFindBy(xpath = "//*[contains(@text,'My Farmer Leads')]")
	public AndroidElement optioninMenu;	
	
	@AndroidFindBy(xpath = "//*[@text='My Farmer Leads']")
	public AndroidElement TitleTxt;	
	
	@AndroidFindBy(xpath = "//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*")
	public List<AndroidElement> NoOfFLCards;		

	@AndroidFindBy(xpath = "//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*/*")
	public AndroidElement FLCardTxt;	
	
	@AndroidFindBy(xpath = "//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*/*/*[1]")
	public AndroidElement FLImage;
	
	@AndroidFindBy(xpath = "//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*/*/*[2]")
	public AndroidElement FLNameTxt;
	
	@AndroidFindBy(xpath = "//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*/*/*[3]")
	public AndroidElement FLoansTxt;
	
	@AndroidFindBy(xpath = "//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*/*/*[4]")
	public AndroidElement FLWhatsAppIcon;
	
	@AndroidFindBy(xpath = "//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*/*/*[5]")
	public AndroidElement FLCallIcon;
	
	@AndroidFindBy(xpath = "//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*/*/*[6]")
	public AndroidElement FLAddressTxt;
	
	@AndroidFindBy(xpath = "//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*/*/*[8]")
	public AndroidElement FLCommodityTxt;
	

	
	
	//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*[1]/*/*[1]   image
	//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*[1]/*/*[2]   name
	//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*[1]/*/*[3]   loantext
	//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*[1]/*/*[4]   whatsapp link
	//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*[1]/*/*[5]   helpline icon
	//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*[1]/*/*[6]   addressTxt
	//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*[1]/*/*[7]   1st commd image
	//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*[1]/*/*[8]    2nd commd
	//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*[1]/*/*[9]    3commd
	//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*[1]/*/*[10]    4commod

	//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*[1]/*/*[7]/following-sibling::*   commodity Txt

	@AndroidFindBy(xpath = "//*[@text='Error']/../following-sibling::*/following-sibling::*/following-sibling::*")
	public AndroidElement whatsAppPopupMsg;	
	
	@AndroidFindBy(xpath = "//*[@text='Ok']")
	public AndroidElement whatsAppOkbtn;	
	
	@AndroidFindBy(xpath = "//*[@text='Error']")
	public AndroidElement whatsappErrorPopupHText;	
	
	@AndroidFindBy(xpath = "//*[@text='CALL']")
	public AndroidElement callPopupTxt;	
	
	@AndroidFindBy(xpath = "//*[@text='CALL']/../following-sibling::*/following-sibling::*")
	public AndroidElement callPopupMsgText;	
	
	@AndroidFindBy(xpath = "//*[@text='CALL']/following-sibling::*/*")
	public AndroidElement clsBtnCallPopup;		


	
	
	
}
