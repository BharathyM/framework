package com.olamnet.farmer.utilities;

import static java.lang.Thread.sleep;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.cucumber.listener.Reporter;

import groovy.time.Duration;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.touch.offset.PointOption;
//import io.appium.java_client.touch.offset.ElementOption;
//import io.appium.java_client.touch.offset.PointOption;



public class ActionItems extends BaseStepAction {

	public static ActionItems inst_ActionItems = null;
	AndroidDriver driver;

	private ActionItems(AndroidDriver driver) {
		this.driver = driver;
	}

	public static ActionItems getInstance() {
		if (inst_ActionItems == null)
			inst_ActionItems = new ActionItems(AppiumUtil.driver);
		return inst_ActionItems;
	}

	// Click Action
	public void clickAction(WebElement element) {
		waitAction(element, 40);
		element.click();
		waitForProgressBar();
	}

	// View Action
		public boolean isDisplayedAction(WebElement element) {
			try {
				waitAction(element, 10);
				element.isDisplayed();
				return true;
			} catch (Exception e) {
				getActionItemsInstance().reportStepLog("No such element is displayed " + e.getMessage());
				return false;
			}
		}

		public boolean isDisplayedAction(String elementText, WebElement element) {
			try {
				waitAction(element, 10);
				element.isDisplayed();
				getActionItemsInstance().reportStepLog(elementText + " is displayed");
				return true;
			} catch (NoSuchElementException e) {
				getActionItemsInstance().reportStepLog(elementText + " - No such element is displayed " + e.getMessage());
				return false;
			}
		}

	// SendKeys Action
	public void sendKeysAction(WebElement element, String value) {
		waitAction(element, 25);
		element.sendKeys(value);
	}
	//Login OTP
	public void sendKeysOTP(String otp)
	{
	  char array[]= otp.toCharArray();
	 // WebElement ele=driver.findElementByXPath("(//*[@class='android.view.ViewGroup' and ./parent::*[@id='OTPInputView']]/*[@id='inputSlotView'])[1]");	
		//clickAction(ele);
	for (int i=1;i<=otp.length();i++)
	{
		//AppiumUtil.driver.findElementById("et"+i).sendKeys(String.valueOf(array[i-1]));			
		AppiumUtil.driver.findElementByXPath("(//*[@class='android.view.ViewGroup' and ./parent::*[@id='OTPInputView']]/*[@id='inputSlotView'])["+ i +"]").sendKeys(String.valueOf(array[i-1]));
	}
}

	// Clear element
	public void clearAction(WebElement element) {
		element.clear();
	}

	// Explicit Wait Action
	public void waitAction(WebElement element, int seconds) {
		new WebDriverWait(AppiumUtil.driver, seconds).until(ExpectedConditions.visibilityOf(element)).isDisplayed();
	}

	// ToastWait
	public void waitToastAction(AndroidElement element, int seconds) {
		new WebDriverWait(driver, seconds).until(ExpectedConditions.visibilityOf(element)).isDisplayed();
	}

	// Enabled Action
	public boolean isEnabledAction(WebElement element) {
		return element.isEnabled();
	}

	// Wait Until Element is clikable
	public void waitUntilElementClickable(WebElement element, int seconds) {
		new WebDriverWait(AppiumUtil.driver, seconds).until(ExpectedConditions.elementToBeClickable(element))
				.isDisplayed();
	}

	// Selected Action
	public boolean isSelectedAction(WebElement element) {
		return element.isSelected();
	}

	// Sleep Action
	public void sleepAction(int milliSeconds) {
		try {
			sleep(milliSeconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// Wait for Progress bar
	public void waitForProgressBar() {
		try {
			Thread.sleep(300);
		} catch (Exception e) {

		}
		if (getActionItemsInstance().getSizeOfElementByClass("android.widget.ProgressBar") > 0) {
			new WebDriverWait(AppiumUtil.driver, 180)
					.until(ExpectedConditions.invisibilityOfElementLocated(By.className("android.widget.ProgressBar")));
		}
	}

	// Verify validation message
	public void verifyValidationMessage(String message) {
		waitForProgressBar();

		try {
			String xmlFormat = driver.getPageSource();
			Thread.sleep(200);
			String xmlFormat1 = driver.getPageSource();
			Thread.sleep(100);
			String xmlFormat2 = driver.getPageSource();
			Thread.sleep(200);
			String xmlFormat3 = driver.getPageSource();
			Thread.sleep(100);
			String xmlFormat4 = driver.getPageSource();
			if (xmlFormat.contains(message) || xmlFormat1.contains(message) || xmlFormat2.contains(message)
					|| xmlFormat3.contains(message) || xmlFormat4.contains(message)) {
				getActionItemsInstance().reportStepLog("Validation message exists");
			}
			// org.junit.Assert.assertThat(xmlFormat, CoreMatchers.containsString(message));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// Verify Invisibility of an element
	public static ExpectedCondition<Boolean> invisibilityOfElementLocated(final By locator) {
		return new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				try {
					return !(driver.findElement(locator).isDisplayed());
				} catch (NoSuchElementException e) {
					// Returns true because the element is not present in DOM. The
					// try block checks if the element is present but is invisible.
					return true;
				} catch (StaleElementReferenceException e) {
					// Returns true because stale element reference implies that element
					// is no longer visible.
					return true;
				}
			}

		};
	}

	// Return size of element - By ID
	public int getSizeOfElementById(String elementID) {
		int size = AppiumUtil.driver.findElementsById(elementID).size();
		return size;
	}

	// Return size of element - By ID
	public int getSizeOfElementByClass(String elementID) {
		int size = AppiumUtil.driver.findElementsByClassName(elementID).size();
		return size;
	}

	// Return size of element - By Xpath
	public int getSizeOfElementByXpath(String xpath) {
		int size = AppiumUtil.driver.findElementsByXPath(xpath).size();
		return size;
	}

	// Step log
	public void reportStepLog(String message) {
		Reporter.addStepLog(message);
	}

	// Get text
	public String getTextAction(AndroidElement element) {
		return element.getText();
	}

	// Allow permission
	public void allowPermission(AndroidElement element) {
		if (element.getText().equals("1 of 3")) {
			for (int i = 0; i < 3; i++) {
				clickAction(getAndroidRepoInstance().permissionAllow);
			}
		} else if (element.getText().equals("1 of 2")) {
			for (int i = 0; i < 2; i++) {
				clickAction(getAndroidRepoInstance().permissionAllow);
			}
		} else if (element.getText().equals("1 of 1")) {
			for (int i = 0; i < 1; i++) {
				clickAction(getAndroidRepoInstance().permissionAllow);
			}
		}
	}
	
	//error popup
		public void acceptError(){				
			getActionItemsInstance().addLogWithScreenShot("Error Popup");
			getActionItemsInstance().reportStepLog(""+getMyAccountRepoInstance().errorPopupTextMsg);
			getActionItemsInstance().clickAction(getMyAccountRepoInstance().okBtnPopup);
		}

	// Scroll down
	public void scrollDownView(String elementID) {

		int pressX = AppiumUtil.driver.manage().window().getSize().width / 2;

		int bottomY = AppiumUtil.driver.manage().window().getSize().height * 4 / 5;

		int topY = AppiumUtil.driver.manage().window().getSize().height / 8;

		int i = 0;
		boolean isPresent;

		do {

			isPresent = AppiumUtil.driver.findElements(By.id(elementID)).size() > 0;
			if (isPresent) {
				AppiumUtil.driver.findElement(By.id(elementID)).isDisplayed();
				break;
			} else {
				scroll(pressX, bottomY, pressX, topY);
				if (AppiumUtil.driver.findElementsById(elementID).size() > 0) {
					new WebDriverWait(AppiumUtil.driver, 30)
							.until(ExpectedConditions.presenceOfElementLocated(By.id(elementID))).isDisplayed();
				}
				getActionItemsInstance().reportStepLog("Element not identified, so scroll for " + i + " time");
			}
			i++;

		} while (i <= 6);
	}

	// Scroll down - By Xpath
	public void scrollDownViewByXpath(String elementXpath) {

		Dimension size = AppiumUtil.driver.manage().window().getSize();

		int pressX = size.width / 2;

		int bottomY = (int) (size.height * 0.8);

		int topY = (int) (size.height * 0.2);

		int i = 0;
		boolean isPresent;
		do {
			isPresent = AppiumUtil.driver.findElements(By.xpath(elementXpath)).size() > 0;
			if (isPresent) {
				AppiumUtil.driver.findElement(By.xpath(elementXpath)).isDisplayed();
				break;
			} else {
				scroll(pressX, bottomY, pressX, topY);
				if (AppiumUtil.driver.findElementsByXPath(elementXpath).size() > 0) {
					new WebDriverWait(AppiumUtil.driver, 30)
							.until(ExpectedConditions.presenceOfElementLocated(By.xpath(elementXpath))).isDisplayed();
				}
				getActionItemsInstance().reportStepLog("Element not identified, so scroll for " + i + " time");
			}
			i++;
		} while (i <= 6);
	}

	// ScrollUp
	public void scrollUpView(String elementID) {

		int pressX = driver.manage().window().getSize().width / 2;

		int bottomY = driver.manage().window().getSize().height * 4 / 5;

		int topY = driver.manage().window().getSize().height / 8;

		int i = 0;
		boolean isPresent;

		do {

			isPresent = driver.findElements(By.id(elementID)).size() > 0;
			if (isPresent) {
				driver.findElement(By.id(elementID)).isDisplayed();
				break;
			} else {
				scroll(pressX, topY, pressX, bottomY);
				if (driver.findElementsById(elementID).size() > 0) {
					new WebDriverWait(driver, 30).until(ExpectedConditions.presenceOfElementLocated(By.id(elementID)))
							.click();
				}
				getActionItemsInstance().reportStepLog("Element not identified, so scroll for " + i + " time");
			}
			i++;

		} while (i <= 6);
	}

	// Scroll up - By Xpath
	public void scrollUpViewByXpath(String elementXpath) {

		int pressX = AppiumUtil.driver.manage().window().getSize().width / 2;

		int bottomY = AppiumUtil.driver.manage().window().getSize().height * 4 / 5;

		int topY = AppiumUtil.driver.manage().window().getSize().height / 8;
		getActionItemsInstance().reportStepLog("x, topy, x, bottomy" + pressX + topY + pressX + bottomY);

		int i = 0;
		boolean isPresent;
		do {
			isPresent = AppiumUtil.driver.findElements(By.xpath(elementXpath)).size() > 0;
			if (isPresent) {
				AppiumUtil.driver.findElement(By.xpath(elementXpath)).isDisplayed();
				break;
			} else {
				scroll(pressX, topY, pressX, bottomY);
				if (AppiumUtil.driver.findElementsByXPath(elementXpath).size() > 0) {
					new WebDriverWait(AppiumUtil.driver, 30)
							.until(ExpectedConditions.presenceOfElementLocated(By.xpath(elementXpath))).isDisplayed();
				}
				getActionItemsInstance().reportStepLog("Element not identified, so scroll for " + i + " time");
			}
			i++;
		} while (i <= 6);
	}
	
	

	// Scroll
	public void scroll(int fromX, int fromY, int toX, int toY) {
		TouchAction touchAction = new TouchAction(AppiumUtil.driver);
		try {

		} catch (WebDriverException wd) {
		}
		touchAction.longPress(new PointOption().withCoordinates(fromX, fromY))
				.moveTo(new PointOption().withCoordinates(toX, toY)).release().perform();
	}
	
	
	public void touchandScroll()
	{
	
	TouchActions action = new TouchActions(driver);
	action.scroll( 10, 100);
	action.perform();

	}




	// Scroll down
	public void scrollDownViewSurvey(String elementID) {

		int pressX = AppiumUtil.driver.manage().window().getSize().width / 2;

		int bottomY = AppiumUtil.driver.manage().window().getSize().height * 4 / 5;

		int topY = AppiumUtil.driver.manage().window().getSize().height / 8;

		int i = 0;
		boolean isPresent;

		do {

			isPresent = AppiumUtil.driver.findElements(By.id(elementID)).size() > 0;
			if (isPresent) {
				AppiumUtil.driver.findElement(By.id(elementID)).isDisplayed();
				break;
			} else {
				scroll(pressX, bottomY, pressX, topY);
				if (driver.findElementsById(elementID).size() > 0) {
					new WebDriverWait(driver, 30).until(ExpectedConditions.presenceOfElementLocated(By.id(elementID)))
							.isDisplayed();
				}
				// getActionItemsInstance().reportStepLog("Element not identified, so scroll for
				// " +i+" time");
			}
			i++;

		} while (i <= 6);
	}

	// Report log with screen shot
	public void addLogWithScreenShot(String message) {
		getActionItemsInstance().reportStepLog(message);
		getScreenshot(AppiumUtil.driver);
	}

	// Attach screenshot
	public void getScreenshot(WebDriver driver) {
		String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String destination = System.getProperty("user.dir") + "/test-output/" + "screenshot" + dateName + ".png";
		File finalDestination = new File(destination);
		try {
			FileUtils.copyFile(source, finalDestination);
			Reporter.addScreenCaptureFromPath(
					System.getProperty("user.dir") + "/test-output/" + "screenshot" + dateName + ".png");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void captureScreenshot(String path) {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			String filePath = path + "\\toastmessage1.png";
			FileUtils.copyFile(scrFile, new File(filePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void newScrollDown(WebElement element) {
		boolean found = false;
		while (!found) {
			try {
				element.getText();
				found = true;
			} catch (Exception e) {
				Dimension size = driver.manage().window().getSize();
				int startx = size.width / 2;
				int starty = (int) (size.height * 0.9);
				int endy = (int) (size.height * 0.5);
				scroll(startx, starty, startx, endy);
			}
		}
	}

	public void newScrollUp(WebElement element) {
		boolean found = false;
		while (!found) {
			try {
				element.getText();
				found = true;
			} catch (Exception e) {
				Dimension size = driver.manage().window().getSize();
				int startx = size.width / 2;
				int starty = (int) (size.height * 0.5);
				int endy = (int) (size.height * 0.9);
				scroll(startx, starty, startx, endy);
			}
		}
	}

	public void BackUntilElementFound(WebElement element) {
		boolean found = false;
		while (!found) {
			try {
				element.getText();
				found = true;
			} catch (Exception e) {
				driver.pressKey(new KeyEvent(AndroidKey.BACK));
			}
		}
	}

	// Screen Navigation

	public void assertTitle(WebElement ele) {
		waitForProgressBar();
		waitAction(ele, 25);
		Assert.assertTrue(isDisplayedAction(ele));
	}

	// Scroll to the element and click using UIAutomator
	public void scrollAndClick(String visibleText) {
		try {
			AppiumUtil.driver.findElementByAndroidUIAutomator(
					"new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""
							+ visibleText + "\").instance(0))")
					.click();
			waitForProgressBar();
			getActionItemsInstance().reportStepLog("Clicked on element with text: " + visibleText);
		} catch (NoSuchElementException e) {
			getActionItemsInstance()
					.reportStepLog("Unable to scroll and click on the element with text : " + visibleText);
		}
	}

	// Select by visible Text
	public void selectByVisibleText(WebElement ele, String value) {
		try {

			getActionItemsInstance().clickAction(ele);
			WebElement wb = AppiumUtil.driver.findElementByXPath("//*[contains(@text,'" + value + "')]");
			getActionItemsInstance().clickAction(wb);
			getActionItemsInstance().reportStepLog("Element is selected from the dropdown by text : " + value);
		} catch (WebDriverException e) {
			getActionItemsInstance().reportStepLog("Unable to select element from the dropdown by text : " + value);
		}

	}

	// Click by visible Text
	public void clickByVisibleText(String value) {
		try {

			WebElement wb = AppiumUtil.driver.findElementByXPath("//*[contains(@text,'" + value + "')]");
			getActionItemsInstance().clickAction(wb);
			getActionItemsInstance().waitForProgressBar();
			getActionItemsInstance().reportStepLog("Element is clicked based on text value: " + value);
		} catch (WebDriverException e) {
			getActionItemsInstance().reportStepLog("Unable to click element based on text value: " + value);
		}

	}

	// Scroll to the element using UIAutomator
	public void scrollUntilVisibleText(String visibleText) {
		try {
			AppiumUtil.driver.findElementByAndroidUIAutomator(
					"new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""
							+ visibleText + "\").instance(0))");
		} catch (NoSuchElementException e) {
			getActionItemsInstance().reportStepLog("Unable to scroll to the element with text : " + visibleText);

		}
	}

	// Verify if certain string matches any of the array items

	public boolean stringContainsItemFromList(String inputStr, List<String> allCommodities) {
		return allCommodities.parallelStream().anyMatch(inputStr::contains);
	}

	// Select date from calendar

	public void selectDate(String dateString) {
		LocalDate date = LocalDate.parse(dateString, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
		String fmtDate = DateTimeFormatter.ofPattern("d-MMMM-yyyy").format(date);
		getActionItemsInstance().reportStepLog("Given date is: " + dateString + " formatted date is: " + fmtDate);

		String dd = fmtDate.split("-")[0];
		String month = fmtDate.split("-")[1];
		String year = fmtDate.split("-")[2];
		WebElement wbYear = AppiumUtil.driver.findElementByXPath("//*[@text='" + year + "']");
		WebElement wbDate = AppiumUtil.driver.findElementByXPath("//*[@text='" + dd + "']");

		getActionItemsInstance().clickAction(wbYear);
		getActionItemsInstance().reportStepLog(year + " Year is selected");
		selectMonth(month);
		getActionItemsInstance().clickAction(wbDate);
		getActionItemsInstance().reportStepLog(dd + " Date is selected");

	}

	public void selectMonth(String month) {
		boolean found = false;
		boolean isPresent;
		do {
			try {
				isPresent = AppiumUtil.driver.findElementsByXPath("//*[@text='" + month + "']").size() > 0;
				if (isPresent == true) {
					found = true;
					getActionItemsInstance()
							.clickAction(AppiumUtil.driver.findElementByXPath("//*[@text='" + month + "']"));
					getActionItemsInstance().reportStepLog(month + " Month is selected");
				}

				else
					getActionItemsInstance().clickAction(getAndroidRepoInstance().btnPrevMonth);

			} catch (Exception e) {
				e.printStackTrace();
			}
		} while (found = false);

	}

	public void uploadImage() {

		getActionItemsInstance().clickAction(getSingupRepoInstance().cameraSelect);
		getActionItemsInstance().clickAction(getSingupRepoInstance().camerClickbtn);
		//keyEvent(27);
		//keyEvent(24);
		try {
			getActionItemsInstance().clickAction(getSingupRepoInstance().picOkbtn);
		} catch (Exception e) {
			e.printStackTrace();
		}
		waitForProgressBar();
		getActionItemsInstance().reportStepLog("Image uploaded successfuly");
	}

	public void verifyText(String actualText, String expectedText) {
		try {
			if (expectedText.equals(actualText)) {
				getActionItemsInstance()
						.reportStepLog("Actual text " + actualText + " is matched with expected text: " + expectedText);
			} else {
				getActionItemsInstance().reportStepLog(
						"Actual text " + actualText + " is not matched with expected text: " + expectedText);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void assertText(String actualText, String expectedText) {
		// assert.assertTrue(expectedText.equals(expectedText), "Text not matched");

	}

	/**
	 * Produces a random number based on the no of digits given as input
	 * 
	 * @param n
	 *            - no of digits
	 * @return the random no generated between the lower bound inclusive and upper
	 *         bound exlcusive
	 */
	public long getRandomNumber(int n) {
		long min = (long) Math.pow(10, n - 1);
		return ThreadLocalRandom.current().nextLong(min, min * 10);
	}

	public void keyEvent(int keyCodeNumber) {
		try {
			Runtime.getRuntime().exec("cmd /C adb shell input keyevent " + keyCodeNumber);
			Thread.sleep(3000);
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	public String epochToDate(String epochDateTime) {
		LocalDateTime date = LocalDateTime.ofInstant(Instant.ofEpochMilli(Long.parseLong(epochDateTime)),
				ZoneOffset.UTC);
		String fmtDate = DateTimeFormatter.ofPattern("dd-MM-yyyy").format(date);
		System.out.println(fmtDate);
		return fmtDate;
	}

	public void waitForInvisibilityOfErrorPopup() {
		if (getHomeRepoInstance().txtSomethingWentWrong.size() > 0) {
			getActionItemsInstance().addLogWithScreenShot("Something went wrong / Error popup appears");
			new WebDriverWait(AppiumUtil.driver, 1)
					.until(ExpectedConditions.invisibilityOf(getHomeRepoInstance().txtSomethingWentWrong.get(0)));
		}
	}

	public void acceptErrorPopup() {
		if (getHomeRepoInstance().txtSomethingWentWrong.size() > 0) {
			getActionItemsInstance().reportStepLog("Something went wrong / Error popup appears");
			getActionItemsInstance().clickAction(getAndroidRepoInstance().btnOk);
			new WebDriverWait(AppiumUtil.driver, 1)
					.until(ExpectedConditions.invisibilityOf(getHomeRepoInstance().txtSomethingWentWrong.get(0)));
			getActionItemsInstance().reportStepLog("Something went wrong / Error popup disappeared");
		}
	}

	public void launchCurrentApp() {
		Activity activity = new Activity(AppiumUtil.BASE_PKG, "com.olam.activities.SplashScreen");
		activity.setAppWaitActivity("com.olam.activities.MainActivity,com.olam.activities.LoginActivity");
		AppiumUtil.driver.startActivity(activity);
	}

	public void reLaunchCurrentApp() {
		AppiumUtil.driver.closeApp();
		launchCurrentApp();
	}

	public String getAppVersionName(String packageName) {
		String cmd = "adb shell dumpsys package " + packageName + " |grep versionName";
		Process process = null;
		String appVersion = "";
		try {
			process = Runtime.getRuntime().exec(cmd);
			appVersion = new BufferedReader(new InputStreamReader(process.getInputStream())).readLine();
			System.out.println("appVersion = " + appVersion);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return appVersion;
	}

	public String getAppVersionCode(String packageName) {
		String cmd = "adb shell dumpsys package " + packageName + " |grep versionCode";
		Process process = null;
		String appVersionCode = "";
		try {
			process = Runtime.getRuntime().exec(cmd);
			appVersionCode = new BufferedReader(new InputStreamReader(process.getInputStream())).readLine();
			System.out.println("App Version Code = " + appVersionCode);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return appVersionCode;
	}

	public void reInstallApp(String packageName) {
		AppiumUtil.driver.removeApp(packageName);
		String appPath = System.getProperty("user.dir") + "/src/test/resources/" + AppiumUtil.APPLICATION_NAME;
		AppiumUtil.driver.installApp(appPath);
		getActionItemsInstance().launchCurrentApp();
	}
	
	//Scroll in all directions 
	
	public enum DIRECTION {
	    DOWN, UP, LEFT, RIGHT;
	}
	
	public void swipe( DIRECTION direction) {
	    Dimension size = driver.manage().window().getSize();

	    int startX = 0;
	    int endX = 0;
	    int startY = 0;
	    int endY = 0;

	    switch (direction) {
	        case RIGHT:
	            startY = (int)(size.height / 2);
	            startX = (int) (size.width * 0.90);
	            endX =  (int) (size.width * 0.05);
	            new TouchAction(driver).tap(PointOption.point(startY, endY)).waitAction().moveTo(PointOption.point(endY, startY)).release().perform();       
	                      
	            break;

	        case LEFT:
	            startY = (int) (size.height / 2);
	            startX = (int) (size.width * 0.05);
	            endX = (int) (size.width * 0.90);
	            new TouchAction(driver).tap(PointOption.point(startX, startY)).waitAction().moveTo(PointOption.point(endX, startY)).release().perform();       
	                   	            break;

	        case UP:
	            endY = (int) (size.height * 0.70);
	            startY = (int) (size.height * 0.30);
	            startX = (size.width / 2);
	            new TouchAction(driver).tap(PointOption.point(startX, startY)).waitAction().moveTo(PointOption.point(endX, startY)).release().perform();       
	                  
	            break;


	        case DOWN:
	            startY = (int) (size.height * 0.70);
	            endY = (int) (size.height * 0.30);
	            startX = (size.width / 2);
	            new TouchAction(driver).tap(PointOption.point(startX, startY)).waitAction().moveTo(PointOption.point(startX, endY)).release().perform();       
	            

	            break;

	    }
	}
}