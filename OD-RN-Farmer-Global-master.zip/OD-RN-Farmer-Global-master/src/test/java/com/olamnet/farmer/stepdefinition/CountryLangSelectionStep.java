package com.olamnet.farmer.stepdefinition;

import static org.testng.Assert.assertTrue;

import com.cucumber.listener.Reporter;
import com.olamnet.farmer.utilities.BaseStepAction;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CountryLangSelectionStep extends BaseStepAction {
	@Given("^the user launches the farmer app$")
	public void the_user_launches_the_farmer_app() throws Throwable {
		getActionItemsInstance().reportStepLog("The user launches the farmer app");
	}

	@Then("^country and language and commodity are selected \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\"$")
	public void country_and_language_are_selected(String origin,String lang,String Commodity) throws Throwable {		
		//if(getAndroidRepoInstance().permissionpopupBytext1.isDisplayed())		{
		getCountryLangActionInstance().allowPermissions();
		getActionItemsInstance().reportStepLog("User could allow the App permission ");
		//}						
		getCountryLangActionInstance().selectOriginLang(origin,lang,Commodity);
		getActionItemsInstance().reportStepLog("User could seleted the Origin and language and commodity ");
	}

	@Then("^verify if the user is navigated to login screen$")
	public void verify_if_the_user_is_navigated_to_login_screen() throws Throwable {
		getActionItemsInstance().waitAction(getLoginRepoInstance().labelTxt, 30);
		assertTrue(getLoginRepoInstance().labelTxt.isDisplayed());
	}

}
