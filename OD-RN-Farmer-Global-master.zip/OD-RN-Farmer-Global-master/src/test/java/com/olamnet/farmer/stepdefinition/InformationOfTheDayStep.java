package com.olamnet.farmer.stepdefinition;

import java.util.stream.Stream;

import org.openqa.selenium.WebElement;

import com.cucumber.listener.Reporter;
import com.olamnet.farmer.utilities.BaseStepAction;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class InformationOfTheDayStep extends BaseStepAction {

	@Given("^the user is on news and info screen$")
	public void the_user_is_on_news_and_info_screen() throws Throwable {
		getActionItemsInstance().clickAction(getAndroidRepoInstance().imgHomeMenu);		
		getActionItemsInstance().clickAction(getHomeRepoInstance().btnHome);
		getActionItemsInstance().waitForProgressBar();		
		getActionItemsInstance().clickAction(getInformationOfTheDayRepoInstance().newsInfoBottomOpt);
		getActionItemsInstance().waitForProgressBar();
		getActionItemsInstance().verifyText(getInformationOfTheDayRepoInstance().newsInfoTitleTxt.getText(), "News & Info");
	}

	@Then("^verify the UI elements in news and info screen$")
	public void verify_the_UI_elements_in_news_and_info_screen() throws Throwable {
		
		getNewsInfoActionInstance().verifyNewsInfoUI();
		/*Stream.of(getInformationOfTheDayRepoInstance().currentDate, getAndroidRepoInstance().imgHelpline,
				getInformationOfTheDayRepoInstance().iodCard.get(0)).forEach(WebElement::isDisplayed);

		for (int i = 0; i < getInformationOfTheDayRepoInstance().iodCard.size(); i++) {
			// TODO Inconsistent
			// String categoryType =
			// getInformationOfTheDayRepoInstance().categoryType.get(0).getText();
			getActionItemsInstance().clickAction(getInformationOfTheDayRepoInstance().iodCard.get(i));
			// getActionItemsInstance().verifyText(getAndroidRepoInstance().txtTitle.getText(),
			// categoryType);
			//getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNavigateUp);
		}

		getActionItemsInstance().reportStepLog("Iod UI elements verified");*/

	}

}
