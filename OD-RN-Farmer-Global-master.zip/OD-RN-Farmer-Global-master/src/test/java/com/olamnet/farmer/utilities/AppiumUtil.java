package com.olamnet.farmer.utilities;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;
import java.util.concurrent.TimeUnit;


import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;


public class AppiumUtil {
	private static Properties appiumProp = new Properties();
	private static Properties runConfigProp = new Properties();
	public static int EXPLICIT_WAIT_TIME;
	public static int IMPLICIT_WAIT_TIME;
	public static int DEFAULT_WAIT_TIME;
	public static String APPLICATION_NAME;
	public static String BASE_PKG;
	public static String APP_ACTIVITY;
	public static String APPIUM_PORT;
	public static String AUTOMATION_INSTRUMENTATION;
	public static String BROWSER_NAME;
	public static String PLATFORM_NAME;
	public static String NEW_COMMAND_TIMEOUT;
	public static String PLATFORM_VERSION;
	public static String DEVICE_READY_TIMEOUT;
	public static String DEVICE_NAME;
	public static String DEVICE_UDID;
	public static String AUTO_WEBVIEW;
	public static String FULL_RESET_VALUE;
	public static String NO_RESET_VALUE;
	public static long originId;
	public static String ServerInstallTimeout;
	public static String origin;
	public static String farmerLeadId;
	public static String farmerId;
	public static String baseUrl;
	public static String dbType;
	public static String hostNameOrIPAddress;
	public static String portNumber;
	public static String dbNameGlobal;
	public static String dbNameNonGlobal;
	public static String dbUserName;
	public static String dbPassword;
	public static String testEnv;
	public static String country;
	public static String lang;
	public static String commodity;
	public static String projectName;
	public static String userId;
	private static DesiredCapabilities capabilities = new DesiredCapabilities();
	private static URL serverUrl;
	@SuppressWarnings("rawtypes")
	public static AndroidDriver driver;
	private static String WAIT_ACTIVITY;

	// Property file loading config
	public static void loadAppiumConfigProp(String propertyFileName) throws IOException {
		appiumProp.load(ClassLoader.getSystemResource(propertyFileName).openStream());
		EXPLICIT_WAIT_TIME = Integer.parseInt(appiumProp.getProperty("explicit.wait"));
		IMPLICIT_WAIT_TIME = Integer.parseInt(appiumProp.getProperty("implicit.wait"));
		DEFAULT_WAIT_TIME = Integer.parseInt(appiumProp.getProperty("default.wait"));
		if ("uat".equals(testEnv)) {
			APPLICATION_NAME = appiumProp.getProperty("uat.application.path");
			BASE_PKG = appiumProp.getProperty("uat.base.pkg");
		}
		if ("sit".equals(testEnv)) {
			APPLICATION_NAME = appiumProp.getProperty("sit.application.path");
			BASE_PKG = appiumProp.getProperty("sit.base.pkg");
		}

		if ("prod".equals(testEnv)) {
			APPLICATION_NAME = appiumProp.getProperty("prod.application.path");
			BASE_PKG = appiumProp.getProperty("prod.base.pkg");
		}
		APP_ACTIVITY = appiumProp.getProperty("application.activity");
		WAIT_ACTIVITY = appiumProp.getProperty("wait.activity");
		APPIUM_PORT = appiumProp.getProperty("appium.server.port");
		AUTOMATION_INSTRUMENTATION = appiumProp.getProperty("automation.instrumentation");
		DEVICE_NAME = appiumProp.getProperty("device.name");
		BROWSER_NAME = appiumProp.getProperty("browser.name");
		PLATFORM_NAME = appiumProp.getProperty("platform.name");
		PLATFORM_VERSION = appiumProp.getProperty("platform.version");
		//AUTO_WEBVIEW=appiumProp.getProperty("autoWebview");		
		NEW_COMMAND_TIMEOUT = appiumProp.getProperty("new.command.timeout");
		DEVICE_READY_TIMEOUT = appiumProp.getProperty("device.ready.timeout");
		FULL_RESET_VALUE = appiumProp.getProperty("full.reset.value");
		NO_RESET_VALUE = appiumProp.getProperty("no.reset.value");
		ServerInstallTimeout=appiumProp.getProperty("uiautomator2ServerInstallTimeout");

	}

	// Capabilities
	public static void setCapabilities() {
		File appDir = new File("src/test/resources/");
		File app = new File(appDir, APPLICATION_NAME);
		capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, AppiumUtil.BROWSER_NAME);
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, AppiumUtil.PLATFORM_NAME);
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, AppiumUtil.DEVICE_NAME);
		capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, AppiumUtil.AUTOMATION_INSTRUMENTATION);
		capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
		//capabilities.setCapability(MobileCapabilityType.AUTO_WEBVIEW, AppiumUtil.AUTO_WEBVIEW);
		capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, AppiumUtil.NEW_COMMAND_TIMEOUT);
		capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, AppiumUtil.DEVICE_READY_TIMEOUT);
		capabilities.setCapability(MobileCapabilityType.UDID, AppiumUtil.DEVICE_UDID);
		capabilities.setCapability("autoGrantPermissions", true);
		capabilities.setCapability(MobileCapabilityType.FULL_RESET, FULL_RESET_VALUE);
		capabilities.setCapability(MobileCapabilityType.NO_RESET, NO_RESET_VALUE);
		capabilities.setCapability("--session-override", true);
		capabilities.setCapability("activity", AppiumUtil.APP_ACTIVITY);
		capabilities.setCapability("package", AppiumUtil.BASE_PKG);
		capabilities.setCapability("appWaitActivity", AppiumUtil.WAIT_ACTIVITY);
		capabilities.setCapability("noSign", "true");
		capabilities.setCapability("uiautomator2ServerInstallTimeout", AppiumUtil.ServerInstallTimeout);
		System.out.println("Capabilities executed");

	}

	public static void setEnvironmentOriginSettings() {
		System.out.println("Country: " + country + " Test Environment: " + testEnv);

		switch (testEnv) {
		case "uat":
			baseUrl = Constants.UAT_BASE_URL;
			dbType = Constants.UAT_DB_TYPE;
			hostNameOrIPAddress = Constants.UAT_HOST_NAME_OR_IP_ADDRESS;
			portNumber = Constants.UAT_PORT_NUMBER;
			dbNameGlobal = Constants.UAT_GLOBAL_DB_NAME;
			dbNameNonGlobal = Constants.UAT_DB_NAME;
			dbUserName = Constants.UAT_DB_USER_NAME;
			dbPassword = Constants.UAT_DB_PASSWORD;
			userId = Constants.UAT_ADMIN_ID;

			switch (country) {
			case "Indonesia":
				
				originId= Constants.INDO_ID;
				lang=Constants.lang_name;
				commodity =Constants.commodity_name;						
				farmerId = Constants.INDO_UAT_Farmer_ID;
				farmerLeadId = Constants.INDO_UAT_FL_ID;
				commodity = Constants.Indo_Cocoa;				
				break;
	
			case "Cambodia":
				originId= Constants.CAMBODIA_ID;
				lang=Constants.lang_name;
				commodity =Constants.commodity_name;
				farmerId = Constants.CAMBODIA_UAT_Farmer_ID;
				farmerLeadId = Constants.CAMBODIA_UAT_FL_ID;
				commodity = Constants.Cambodia_Pepper;
				break;
			case "Turkey":
				originId= Constants.TURKEY_ID;
				lang=Constants.lang_name;
				commodity =Constants.commodity_name;
				farmerId = Constants.TURKEY_UAT_Farmer_ID;
				farmerLeadId = Constants.MOZAMBIQUE_UAT_FL_ID;
				commodity = Constants.Turkey_Commod;
				break;
			case "Vietnam":
				originId= Constants.VIETNAM_ID;
				lang=Constants.lang_name;
				commodity =Constants.commodity_name;
				farmerId = Constants.VIETNAM_UAT_Farmer_ID;
				farmerLeadId = Constants.VIETNAM_UAT_FL_ID;
				commodity = Constants.Vietnam_Cashew;
				break;
			// Not in use currently
			/*
			 * case "Guatemala": originId = Constants.GUATEMALA_ID; farmerId =
			 * Constants.GUATEMALA_UAT_Farmer_ID; break; case "Mozambique": originId =
			 * Constants.MOZAMBIQUE_ID; farmerId = Constants.MOZAMBIQUE_UAT_Farmer_ID;
			 * farmerLeadId = Constants.MOZAMBIQUE_UAT_FL_ID; break; case "Ghana": originId
			 * = Constants.GHANA_ID; farmerId = Constants.GHANA_UAT_Farmer_ID; farmerLeadId
			 * = Constants.GHANA_UAT_FL_ID; break; case "Peru": originId =
			 * Constants.PERU_ID; farmerId = Constants.PERU_UAT_Farmer_ID; farmerLeadId =
			 * Constants.PERU_UAT_FL_ID; break;
			 */

			default:
				System.out.println("Invalid input for country: " + country);
				break;
			}
			break;
		case "sit":
			baseUrl = Constants.SIT_BASE_URL;
			dbType = Constants.SIT_DB_TYPE;
			hostNameOrIPAddress = Constants.SIT_HOST_NAME_OR_IP_ADDRESS;
			portNumber = Constants.SIT_PORT_NUMBER;
			dbNameGlobal = Constants.SIT_GLOBAL_DB_NAME;
			dbNameNonGlobal = Constants.SIT_DB_NAME;
			dbUserName = Constants.SIT_DB_USER_NAME;
			dbPassword = Constants.SIT_DB_PASSWORD;

			switch (country) {
			case "Indonesia":
				origin= Constants.origin_name;
				lang=Constants.lang_name;
				commodity =Constants.commodity_name;
				farmerId = Constants.INDO_SIT_Farmer_ID;
				farmerLeadId = Constants.INDO_SIT_FL_ID;
				userId = Constants.INDO_PROD_ADMIN_ID;
				break;

			case "Vietnam":
				origin= Constants.origin_name;
				lang=Constants.lang_name;
				commodity =Constants.commodity_name;
				farmerId = Constants.VIETNAM_SIT_Farmer_ID;
				farmerLeadId = Constants.VIETNAM_SIT_FL_ID;
				userId = Constants.VIETNAM_PROD_ADMIN_ID;
				break;

			default:
				System.out.println("Invalid input for country: " + country);
				break;
			}

			break;

		case "prod":
			baseUrl = Constants.PROD_BASE_URL;
			dbType = Constants.PROD_DB_TYPE;
			hostNameOrIPAddress = Constants.PROD_HOST_NAME_OR_IP_ADDRESS;
			portNumber = Constants.PROD_PORT_NUMBER;
			dbNameGlobal = Constants.PROD_GLOBAL_DB_NAME;
			dbNameNonGlobal = Constants.PROD_DB_NAME;
			dbUserName = Constants.PROD_DB_USER_NAME;
			dbPassword = Constants.PROD_DB_PASSWORD;

			switch (country) {
			case "Indonesia":
				origin= Constants.origin_name;
				lang=Constants.lang_name;
				commodity =Constants.commodity_name;
				
				farmerId = Constants.INDO_PROD_Farmer_ID;
				farmerLeadId = Constants.INDO_PROD_FL_ID;
				userId = Constants.INDO_PROD_ADMIN_ID;
				break;
			case "Cambodia":
				origin= Constants.origin_name;
				lang=Constants.lang_name;
				commodity =Constants.commodity_name;
				farmerId = Constants.CAMBODIA_PROD_Farmer_ID;
				farmerLeadId = Constants.CAMBODIA_PROD_FL_ID;
				userId = Constants.TURKEY_PROD_ADMIN_ID;
				break;

			case "Turkey":
				origin= Constants.origin_name;
				lang=Constants.lang_name;
				commodity =Constants.commodity_name;
				farmerId = Constants.TURKEY_PROD_Farmer_ID;
				farmerLeadId = Constants.MOZAMBIQUE_PROD_FL_ID;
				userId = Constants.TURKEY_PROD_ADMIN_ID;
				break;
			case "Vietnam":
				origin= Constants.origin_name;
				lang=Constants.lang_name;
				commodity =Constants.commodity_name;
				farmerId = Constants.VIETNAM_PROD_Farmer_ID;
				farmerLeadId = Constants.VIETNAM_PROD_FL_ID;
				userId = Constants.VIETNAM_PROD_ADMIN_ID;
				break;

			// Not in use currently

			/*
			 * case "Guatemala": originId = Constants.GUATEMALA_ID; farmerId =
			 * Constants.GUATEMALA_PROD_Farmer_ID; break; case "Mozambique": originId =
			 * Constants.MOZAMBIQUE_ID; farmerId = Constants.MOZAMBIQUE_PROD_Farmer_ID;
			 * farmerLeadId = Constants.MOZAMBIQUE_PROD_FL_ID; break; case "Ghana": originId
			 * = Constants.GHANA_ID; farmerId = Constants.GHANA_PROD_Farmer_ID; farmerLeadId
			 * = Constants.GHANA_PROD_FL_ID; break; case "Peru": originId =
			 * Constants.PERU_ID; farmerId = Constants.PERU_PROD_Farmer_ID; farmerLeadId =
			 * Constants.PERU_PROD_FL_ID; break;
			 */

			default:
				System.out.println("Invalid input for country: " + country);
				break;
			}

			break;
		default:
			System.out.println("Invalid input for environment: " + testEnv);
			break;
		}
		System.out.println("Base url has been set as: " + baseUrl);
	}

	public static void loadRunConfigProperties(String propertyFileName) throws IOException {
		runConfigProp.load(ClassLoader.getSystemResource(propertyFileName).openStream());

		testEnv = runConfigProp.getProperty("testEnv");
		country = runConfigProp.getProperty("origin");
		projectName = runConfigProp.getProperty("project.name");

		System.setProperty("cucumber.options", runConfigProp.getProperty("cucumber.options"));

	}

	// Initializing driver
	public static AndroidDriver getDriver() throws MalformedURLException {
		serverUrl = new URL("http://localhost:" + APPIUM_PORT + "/wd/hub");
		driver = new AndroidDriver(serverUrl, capabilities);
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		System.out.println("Driver initiated");
		return driver;
	}

}