package com.olamnet.farmer.stepdefinition;

import com.olamnet.farmer.utilities.BaseStepAction;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class HomeStep extends BaseStepAction {

	@Given("^the user is on home screen$")
	public void the_user_is_on_home_screen() throws Throwable {
		getActionItemsInstance().clickAction(getAndroidRepoInstance().imgHomeMenu);
		getActionItemsInstance().clickAction(getHomeRepoInstance().btnHome);
		getHomeActionInstance().waitForHomeScreenloading();
	}

	@Then("^verify if the home screen elements are displayed$")
	public void verify_if_the_home_screen_elements_are_displayed() throws Throwable {
		getHomeActionInstance().verifyHomeScreenElements();
	}

	
	@Then("^verify logout functionality$")
	public void verify_logout_functionality() throws Throwable {
		getHomeActionInstance().logout();
	}

}
