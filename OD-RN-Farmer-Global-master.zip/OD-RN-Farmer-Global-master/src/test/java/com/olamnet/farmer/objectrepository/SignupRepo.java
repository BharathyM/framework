package com.olamnet.farmer.objectrepository;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.olamnet.farmer.utilities.AppiumUtil;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindAll;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AndroidFindBys;

public class SignupRepo extends AbstractRepository {
	public static SignupRepo inst_SignupRepo = null;
	public SignupRepo(AndroidDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public static SignupRepo getInstance() {
		if (inst_SignupRepo == null)
			inst_SignupRepo = new SignupRepo(AppiumUtil.driver);
		return inst_SignupRepo;
	}

	@AndroidFindBy(xpath = "//*[@text='Signup']")
	public AndroidElement signupSwitch;
	
	@AndroidFindBy(xpath = "//*[@class='android.view.ViewGroup' and ./*[@text='SELECT COMMODITY']]")
	public AndroidElement commdDD;
	
	@AndroidFindBy(xpath = "//*[@text='Profile Picture* ']/following-sibling::*/*")
	public AndroidElement profilePic;
	
	@AndroidFindBy(xpath = "//*[@text='Take Photo']")
	public AndroidElement cameraSelect;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.sec.android.app.camera:id/normal_center_button']")
	public AndroidElement camerClickbtn;
	
	@AndroidFindBy(xpath = "//*[@resource-id='com.sec.android.app.camera:id/okay']")
	public AndroidElement picOkbtn;	
	
	@AndroidFindBy(xpath = "//*[@text='Gender*']/following-sibling::*/*/*/following-sibling::*")
	public AndroidElement genderSelect;
	
	@AndroidFindBy(xpath = "//*[@text='Full Name*']/following-sibling::*/*")
	public AndroidElement fullNameInput;
	
	@AndroidFindBy(xpath = "//*[@text='Phone Number*']/following-sibling::*/*/following-sibling::*")
	public AndroidElement PhoneNumbInput;
	
	@AndroidFindBy(xpath = "//*[@text='Date Of Birth*']/following-sibling::*/*/following-sibling::*")
	public AndroidElement DOBInput;
	
	@AndroidFindBy(xpath = "//*[@resource-id='android:id/button1']")
	public AndroidElement CalenderokBtn;	
	
	@AndroidFindBy(xpath = "//*[@resource-id='android:id/prev']")
	public AndroidElement calPrevMonth;
		
	@AndroidFindBy(xpath = "//*[@resource-id='android:id/next']")
	public AndroidElement calNextMonth;
	
	@AndroidFindBy(xpath = "//*[@resource-id='android:id/date_picker_header_year']")
	public AndroidElement calyearlist;
	
	@AndroidFindBy(xpath = "//*[@resource-id='android:id/text1']")
	public AndroidElement calYearClick;
		
	@AndroidFindBy(xpath = "//*[@text='Email*']/following-sibling::*/*")
	public AndroidElement emailInput;
	
	@AndroidFindBy(xpath = "//*[@text='Unique ID*']/following-sibling::*/*")
	public AndroidElement uniqueIDInput;
	
	@AndroidFindBy(xpath = "//*[@text='Add Scan Copy Of Unique Id* ']/following-sibling::*/*/*")
	public AndroidElement uniqueIDScanCopyPic;
	
	@AndroidFindBy(xpath = "//*[@text='Country*']/following-sibling::*/*")
	public AndroidElement countrydd;

	@AndroidFindBy(xpath = "//*[@text='Province*']/following-sibling::*/*/*/following-sibling::*")
	public AndroidElement provinceDD;
	
	@AndroidFindBy(xpath = "//*[@text='District*']/following-sibling::*/*/*/following-sibling::*")
	public AndroidElement distDD;
	
	@AndroidFindBy(xpath = "//*[@text='Sub District*']/following-sibling::*/*/*/following-sibling::*")
	public AndroidElement subDistDD;
	
	@AndroidFindBy(xpath = "//*[@text='City*']/following-sibling::*/*/*/following-sibling::*")
	public AndroidElement cityDD;
	
	@AndroidFindBy(xpath = "//*[@text='Address*']/following-sibling::*/*")
	public AndroidElement addrInput;
	
	@AndroidFindBy(xpath = "//*[@text='Zipcode*']/following-sibling::*/*")
	public AndroidElement zipcodeInput;
	
	@AndroidFindBy(xpath = "//*[@text='Farmer Lead ID*']/following-sibling::*/*/*/following-sibling::*")
	public AndroidElement flIdDD;
	
	@AndroidFindBy(xpath = "//*[@text='Farmer Lead Name*']/following-sibling::*/*")
	public AndroidElement flName;
	
	@AndroidFindBy(xpath = "//*[@text='I have read and agree to End User License Agreement and Privacy notice']")
	public AndroidElement tcTxt;
	

	@AndroidFindBy(xpath = "//*[@text='Submit']")
	public AndroidElement submit;
	
	@AndroidFindBy(xpath = "//*[@text='Farmer registration success']")
	public AndroidElement successMsginPopup;
	
	@AndroidFindBy(xpath = "//*[@text='Farmer registration success']/following-sibling::*/following-sibling::*")
	public AndroidElement newFarmerID;
	
	@AndroidFindBy(xpath = "//*[@text='Registration Successful']")
	public AndroidElement popupHeadingTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Registration Successful']/following-sibling::*/*")
	public AndroidElement popupClsbtn;
	
	@AndroidFindBy(xpath = "//*[@text='OK']")
	public AndroidElement popupOkbtn;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
