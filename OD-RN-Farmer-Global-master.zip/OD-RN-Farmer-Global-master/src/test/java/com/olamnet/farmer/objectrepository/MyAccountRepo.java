package com.olamnet.farmer.objectrepository;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.olamnet.farmer.utilities.AppiumUtil;
import com.olamnet.farmer.utilities.BaseStepAction;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindAll;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AndroidFindBys;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

public class MyAccountRepo extends AbstractRepository {

	public static MyAccountRepo inst_MyAccountRepo = null;

	public MyAccountRepo(AndroidDriver driver) {
		super(driver);
	}

	public static MyAccountRepo getInstance() {
		if (inst_MyAccountRepo == null)
			inst_MyAccountRepo = new MyAccountRepo(AppiumUtil.driver);
		return inst_MyAccountRepo;
	}

	
	//Personal Details...
		
	@AndroidFindBy(xpath = "//*[@text='Gender']/preceding-sibling::*")
	public AndroidElement profileImageView;
	
		
	@AndroidFindBy(xpath = "//*[@text='Full Name']/following-sibling::*[@class='android.view.ViewGroup']/*")
	public AndroidElement txtFarmerNameView;
	
	@AndroidFindBy(xpath = "//*[@text='Gender']/following-sibling::*[@class='android.view.ViewGroup']/*/*")
	public AndroidElement txtGenderView;
	
	@AndroidFindBy(xpath = "//*[@text='Phone Number']/following-sibling::*[@class='android.view.ViewGroup']/*/following-sibling::*")
	public AndroidElement txtPhonenumberview;
	
	@AndroidFindBy(xpath = "//*[@text='Date Of Birth']/following-sibling::*[@class='android.view.ViewGroup']/*")
	public AndroidElement txtDOBview;
	
	@AndroidFindBy(xpath = "//*[@text='Email']/following-sibling::*[@class='android.view.ViewGroup']/*")
	public AndroidElement txtEmailView;
	
	@AndroidFindBy(xpath = "//*[@text='Unique ID']/following-sibling::*[@class='android.view.ViewGroup']/*")
	public AndroidElement txtUniqueIdView;
	
	@AndroidFindBy(xpath = "//*[@text='Unique ID']/following-sibling::*[@class='android.view.ViewGroup']/following-sibling::*")
	public AndroidElement txtUniqueIDCopyview;	
	
	//Address View fields
	
	@AndroidFindBy(xpath = "//*[@text='Country']/following-sibling::*[@class='android.view.ViewGroup']/*")
	public AndroidElement txtCountryview;
	
	@AndroidFindBy(xpath = "//*[@text='Province']/following-sibling::*[@class='android.view.ViewGroup']/*/*")
	public AndroidElement txtStateView;
	
	@AndroidFindBy(xpath = "//*[@text='District']/following-sibling::*[@class='android.view.ViewGroup']/*/*")
	public AndroidElement txtDistview;
	
	@AndroidFindBy(xpath = "//*[@text='Sub District']/following-sibling::*[@class='android.view.ViewGroup']/*/*")
	public AndroidElement txtSubDistView;
	
	@AndroidFindBy(xpath = "//*[@text='City']/following-sibling::*[@class='android.view.ViewGroup']/*/*")
	public AndroidElement txtCityView;
	
	@AndroidFindBy(xpath = "//*[@text='Address']/following-sibling::*[@class='android.view.ViewGroup']/*")
	public AndroidElement txtAddressView;
	
	@AndroidFindBy(xpath = "//*[@text='Zipcode']/following-sibling::*[@class='android.view.ViewGroup']/*")
	public AndroidElement txtZipcodeView;
	
	//FL Details view...
	
	@AndroidFindBy(xpath = "//*[@text='Farmer Lead ID']/following-sibling::*[@class='android.view.ViewGroup']/*/*")
	public AndroidElement txtFLIDview;

	@AndroidFindBy(xpath = "//*[@text='Farmer Lead Name']/following-sibling::*[@class='android.view.ViewGroup']/*")
	public AndroidElement txtFLNameview;	
	

	@AndroidFindBy(xpath = "//*[@text='Error']/../following-sibling::*/following-sibling::*")
	public AndroidElement errorPopupTextMsg;	
	
	@AndroidFindBy(xpath = "//*[@text='OK']")
	public AndroidElement okBtnPopup;	
	
	
	//Edit personal details...	
	
	
	

	@AndroidFindBy(xpath = "//*[@text='Edit']")
	public AndroidElement editBtn;	
	
	@AndroidFindBy(xpath = "//*[@text='Change Profile Image']")
	public AndroidElement changeProfileImagelink;	
	
	@AndroidFindBy(xpath = "//*[@text='Full Name*']/following-sibling::*[@class='android.view.ViewGroup']/*")
	public AndroidElement editFullName;	
	
	@AndroidFindBy(xpath = "//*[@text='Gender*']/following-sibling::*/*/*/following-sibling::*")
	public AndroidElement editGender;	
	
	@AndroidFindBy(xpath = "//*[@text='Date Of Birth*']/following-sibling::*[@class='android.view.ViewGroup']/*/following-sibling::*")
	public AndroidElement editDob;	
	
	@AndroidFindBy(xpath = "//*[@text='Email*']/following-sibling::*[@class='android.view.ViewGroup']/*")
	public AndroidElement editEmail;
	
	@AndroidFindBy(xpath = "//*[@text='Unique ID*']/following-sibling::*[@class='android.view.ViewGroup']/*")
	public AndroidElement editUniqueID;
	
	@AndroidFindBy(xpath = "//*[@text='Add Scan Copy Of Unique Id']/following-sibling::*")
	public AndroidElement editScanCopy;		
	
	//Edit phone number...	

	@AndroidFindBy(xpath = "//*[@text='Phone Number*']/following-sibling::*[@class='android.view.ViewGroup']/*/following-sibling::*")
	public AndroidElement editPhoneNum;	
	
	@AndroidFindBy(id = "//*[@resource-id='android:id/alertTitle']")
	public AndroidElement alertPopup;		
	
	@AndroidFindBy(id = "//*[@resource-id='android:id/button1']")
	public AndroidElement okBtninAlert;		
	
	@AndroidFindBy(id = "//*[@resource-id='android:id/message']")
	public AndroidElement alertPopupMsg;			
	
	//Edit Address fields...

	@AndroidFindBy(xpath = "//*[@text='Address*']/following-sibling::*[@class='android.view.ViewGroup']/*")
	public AndroidElement editAdd;	

	@AndroidFindBy(xpath = "//*[@text='Zipcode*']/following-sibling::*[@class='android.view.ViewGroup']/*")
	public AndroidElement editZipcode;	
	
	@AndroidFindBy(xpath = "//*[@text='Edit on same property already pending. Wait for it to get approved.']")
	public AndroidElement popupMsgEditAdd;	
	
	@AndroidFindBy(xpath = "//*[@text='OK']")
	public AndroidElement okBtnInPopup;	
	
	@AndroidFindBy(xpath = "//*[@text='Error']")
	public AndroidElement errorPopup;	
	
	@AndroidFindBy(xpath = "//*[@text='Error']/following-sibling::*/*")
	public AndroidElement clsMarkPopup;	
	
	
	@AndroidFindBy(xpath = "//*[@text='Submit']")
	public AndroidElement editSubmitBtn;	
	
	@AndroidFindBy(xpath = "//*[@text='OK']")
	public AndroidElement editedPopupOkbtn;	
	
	@AndroidFindBy(xpath = "//*[@text='Profile update']/following-sibling::*/*")
	public AndroidElement editPopupClsbtn;	
	
	@AndroidFindBy(xpath = "//*[@text='User Profile updated successfully']")
	public AndroidElement editPopupSuccessMsg;		
	
	
		
	@AndroidFindBy(id = "profile_image")
	public AndroidElement imgFarmer;

	@AndroidFindBy(id = "idpetani")
	public AndroidElement txtFarmerId;

	@AndroidFindBy(id = "dob")
	public AndroidElement txtFarmerDOB;

	@AndroidFindBy(id = "identitynum")
	public AndroidElement txtUniqueId;

	@AndroidFindBy(id = "idvalidity")
	public AndroidElement txtUniqueIdExpiryDate;

	@AndroidFindBy(id = "farmerProg")
	public AndroidElement txtFarmerProgram;

	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'mobile_number')])[2]")
	public AndroidElement txtFarmerPhoneNo;

	@AndroidFindBy(id = "address")
	public AndroidElement txtFarmerAddress;

	@AndroidFindBy(id = "edit_img")
	public AndroidElement imgEditPersonalDetails;

	@AndroidFindBy(xpath = "//*[@resource-id='com.olam.fsp.farmertest:id/edit_address']")
	public AndroidElement imgEditAddress;

	@AndroidFindBy(id = "bankname")
	public AndroidElement txtBankName;

	@AndroidFindBy(id = "rekeningname")
	public AndroidElement txtAccHolderName;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'norekeningvalue')]")
	public AndroidElement txtBankAccNo;

	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'cardlayout')])[1]")
	public AndroidElement ddFirstOption;

	@AndroidFindBy(xpath ="//*[@resource-id='com.olam.fsp.farmertest:id/linear3']")
	public AndroidElement txtAccType;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'other_document')]/following-sibling::*/descendant::android.widget.LinearLayout")
	public List<AndroidElement> UploadDoc;

	@AndroidFindBy(id = "languageValue")
	public AndroidElement txtLanguage;

	@AndroidFindBy(id = "editlanguage")
	public AndroidElement imgEditLanguage;

	@AndroidFindBy(xpath = "//*[contains(@text,'Choose Language')]")
	public AndroidElement txtLanguagePopupTitle;

	@AndroidFindAll({ @AndroidBy(id = "sig_text_not_verified"), @AndroidBy(id = "txtSignatureCapturedStatus"),
			@AndroidBy(id = "sig_text_verified") })
	public List<AndroidElement> txtSignatureStatus;

	@AndroidFindBy(xpath = "//*[contains(@text,'LOGOUT')]")
	public AndroidElement lnkLogout;

	@AndroidFindBy(xpath = "//*[@text='LOGOUT']")
	public AndroidElement btnLogout;

	@AndroidFindBys({ @AndroidBy(xpath = "//*[contains(@text,'Verification Pending')]"),
			@AndroidBy(xpath = "//*[contains(@resource-id,'verifiedtxt1')]") })
	public List<AndroidElement> txtPendingVerification1;

	@AndroidFindBys({ @AndroidBy(xpath = "//*[contains(@text,'Verification Pending')]"),
			@AndroidBy(xpath = "//*[contains(@resource-id,'verifiedtxt2')]") })
	public List<AndroidElement> txtPendingVerification2;

	@AndroidFindBy(xpath = "//*[contains(@text,'successfully')]")
	public AndroidElement txtSuccessfully;

	@AndroidFindBy(id = "background_image")
	public AndroidElement geoSignArea;

	@AndroidFindBy(id = "privacy_policy_checkbox")
	public AndroidElement chkPrivacyPolicy;

	@AndroidFindBys({ @AndroidBy(xpath = "//*[@text='Privacy Policy']"), @AndroidBy(id = "toolbar_logo") })
	public AndroidElement titlePrivacyPolicy;

	@AndroidFindBy(id = "read_and_agree_txt_policy3")
	public AndroidElement lnkPrivacyPolicyFr;

	@AndroidFindBys({ @AndroidBy(xpath = "//*[@text='End User License']"), @AndroidBy(id = "toolbar_logo") })
	public WebElement titleEndUserLicense;

	@AndroidFindBy(id = "read_and_agree_txt_policy1")
	public AndroidElement lnkEndUserPolicy;

	@FindBys({ @FindBy(xpath = "//*[@text='Signature']"), @FindBy(id = "toolbar_logo") })
	public WebElement titleSignature;

	@AndroidFindBy(id = "imgAddSignature")
	public AndroidElement imgAddSignature;

	// TODO remove after app is stable
	/*
	 * @AndroidFindBy(xpath = "//*[contains(@resource-id,'selected_image')]") public
	 * AndroidElement profileImage;
	 * 
	 * @AndroidFindBy(xpath = "//*[contains(@resource-id,'rdoMale')]") public
	 * AndroidElement rdMale;
	 * 
	 * @AndroidFindBy(xpath = "//*[contains(@resource-id,'rdoFemale')]") public
	 * AndroidElement rdFemale;
	 */
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'namapemegangtxtvalue')]")
	public AndroidElement editAccHolderName;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'edit_img1')]")
	public AndroidElement imgEditBankDetails;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'editphone')]")
	public AndroidElement imgEditPhoneNo;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'customEditText')]")
	public AndroidElement tbAddress;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'txtReTakektp')]")
	public AndroidElement imgRetakeUniqueId;

	@AndroidFindBy(xpath = "//*[@text='Request for change in Bank Account has been submitted']")
	public AndroidElement txtUpdateSubmissionStatus;

	@AndroidFindBy(xpath = "//*[contains(@text,'has been uploaded')]")
	public AndroidElement txtUpdateUploadStatus;

	@AndroidFindBy(xpath = "//*[contains(@text,'Data edited successfully')]")
	public AndroidElement txtPhoneNoChangeStatus;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'order_sum_pay_text1')]")
	public AndroidElement txtUpdatedPhoneNo;

	@AndroidFindBy(id = "view_doc")
	public AndroidElement lnkViewUploadedDocs;

	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'document_name')])[1]")
	public AndroidElement lnkFirstDoc;
	

}
