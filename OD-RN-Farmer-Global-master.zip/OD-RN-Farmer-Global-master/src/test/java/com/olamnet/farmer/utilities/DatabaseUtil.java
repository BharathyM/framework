package com.olamnet.farmer.utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.olamnet.farmer.utilities.Constants;
import com.olamnet.farmer.utilities.DatabaseUtil;

public class DatabaseUtil {

	public static DatabaseUtil databaseUtil = null;

	public static DatabaseUtil getInstance() {
		if (databaseUtil == null)
			databaseUtil = new DatabaseUtil();
		return databaseUtil;
	}

	/**
	 * Returns JDBC Connection URL as per the specified Database Type
	 * 
	 * @param dbType              (Accepted Database types are sqlserver and mysql)
	 * @param hostNameOrIPAddress (the user can specify either <IP Address> or <Host
	 *                            name> of the database)
	 * @param portNumber          (Can be null when DBType=sqlserver)
	 * @param dbName              (Database instance name)
	 */
	public static String getJDBCConnectionURL(String dbType, String hostNameOrIPAddress, String portNumber,
			String dbName) {
		String dbURL = "";
		switch (dbType.toLowerCase()) {
		case "sqlserver":
			// DB URL format --> String dbURL =
			// "jdbc:sqlserver://ipAddress:portNumber/dbName";
			if (portNumber.equals("")) {
				String defaultPortNumber = "1433";
				portNumber = defaultPortNumber;
			}
			dbURL = "jdbc:sqlserver://" + hostNameOrIPAddress + ":" + portNumber + ";databaseName=" + dbName;
			break;

		case "mysql":
			dbURL = "jdbc:mysql://" + hostNameOrIPAddress + ":" + portNumber + ";databaseName=" + dbName;
			break;
		}
		return dbURL;
	}

	/**
	 * Returns the JDBC Connection driver corresponding to the Database Type
	 * specified
	 * 
	 * @return dbDriver
	 */
	public static String getJDBCConnectionDriver(String dbType) {
		String dbDriver = "";
		switch (dbType.toLowerCase()) {
		case "sqlserver": // Set Microsoft SQL JDBC Driver
			// Add Maven dependency from <!--
			// https://mvnrepository.com/artifact/com.microsoft.sqlserver/mssql-jdbc -->
			dbDriver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
			break;
		case "mysql": // Set MySQL JDBC Driver
			// Add Maven dependency from <!--
			// https://mvnrepository.com/artifact/mysql/mysql-connector-java -->
			dbDriver = "com.mysql.jdbc.Driver";
			break;
		}
		return dbDriver;
	}

	/**
	 * To establish a new connection to the given database
	 * 
	 * @param dbType              (Accepted Database types are sqlserver and mysql)
	 * @param hostNameOrIPAddress (the user can specify either <IP Address> or <Host
	 *                            name> of the database)
	 * @param portNumber          (Can be null when DBType=sqlserver)
	 * @param dbName              (Database name)
	 * @return con (Returns Connection Type variable after establishing a database
	 *         connection with the given parameters)
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public static Connection establishDBConnection(String dbType, String hostNameOrIPAddress, String portNumber,
			String dbName, String dbUserName, String dbPassword) throws ClassNotFoundException, SQLException {
		String dbDriver = DatabaseUtil.getJDBCConnectionDriver(dbType);
		String dbURL = DatabaseUtil.getJDBCConnectionURL(dbType, hostNameOrIPAddress, portNumber, dbName);
		Connection conn = null;

		// Load JDBC Driver
		Class.forName(dbDriver);

		// Creating connection to the database
		try {
			conn = DriverManager.getConnection(dbURL, dbUserName, dbPassword);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return conn;
	}

	/**
	 * Execute the given select query and return first record from the specified
	 * column
	 * 
	 * @param conn            (Connection Type variable returned as a result of the
	 *                        method 'establishDBConnection')
	 * @param selectquery     (Valid Select Query. It's not mandatory to mention
	 *                        Column name in the query. Query format: "SELECT * FROM
	 *                        <tablename> WHERE <condition>")
	 * @param tableColumnName (Column data to be filtered from the query result set)
	 * @return resultData (Returns the first record from the query result set)
	 * @throws SQLException
	 */
	public static String executeSelectQueryAndFetchFirstData(Connection conn, String selectquery,
			String tableColumnName) throws SQLException {
		String resultData = null;

		// Creating statement object
		Statement stmt = conn.createStatement();

		try {
			// Executing the SQL Query and store the results in ResultSet
			ResultSet resultSet = stmt.executeQuery(selectquery);

			// While loop to iterate through all data and print results
			while (resultSet.next()) {
				// System.out.println(resultSet.getString(tableColumnName));
				resultData = resultSet.getString(tableColumnName);
			}

			// Close result set
			if (resultSet != null) {
				resultSet.close();
			}

			// Close statement
			if (stmt != null) {
				stmt.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultData;
	}

	/**
	 * Close the Database connection instance
	 * 
	 * @param conn (Connection Type variable returned as a result of the method
	 *             'establishDBConnection')
	 */
	public static void closeDBConnection(Connection conn) {
		if (conn != null) {
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
	}

	/********************************************************************************
	 * The below two methods are provided for explaining the usage of this class
	 * file Remove or customize the below methods in your actual project
	 * implementation
	 ******************************************************************************/
// To establish connection with global DB
	public static Connection getGlobalDBConnection() throws ClassNotFoundException, SQLException {
		Connection connDOGlobalUAT = DatabaseUtil.establishDBConnection(AppiumUtil.dbType,
				AppiumUtil.hostNameOrIPAddress, AppiumUtil.portNumber, AppiumUtil.dbNameGlobal, AppiumUtil.dbUserName,
				AppiumUtil.dbPassword);

		return connDOGlobalUAT;
	}

	// To establish connection with non global DB
	public static Connection getDBConnection() throws ClassNotFoundException, SQLException {
		Connection connDOUAT = DatabaseUtil.establishDBConnection(AppiumUtil.dbType, AppiumUtil.hostNameOrIPAddress,
				AppiumUtil.portNumber, AppiumUtil.dbNameNonGlobal, AppiumUtil.dbUserName, AppiumUtil.dbPassword);

		return connDOUAT;
	}

//	To get column data from DB by utilizing the above method
	public String getAuthorizationOTP(String userID) throws ClassNotFoundException, SQLException {
		Connection connDOGlobalUAT = getGlobalDBConnection();

		String selectQuery = "SELECT TOP (1) [otp] FROM [authorizationn].[users] WHERE user_id like '%" + userID
				+ "%' AND ACTIVE_ORIGIN_ID = " + AppiumUtil.origin + " ORDER BY updated_ts DESC";

		String authorizationOTP = DatabaseUtil.executeSelectQueryAndFetchFirstData(connDOGlobalUAT, selectQuery, "otp");

		System.out.println("Authorization OTP from DB: " + authorizationOTP);

		closeDBConnection(connDOGlobalUAT);

		return authorizationOTP;
	}

	public String getTransactionOtp() throws ClassNotFoundException, SQLException {
		Connection connDOUAT = getDBConnection();

		String transactionOTP = DatabaseUtil.executeSelectQueryAndFetchFirstData(connDOUAT,
				Constants.SQL_SELECT_TRANS_OTP, "transaction_otp");

		System.out.println(transactionOTP);

		closeDBConnection(connDOUAT);

		return transactionOTP;
	}

	public String getVerificationOtp() throws ClassNotFoundException, SQLException {
		Connection connDOUAT = getDBConnection();

		String verificationOTP = DatabaseUtil.executeSelectQueryAndFetchFirstData(connDOUAT,
				Constants.SQL_SELECT_VERIFICATION_OTP, "otp");

		System.out.println(verificationOTP);

		closeDBConnection(connDOUAT);

		return verificationOTP;
	}

	public String getProductId(String commodity) throws ClassNotFoundException, SQLException {
		Connection connDOUAT = getDBConnection();

		String selectQuery = Constants.SQL_SELECT_PRODUCT_ID + commodity + "%'";

		String productId = DatabaseUtil.executeSelectQueryAndFetchFirstData(connDOUAT, selectQuery, "product_id");

		System.out.println(productId);

		closeDBConnection(connDOUAT);

		return productId;
	}

	public String getTradingProductId(String tradingProductName) throws ClassNotFoundException, SQLException {
		Connection connDOUAT = getDBConnection();

		String selectQuery = Constants.SQL_SELECT_TRADPROD_ID + tradingProductName + "%'";

		String tradingProductId = DatabaseUtil.executeSelectQueryAndFetchFirstData(connDOUAT, selectQuery,
				"trading_product_id");

		System.out.println(tradingProductId);

		closeDBConnection(connDOUAT);

		return tradingProductId;
	}

	public String getDisplayFarmerId(String farmerId) throws ClassNotFoundException, SQLException {
		Connection connDOUAT = getDBConnection();

		String selectQuery = Constants.SQL_SELECT_DISPLAY_FARMER_ID + farmerId + "' and origin_id ="
				+ AppiumUtil.originId;

		String displayFarmerId = DatabaseUtil.executeSelectQueryAndFetchFirstData(connDOUAT, selectQuery,
				"display_farmer_id");

		closeDBConnection(connDOUAT);

		return displayFarmerId;
	}

	public String getDisplayFarmerLeadId(String farmerLeadId) throws ClassNotFoundException, SQLException {
		Connection connDOUAT = getDBConnection();

		String selectQuery = Constants.SQL_SELECT_DISPLAY_FARMERLEAD_ID + farmerLeadId + "' and freg.origin_id ="
				+ AppiumUtil.originId;

		String displayFarmerLeadId = DatabaseUtil.executeSelectQueryAndFetchFirstData(connDOUAT, selectQuery,
				"display_farmer_id");

		System.out.println(displayFarmerLeadId);

		closeDBConnection(connDOUAT);

		return displayFarmerLeadId;
	}

	public String getBackendFarmerId(String farmerId) throws ClassNotFoundException, SQLException {
		Connection connDOUAT = getDBConnection();

		String selectQuery = Constants.SQL_SELECT_FARMER_ID + farmerId + "' and origin_id = " + AppiumUtil.originId;

		String backendFarmerId = DatabaseUtil.executeSelectQueryAndFetchFirstData(connDOUAT, selectQuery, "farmer_id");

		System.out.println(backendFarmerId);

		closeDBConnection(connDOUAT);

		return backendFarmerId;
	}

}
