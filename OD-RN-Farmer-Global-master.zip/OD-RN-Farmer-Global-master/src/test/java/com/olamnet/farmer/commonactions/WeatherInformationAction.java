package com.olamnet.farmer.commonactions;

import static org.testng.Assert.assertTrue;

import java.time.format.DateTimeFormatter;
import java.util.stream.Stream;

import org.openqa.selenium.WebElement;

import com.olamnet.farmer.utilities.ActionItems.DIRECTION;
import com.olamnet.farmer.utilities.AppiumUtil;
import com.olamnet.farmer.utilities.BaseStepAction;

import io.appium.java_client.android.AndroidDriver;

public class WeatherInformationAction extends BaseStepAction {
	AndroidDriver driver;
	public static WeatherInformationAction inst_WeatherInfoAction = null;

	public WeatherInformationAction(AndroidDriver driver) {
		this.driver = driver;
	}

	public static WeatherInformationAction getInstance() {
		if (inst_WeatherInfoAction == null)
			inst_WeatherInfoAction = new WeatherInformationAction(AppiumUtil.driver);
		return inst_WeatherInfoAction;
	}

	public void verifyWeatherInfoUIElements() {
		//Weather details		
		getActionItemsInstance().addLogWithScreenShot("Weather Screen-1");		
		getActionItemsInstance().reportStepLog("Date: "+getWeatherInformationRepoInstance1().dateTxt.getText());
		if(getActionItemsInstance().isDisplayedAction(getWeatherInformationRepoInstance1().imageCloudy)) {
			getActionItemsInstance().reportStepLog("Cloud Cover image is dispalyed "); }	
		getActionItemsInstance().reportStepLog("Weather Temparature: "+getWeatherInformationRepoInstance1().tempWeather.getText());
		getActionItemsInstance().reportStepLog("cloudyStatus: "+getWeatherInformationRepoInstance1().cloudyStatus.getText());
		getActionItemsInstance().reportStepLog("Lastly Observed by user: "+getWeatherInformationRepoInstance1().lastObservedtime.getText());
		getActionItemsInstance().reportStepLog(getWeatherInformationRepoInstance1().humadityLabTxt.getText()+": "+getWeatherInformationRepoInstance1().humadityValue.getText());
		getActionItemsInstance().reportStepLog(getWeatherInformationRepoInstance1().lowLabTxt.getText()+" : "+getWeatherInformationRepoInstance1().lowValue.getText());
		getActionItemsInstance().reportStepLog(getWeatherInformationRepoInstance1().highLabTxt.getText()+" : "+getWeatherInformationRepoInstance1().highValue.getText());
		getActionItemsInstance().reportStepLog(getWeatherInformationRepoInstance1().pressureLabTxt.getText()+" : "+getWeatherInformationRepoInstance1().pressureValue.getText());
		getActionItemsInstance().reportStepLog(getWeatherInformationRepoInstance1().preceipitLabTxt.getText()+" : "+getWeatherInformationRepoInstance1().preciptationLabValue.getText());
		getActionItemsInstance().reportStepLog(getWeatherInformationRepoInstance1().windDireTxt.getText()+" : "+getWeatherInformationRepoInstance1().windDireValue.getText());
			
		 view_FullReportElements();				 
		 /*getActionItemsInstance().swipe(DIRECTION.RIGHT);
			getActionItemsInstance().addLogWithScreenShot("horizantal scroll in details report-3");	*/
		 //scrolldown for weekly forecast
		 getActionItemsInstance().scrollDownViewByXpath("//*[@text='Weekly Forecast']/following-sibling::*[5]");
		 getActionItemsInstance().addLogWithScreenShot("Weekly Forecast in Weather-5");	
			getActionItemsInstance().reportStepLog("Weather UI Elements are verified");
	}
	
	public void view_FullReportElements()
	{
		//Hourly Forecast in Detailed Report
				getActionItemsInstance().clickAction(getWeatherInformationRepoInstance1().viewFullReportLink);	
				getActionItemsInstance().waitForProgressBar();
				getActionItemsInstance().verifyText(getWeatherInformationRepoInstance1().detailedReportTxt.getText(),"Detailed Report");
				getActionItemsInstance().addLogWithScreenShot("Detailed Report");		
				/*getActionItemsInstance().swipe(DIRECTION.RIGHT);
				getActionItemsInstance().addLogWithScreenShot("horizantal scroll in details report-3");	*/
			
				//WeeklyForcast in the Detailed Report
				getActionItemsInstance().reportStepLog(getWeatherInformationRepoInstance1().weeklyFCTxt.getText());
				getActionItemsInstance().scrollDownViewByXpath("//*[@text='Weekly Forecast']/following-sibling::*[5]");
				getActionItemsInstance().addLogWithScreenShot("Weekly Forecast in details report-4");	
				driver.navigate().back();		
	}
	
	//Currently it is not there in global 
	public void map_viewVerify()
	{
		
	}
}
