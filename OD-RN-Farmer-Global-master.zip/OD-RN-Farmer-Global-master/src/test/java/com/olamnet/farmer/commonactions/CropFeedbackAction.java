package com.olamnet.farmer.commonactions;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cucumber.listener.Reporter;
import com.olamnet.farmer.utilities.AppiumUtil;
import com.olamnet.farmer.utilities.BaseStepAction;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class CropFeedbackAction extends BaseStepAction {
	AndroidDriver driver;
	public static CropFeedbackAction inst_CropFeedbackAction = null;
	
	WebElement RadioandCheckBoxanswerTypeElement;
	WebElement TextInputanswerTypeElement;

	public CropFeedbackAction(AndroidDriver driver) {
		this.driver = driver;
	}

	public static CropFeedbackAction getInstance() {
		if (inst_CropFeedbackAction == null)
			inst_CropFeedbackAction = new CropFeedbackAction(AppiumUtil.driver);
		return inst_CropFeedbackAction;
	}

	public void submitCropFeedback() {
		getActionItemsInstance().verifyText(getCropFeedbackRepoInstance().titleTxt.getText(), "Survey");
		getActionItemsInstance().verifyText(getCropFeedbackRepoInstance().labelTxtinSurveyList.getText(), "Click on a survey to continue");		
		getActionItemsInstance().addLogWithScreenShot("SurveryList Screen..");		
		int NoOfSurveys = getCropFeedbackRepoInstance().surveyListSize.size() ;		
		System.out.println("No.of Querys :::: "+NoOfSurveys);	
		getActionItemsInstance().reportStepLog("1st Survery Title:: "+getCropFeedbackRepoInstance().surveryTitle.getText());
		
		if(getCropFeedbackRepoInstance().paidSurveryRpTxtinList.getText().equals("Rp")) 		{
			getActionItemsInstance().clickAction(getCropFeedbackRepoInstance().paidSurveryNavigationLink);
		}
		else 		{
			getActionItemsInstance().clickAction(getCropFeedbackRepoInstance().nonPaidSurveryNavigationlink);
		}	
				
		mandatoryQuestionAnswering();		
		
		//old code
		/*String txtCropFeedbackCardTitle = getCropFeedbackRepoInstance().lstCropFeedbackTitle.get(0).getText();
		getActionItemsInstance().clickAction(getCropFeedbackRepoInstance().lstCropFeedbackTitle.get(0));
	//	getActionItemsInstance().verifyText(getAndroidRepoInstance().txtTitle.getText(), "Crop Feedback");
		assertTrue(txtCropFeedbackCardTitle.equals(getCropFeedbackRepoInstance().feedbackTitleInCard.getText()));
		int queryCount = getCropFeedbackRepoInstance().lstQuery.size();
		getActionItemsInstance().reportStepLog("No of queries in cropfeedback: " + queryCount);

		for (int i = 0; i < queryCount; i++) {
			WebElement wbFirstAnswer = driver.findElementByXPath(
					"(//*[contains(@resource-id,'answer_list')]/descendant::*[contains(@resource-id,'radio_button')])[1]");
			getActionItemsInstance().clickAction(wbFirstAnswer);
			getActionItemsInstance().sendKeysAction(getCropFeedbackRepoInstance().comments, "test comments");
		}

		if (queryCount > 0) {
			getActionItemsInstance().clickAction(getAndroidRepoInstance().btnSubmit);
			assertTrue(getActionItemsInstance().isDisplayedAction(getCropFeedbackRepoInstance().txtFeedbackSuccessMsg),
					"Feedback is not submitted successfully");
			getActionItemsInstance().clickAction(getAndroidRepoInstance().btnOk);
		}*/

	}
	
	public void mandatoryQuestionAnswering()
	{
		int queryCount = getCropFeedbackRepoInstance().lstQuery.size();
			getActionItemsInstance().reportStepLog("No of queries in cropfeedback: " + queryCount);
		for(int i=1;i<queryCount-2;i++) {		
			 WebElement wbFirstAnswer = driver.findElementByXPath(
					"//*[@text='*required fields']/following-sibling::*/*/*/*[contains(@text,'Q"+i+". ') and contains(@text,'*')]");
			getActionItemsInstance().reportStepLog("Query Name :: "+wbFirstAnswer.getText());	
			String queryName = wbFirstAnswer.getText();
			
			 TextInputanswerTypeElement = driver.findElementByXPath(
						"//*[@text='*required fields']/following-sibling::*/*/*/*[contains(@text,'"+queryName+"')]/following-sibling::*/*");			  
						 			 
			//checbox & Radio button selection question type
			 RadioandCheckBoxanswerTypeElement = driver.findElementByXPath(
						"//*[@text='*required fields']/following-sibling::*/*/*/*[contains(@text,'"+queryName+"')]/following-sibling::*/*/*/*/*/*");
				//TextInputField Question type
			
			if(getActionItemsInstance().isDisplayedAction(wbFirstAnswer)) 			{			
			       if(getActionItemsInstance().isDisplayedAction(TextInputanswerTypeElement)){
			         getActionItemsInstance().sendKeysAction(TextInputanswerTypeElement, "AutomationTestAnswer"); 
			          		       }			
			       else if (getActionItemsInstance().isDisplayedAction(RadioandCheckBoxanswerTypeElement)){
			         getActionItemsInstance().clickAction(RadioandCheckBoxanswerTypeElement) ; 			   
			           
			 }	 //*[@text='Q2. Select checkbox...*']
			}else {
				  getActionItemsInstance().reportStepLog("Not mandatory question"+wbFirstAnswer.getText());
			 
			       break;
			}
		}
		//dropdown selection question type 	---!!!!!!!currently app crashing when select the option in the DD question type so commetning it			 
			// answerTypeElement = driver.findElementByXPath("//*[@text='*required fields']/following-sibling::*/*/*/*[contains(@text,'Q1. ') and contains(@text,'*')]/following-sibling::*/*/*/following-sibling::*");
			    //   if(getActionItemsInstance().isDisplayedAction(answerTypeElement)){
				 //    getActionItemsInstance().clickAction(getCropFeedbackRepoInstance().selectDDOption); 				     }				     
			      
			       getActionItemsInstance().sendKeysAction(getCropFeedbackRepoInstance().sampleRemarksInput, "TestingTextenter");			       
			       getActionItemsInstance().addLogWithScreenShot("BeforeSubmit the Feedback");
			       //Continue button and exit button verifying
			       getActionItemsInstance().clickAction(getCropFeedbackRepoInstance().backArrow);
			       getActionItemsInstance().addLogWithScreenShot("Exit Popup Screen...");
			       getActionItemsInstance().clickAction(getCropFeedbackRepoInstance().continueBtn);      
			       
			      /* getActionItemsInstance().clickAction(getCropFeedbackRepoInstance().submitBtn);
			       getActionItemsInstance().addLogWithScreenShot("Feedback Submitted Message Screen...");
			       getActionItemsInstance().reportStepLog("Success Message :: "+getCropFeedbackRepoInstance().successMsgTxt);
			       getActionItemsInstance().clickAction(getCropFeedbackRepoInstance().takeAnotherSurveryBtn);
			       //getActionItemsInstance().clickAction(getCropFeedbackRepoInstance().backToHomeBtn);*/
			         			
	 }
	
	
	public void nonMandatoryQuestionAnswering()
	{
		int queryCount = getCropFeedbackRepoInstance().lstQuery.size();
			getActionItemsInstance().reportStepLog("No of queries in cropfeedback: " + queryCount);
		for(int i=1;i<queryCount;i++) {		
			 WebElement wbFirstAnswer = driver.findElementByXPath(
					"//*[@text='*required fields']/following-sibling::*/*/*/*[contains(@text,'Q"+i+". ')]");
			getActionItemsInstance().reportStepLog("Query Name :: "+wbFirstAnswer.getText());
			
			//checbox & Radio button selection question type
			 RadioandCheckBoxanswerTypeElement = driver.findElementByXPath(
						"//*[@text='*required fields']/following-sibling::*/*/*/*[contains(@text,'Q"+i+". ')]/following-sibling::*/*/*/*/*/*");
				//TextInputField Question type
			 TextInputanswerTypeElement = driver.findElementByXPath(
						"//*[@text='*required fields']/following-sibling::*/*/*/*[contains(@text,'Q"+i+". ')]/following-sibling::*/*");			  
			if(getActionItemsInstance().isDisplayedAction(wbFirstAnswer)) 			{
			
			       if(getActionItemsInstance().isDisplayedAction(TextInputanswerTypeElement)){
			     getActionItemsInstance().sendKeysAction(TextInputanswerTypeElement, "AutomationTestAnswer"); 
			     break; 			       }			
			 else if (getActionItemsInstance().isDisplayedAction(RadioandCheckBoxanswerTypeElement)){
			     getActionItemsInstance().clickAction(RadioandCheckBoxanswerTypeElement) ; 			   
			 break;    
			 }	 	
			       
		//dropdown selection question type 	---!!!!!!!currently app crashing when select the option in the DD question type so commetning it			 
			// answerTypeElement = driver.findElementByXPath("//*[@text='*required fields']/following-sibling::*/*/*/*[contains(@text,'Q1. ')]/following-sibling::*/*/*/following-sibling::*");
			    //   if(getActionItemsInstance().isDisplayedAction(answerTypeElement)){
				 //    getActionItemsInstance().clickAction(getCropFeedbackRepoInstance().selectDDOption); 				     }				     
			       
			       getActionItemsInstance().sendKeysAction(getCropFeedbackRepoInstance().sampleRemarksInput, "TestingTextenter");
			       
			       getActionItemsInstance().addLogWithScreenShot("BeforeSubmit the Feedback");
			       //Continue button and exit button verifying
			       getActionItemsInstance().clickAction(getCropFeedbackRepoInstance().backArrow);
			       getActionItemsInstance().addLogWithScreenShot("Exit Popup Screen...");
			       getActionItemsInstance().clickAction(getCropFeedbackRepoInstance().continueBtn);      
			       
			      /* getActionItemsInstance().clickAction(getCropFeedbackRepoInstance().submitBtn);
			       getActionItemsInstance().addLogWithScreenShot("Feedback Submitted Message Screen...");
			       getActionItemsInstance().reportStepLog("Success Message :: "+getCropFeedbackRepoInstance().successMsgTxt);
			       getActionItemsInstance().clickAction(getCropFeedbackRepoInstance().takeAnotherSurveryBtn);
			       //getActionItemsInstance().clickAction(getCropFeedbackRepoInstance().backToHomeBtn);*/
			       
			  }
			}
	}
	
}

/*possible queries to answer
Either text or number or email or phonenumber
dropdown
radio button
checkbox 
upload image
date 
photocheckbox*/