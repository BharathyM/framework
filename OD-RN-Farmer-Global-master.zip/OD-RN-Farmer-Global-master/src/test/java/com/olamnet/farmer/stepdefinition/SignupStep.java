package com.olamnet.farmer.stepdefinition;

import com.cucumber.listener.Reporter;
import com.olamnet.farmer.utilities.BaseStepAction;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class SignupStep  extends BaseStepAction{
	
	@Given("^user switch to signup screen from login$")
	public void user_switch_to_signup_screen_from_login_screen() throws Throwable {
		getSignupActionInstance().navigateToRegisterFarmerLink();
	}

	@Then("^sign up as a new farmer with \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void sign_up_as_a_new_farmer_with(String Commodity,String gender,String fullName,String phoneNum,String dob,String email,String proviance,String dist,String subDist,String city,String address,String FLId) throws Throwable {
			getSignupActionInstance().registerFarmer(Commodity,gender,fullName,phoneNum,dob,email,proviance,dist,subDist,city,address,FLId);
	}

	@Then("^verify by logging in using the id generated$")
	public void verify_by_logging_in_using_the_id_generated() throws Throwable {

		//getLoginActionInstance().loginUsingFarmerIdGenerated();
	}
	
}
