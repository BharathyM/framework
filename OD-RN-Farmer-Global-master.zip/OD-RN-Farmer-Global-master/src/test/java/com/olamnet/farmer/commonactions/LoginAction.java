package com.olamnet.farmer.commonactions;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.Year;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Stream;

import org.json.JSONException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cucumber.listener.Reporter;
import com.olamnet.farmer.utilities.AppiumServerTest;
import com.olamnet.farmer.utilities.AppiumUtil;
import com.olamnet.farmer.utilities.BaseStepAction;
import com.olamnet.farmer.utilities.Constants;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.PointOption;

public class LoginAction extends BaseStepAction {
	AndroidDriver driver;
	public static LoginAction inst_LoginAction = null;
	public static String farmerLoginId;
	public static String FULL_RESET_VALUE;
	public static String newFarmerId;
	AtomicBoolean alreadyExecuted = new AtomicBoolean(false);
	AtomicBoolean alreadyInstalled = new AtomicBoolean(false);
	private static Properties appiumProp = new Properties();
	private static Properties farmerProp = new Properties();
	WebElement ele;

	public LoginAction(AndroidDriver driver) {
		this.driver = driver;
	}

	public static LoginAction getInstance() {
		if (inst_LoginAction == null)
			inst_LoginAction = new LoginAction(AppiumUtil.driver);
		return inst_LoginAction;
	}

	public static String getNewFarmerId() {
		return newFarmerId;
	}

	public void loginUsingFarmerIdGenerated() throws ClassNotFoundException, SQLException, IOException, JSONException {
		farmerProp.load(ClassLoader.getSystemResource("farmer.properties").openStream());
		getApiActions().resetDevice(farmerProp.getProperty("farmerId"), Constants.ROLE_ID_FARMER);
		getActionItemsInstance().clickAction(getLoginRepoInstance().btnLogin);
		getLoginActionInstance().enterOTP(newFarmerId);
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnConfirm);
		getHomeActionInstance().waitForHomeScreenloading();
		writeFarmerIdInPropFile(newFarmerId);
		getActionItemsInstance().reportStepLog("Farmer sign up verified");
	}

	public void verifyLoginScreen() throws InterruptedException {
		getActionItemsInstance().waitAction(getLoginRepoInstance().labelTxt, 30);
		getActionItemsInstance().addLogWithScreenShot("User is navigated to login screen");
		getActionItemsInstance().isDisplayedAction("OFI Logo", getLoginRepoInstance().ofiLogo);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(3000);
		getActionItemsInstance().isDisplayedAction("Helpline Image", getLoginRepoInstance().callImageinLogin);
		getActionItemsInstance().clickAction(getLoginRepoInstance().callImageinLogin);
		// getActionItemsInstance().verifyText(getLoginRepoInstance().popupText.getText(),
		// "Contact Olam's help center");
		// Boolean Status =
		// getActionItemsInstance().isDisplayedAction(getLoginRepoInstance().callBtnHelpline);		
		getActionItemsInstance().addLogWithScreenShot("Helpline Popup");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// if (Status == true) {
		getActionItemsInstance().clickAction(getLoginRepoInstance().closeHelpPopup);
		// }
		getActionItemsInstance().reportStepLog("Helpline popup is verified");
		getActionItemsInstance().reportStepLog("UI elements verified");
	}
		

	public void loginWithValidFarmerIdNew(String loginType, String ODID, String OFISID, String MobileNum,
			String UniqueID,String OTP) throws InterruptedException, JSONException, ClassNotFoundException, SQLException, IOException {
		if (loginType.equalsIgnoreCase("ODID")) {
			getActionItemsInstance().clickAction(getLoginRepoInstance().inputHelpText);
			getActionItemsInstance().clickAction(getLoginRepoInstance().odIDLoginOption);
			getActionItemsInstance().sendKeysAction(getLoginRepoInstance().inputTxt, ODID);
		} else if (loginType.equalsIgnoreCase("OFISID")) {
			getActionItemsInstance().clickAction(getLoginRepoInstance().inputHelpText);
			getActionItemsInstance().clickAction(getLoginRepoInstance().ofisIdLoginOption);
			getActionItemsInstance().sendKeysAction(getLoginRepoInstance().inputTxt, OFISID);
		} else if (loginType.equalsIgnoreCase("MobileNum")) {
			getActionItemsInstance().clickAction(getLoginRepoInstance().inputHelpText);
			getActionItemsInstance().clickAction(getLoginRepoInstance().mobileLoginOption);
			getActionItemsInstance().sendKeysAction(getLoginRepoInstance().mobileInputTxt, MobileNum);
			
		} else if (loginType.equalsIgnoreCase("UniqueID")) {
			getActionItemsInstance().clickAction(getLoginRepoInstance().inputHelpText);
			getActionItemsInstance().clickAction(getLoginRepoInstance().uniqueIdLoginOpt);
			getActionItemsInstance().sendKeysAction(getLoginRepoInstance().inputTxt, UniqueID);
		}
		//Thread.sleep(2000);
		//getActionItemsInstance().sendKeysAction(getLoginRepoInstance().inputTxt, ODID);
		//getActionItemsInstance().clickAction(getLoginRepoInstance().termsChxbox);
		getActionItemsInstance().addLogWithScreenShot("Login Screen");
		getApiActions().resetDevice(ODID, Constants.ROLE_ID_FARMER);
		//farmerProp.load(ClassLoader.getSystemResource("farmer.properties").openStream());
		//getApiActions().resetDevice(farmerProp.getProperty("farmerId"), Constants.ROLE_ID_FARMER);
		if(getActionItemsInstance().isDisplayedAction(getLoginRepoInstance().tocTxt))
		{
			getActionItemsInstance().reportStepLog("Terms&condiotins checkbox enabled and text displayed");
		}
		getActionItemsInstance().clickAction(getLoginRepoInstance().otpLink);
		getActionItemsInstance().waitForProgressBar();	
		//String otp = Constants.LoginfirebasedefulatOTP;		
		getActionItemsInstance().addLogWithScreenShot("OTP Login Screen");			
		getActionItemsInstance().verifyText(getLoginRepoInstance().phoneNuminOTP.getText(), MobileNum);
		System.out.println("PhonenNumber::***********" + getLoginRepoInstance().phoneNuminOTP.getText());	
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		enterOTPReact(OTP);	
		
		getActionItemsInstance().reportStepLog("Login OTP is entered and confirmed");		
		getActionItemsInstance().clickAction(getLoginRepoInstance().confirmBtn);
		Thread.sleep(2000);
		getActionItemsInstance().addLogWithScreenShot("Landing to Home ");
		getActionItemsInstance().reportStepLog("User able to Login Sccuessfully with login method: " + loginType);
	}
	
	
	
	
		
	public void enterOTPReact(String OTP) throws ClassNotFoundException, SQLException {
		char[] otpArr = OTP.toCharArray();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
		for (int i = 0; i<otpArr.length; i++) {
			driver.findElementByXPath("(//*[@resource-id='textInput'])["+ (i+1)  +"]")
				.sendKeys(Character.toString(otpArr[i]));		
		}
	}

	public void loginWithValidFarmerId(String farmerId)
			throws JSONException, IOException, ClassNotFoundException, SQLException, InterruptedException {
		writeFarmerIdInPropFile(farmerId);
		getApiActions().resetDevice(farmerId, Constants.ROLE_ID_FARMER);
		char[] arrFarmerId = farmerId.toCharArray();
		for (int i = 0; i < arrFarmerId.length; i++) {
			WebElement wbFarmerId = AppiumUtil.driver.findElementById("et" + (i + 1));
			getActionItemsInstance().sendKeysAction(wbFarmerId, Character.toString(arrFarmerId[i]));
		}
		getActionItemsInstance().clickAction(getLoginRepoInstance().btnLogin);
		enterOTP(farmerId);
		// Login OTPs are not generating from DB it was generating from google firebase
		// so disabled this method

		// hardcoded firebase OTp
		getActionItemsInstance().sendKeysOTP(Constants.LoginfirebasedefulatOTP);
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnConfirm);
		getActionItemsInstance().reportStepLog("Login OTP is entered and confirmed");
	}

	private void writeFarmerIdInPropFile(String farmerId) throws IOException {
		Properties farmerProp = new Properties();
		farmerProp.put("farmerId", farmerId);
		String path = System.getProperty("user.dir") + "\\src\\test\\resources\\farmer.properties";
		FileOutputStream fos = new FileOutputStream(path);
		farmerProp.store(fos, "Farmer Data");
	}

	public void verifyLoginSuccessStatus() throws IOException {
		appiumProp.load(ClassLoader.getSystemResource("Appium.properties").openStream());
		FULL_RESET_VALUE = appiumProp.getProperty("full.reset.value");
		if (FULL_RESET_VALUE.equals("true")) {
			if (alreadyInstalled.compareAndSet(false, true)) {
				getActionItemsInstance().reportStepLog(
						"App is installed for the first time and hence terms and conditions to be accepted");
				getActionItemsInstance().clickAction(getHomeRepoInstance().chkLicense);
				getActionItemsInstance().clickAction(getHomeRepoInstance().chkPrivacyPolicy);
				getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNext);
			} else {
				getActionItemsInstance().reportStepLog("App is already installed");
			}

		} else {
			getActionItemsInstance().reportStepLog("App is already installed");
		}
	}

	public void registerFarmer(String subDist, String village, String addr)
			throws InterruptedException, ParseException {
		navigateToRegisterFarmerLink();
		addPersonalDetails();
		// selectFarmerLead();
		addAddress(subDist, village, addr);
		// getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNext);
		verifyFarmerDetails();
		getActionItemsInstance().waitAction(getLoginRepoInstance().txtSuccessMsg, 15);
		getActionItemsInstance().isDisplayedAction(getLoginRepoInstance().txtSuccessMsg);
		newFarmerId = getLoginRepoInstance().txtRegisFarmerId.getText().replaceAll("\\s", "").replace("-", "");
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnOk);
		getActionItemsInstance()
				.reportStepLog("Farmer registration is successful and registered farmer id is: " + newFarmerId);
	}

	public void addPersonalDetails() throws InterruptedException, ParseException {
		getActionItemsInstance().clickAction(getLoginRepoInstance().imgProfilePik);
		getActionItemsInstance().uploadImage();
		getActionItemsInstance().clickAction(getLoginRepoInstance().btnMrs);
		getActionItemsInstance().sendKeysAction(getLoginRepoInstance().tbName, Constants.FARMER_NAME);
		fillMobileNumber();
		getActionItemsInstance().scrollUntilVisibleText("Date of birth");
		getActionItemsInstance().clickAction(getLoginRepoInstance().calendarDob);
		// TODO to be checked in all origins
		// selectDate(Constants.FARMER_DOB);
		// selectDate();
		selectCompleteDate(Constants.FARMER_DOB);
		getActionItemsInstance().scrollUntilVisibleText("UNIQUE ID");
		getActionItemsInstance().scrollUntilVisibleText("Email Address");
		getActionItemsInstance().sendKeysAction(getLoginRepoInstance().tbEmail, Constants.EMAIL_FARMER);
		getActionItemsInstance().sendKeysAction(getLoginRepoInstance().tbNationalId,
				String.valueOf(getActionItemsInstance().getRandomNumber(10)));
		getActionItemsInstance().scrollUntilVisibleText("copy");
		// if National ID Expiry date present
		if (getActionItemsInstance().isDisplayedAction(getLoginRepoInstance().calendarNationalIdExpiry)) {
			getActionItemsInstance().clickAction(getLoginRepoInstance().calendarNationalIdExpiry);
			// TODO to be checked in all origins
			// selectDate(Constants.NATIONAL_ID_EXPIRY);
			// selectDate();
			selectCompleteDate(Constants.NATIONAL_ID_EXPIRY);
		}
		getActionItemsInstance().clickAction(getLoginRepoInstance().txtAddUniqueIdPhotoNew);
		getActionItemsInstance().uploadImage();
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNext);
		getActionItemsInstance().reportStepLog("Personal details are filled in successfully");
	}

	private void fillMobileNumber() {
		String startDigit = "";
		int randomDigitCount = 0;
		switch (AppiumUtil.country) {
		case "Cambodia":
			startDigit = "96";
			randomDigitCount = 7;
			break;

		case "Peru":
			startDigit = "9";
			randomDigitCount = 8;
			break;

		case "Colombia":
			startDigit = "31";
			randomDigitCount = 9;
			break;

		case "Guatemala":
			startDigit = "22";
			randomDigitCount = 6;
			break;

		case "Honduras":
			startDigit = "3";
			randomDigitCount = 7;
			break;

		case "Mozambique":
			startDigit = "800";
			randomDigitCount = 6;
			break;

		case "Indonesia":
			startDigit = "812";
			randomDigitCount = 7;
			break;

		case "Vietnam":
			startDigit = "81";
			randomDigitCount = 9;
			break;

		}

		getActionItemsInstance().reportStepLog("Country: " + AppiumUtil.country + " Starting digit: " + startDigit
				+ " Random digit count: " + randomDigitCount);

		String PhoneNumberSetting = getApiActions().getRegistrationSettings();
		if (PhoneNumberSetting.equals("WITHOUT_ZERO")) {
			getActionItemsInstance()
					.reportStepLog("Admin portal is configured with  without-zero option in phone number");
			getActionItemsInstance().sendKeysAction(getLoginRepoInstance().tbPhoneNo,
					startDigit.concat(String.valueOf(getActionItemsInstance().getRandomNumber(randomDigitCount))));
		} else if (PhoneNumberSetting.equals("WITH_ZERO")) {
			getActionItemsInstance().reportStepLog("Admin portal is configured with zero option in phone number");
			getActionItemsInstance().sendKeysAction(getLoginRepoInstance().tbPhoneNo, "0".concat(
					startDigit.concat(String.valueOf(getActionItemsInstance().getRandomNumber(randomDigitCount)))));
		} else {
			getActionItemsInstance()
					.reportStepLog("Admin portal is configured with remove zero option in phone number");
			getActionItemsInstance().sendKeysAction(getLoginRepoInstance().tbPhoneNo, "0".concat(
					startDigit.concat(String.valueOf(getActionItemsInstance().getRandomNumber(randomDigitCount)))));
		}
	}

	public void selectFarmerLead() {
		getActionItemsInstance().sendKeysAction(getLoginRepoInstance().tbSearch, "auto farmerlead");
		getActionItemsInstance().clickAction(getLoginRepoInstance().imgSearch);
		getActionItemsInstance().clickAction(getLoginRepoInstance().rdFarmerSearchFirstResult);
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNext);
		getActionItemsInstance().reportStepLog("FarmerLead is selected during farmer registration");
	}

	public void addAddress(String subDist, String village, String addr) {

		// select from sub district dropdown if it exists
		if (getLoginRepoInstance().ddSubDistrict.size() > 0) {
			getActionItemsInstance().selectByVisibleText(getLoginRepoInstance().ddSubDistrict.get(0), subDist);
			getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNext);
		}

		// select from village dropdown if it exists
		if (getLoginRepoInstance().ddVillage.size() > 0) {
			getActionItemsInstance().selectByVisibleText(getLoginRepoInstance().ddVillage.get(0), village);
			getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNext);
		}

		// getActionItemsInstance().clickAction(getLoginRepoInstance().tbAddress);
		getActionItemsInstance().sendKeysAction(getLoginRepoInstance().tbAddress, addr);
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNext);

		getActionItemsInstance().reportStepLog("Address details are filled in successfully");
	}

	public void verifyFarmerDetails() {
		/* verify personal data & farmerlead details */
		Stream.of(getLoginRepoInstance().imgProfilePicture, getLoginRepoInstance().txtFullName,
				getLoginRepoInstance().txtMobileNo, getLoginRepoInstance().txtDob,
				getLoginRepoInstance().txtFarmerProgram, getLoginRepoInstance().txtUniqueId,
				getLoginRepoInstance().txtUniqueIdExpiryDate, getLoginRepoInstance().txtFarmerLeadName,
				getLoginRepoInstance().txtFarmerLeadId).forEach(ele -> getActionItemsInstance().isDisplayedAction(ele));
		getActionItemsInstance().reportStepLog("Personal data verified");
		/* verify address details */
		getActionItemsInstance().isDisplayedAction(getLoginRepoInstance().txtAddress);
		getActionItemsInstance().reportStepLog("Address is verified");
		/* accept license and policy */
		getActionItemsInstance().scrollUntilVisibleText("Privacy Policy");
		getActionItemsInstance().clickAction(getLoginRepoInstance().lnkLicense);
		getActionItemsInstance().isDisplayedAction(getLoginRepoInstance().titleEndUserLicense);
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNavigateUp);
		// getActionItemsInstance().clickAction(getLoginRepoInstance().lnkPrivacyPolicy);
		// getActionItemsInstance().isDisplayedAction(getLoginRepoInstance().titlePrivacyPolicy);
		// getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNavigateUp);
		getActionItemsInstance().clickAction(getLoginRepoInstance().chkLicense);
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnConfirm);
		getActionItemsInstance().reportStepLog("Policies are verified and accepted");
	}

	public void selectCompleteDate(String dateString) throws ParseException {

		LocalDate date = LocalDate.parse(dateString, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
		String formattedDate = DateTimeFormatter.ofPattern("d-MMMM-yyyy").format(date);
		getActionItemsInstance().reportStepLog("Given date is: " + dateString + " formatted date is: " + formattedDate);
		String targetDate = formattedDate.split("-")[0];
		String targetMonth = formattedDate.split("-")[1];
		String targetYear = formattedDate.split("-")[2];

		getActionItemsInstance().scrollAndClick(targetYear);
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnOk);
	/*	int currentMonth = getMonthNumber(
				getActionItemsInstance().getTextAction(getLoginRepoInstance().txtCurrentMonth));
		int monthOffset = getMonthNumber(targetMonth) - currentMonth;
		getActionItemsInstance().reportStepLog("Month offset: " + monthOffset);
		if (monthOffset != 0) {
			WebElement directionEle = (monthOffset > 0) ? getAndroidRepoInstance().btnNextMonth
					: getAndroidRepoInstance().btnPrevMonth;
			selectMonth(targetMonth, directionEle);
		} else {
			getActionItemsInstance().reportStepLog("Target month is already selected in calendar");
		}

		getActionItemsInstance().clickByVisibleText(targetDate);
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnFinish);*/
	}

	public void selectDate() {
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNext);
		getActionItemsInstance().clickByVisibleText(Constants.SAMPLE_DATE);
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnFinish);
	}

	public int getMonthNumber(String month) throws ParseException {

		Date date = new SimpleDateFormat("MMM").parse(month);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int monthNumber = cal.get(Calendar.MONTH) + 1;
		return monthNumber;
	}

	public void selectMonth(String month, WebElement swipeDirection) {
		boolean found = false;

		while (found == false) {
			boolean isPresent = driver.findElementsByXPath("//*[@text='" + month + "']").size() > 0;
			if (isPresent == true) {
				found = true;
				getActionItemsInstance().clickAction(driver.findElementByXPath("//*[@text='" + month + "']"));
				getActionItemsInstance().reportStepLog(month + " Month is selected");
			} else
				getActionItemsInstance().clickAction(swipeDirection);
		}
	}

	public void enterOTP(String userId) throws ClassNotFoundException, SQLException {

		char[] arrOtp = getDatabaseUtil().getAuthorizationOTP(userId).toCharArray();
		for (int i = 0; i < arrOtp.length; i++) {
			getActionItemsInstance().sendKeysAction(getHomeRepoInstance().tbOtp.get(i), Character.toString(arrOtp[i]));
		}
		getActionItemsInstance().reportStepLog("OTP entered");
	}

	public void navigateToRegisterFarmerLink() {
		getActionItemsInstance().clickByVisibleText("Register");
		// getActionItemsInstance().(getLoginRepoInstance().lnkRegisterHere);
		getActionItemsInstance().selectByVisibleText(getAndroidRepoInstance().commodityddSelecitonSignup,
				AppiumUtil.commodity);
		getActionItemsInstance().assertText(getAndroidRepoInstance().txtHeadTitle.getText(), "Sign Up");
		getActionItemsInstance().reportStepLog("Navigated to farmer sign up screen");
	}

	public void searchFarmerleadBy(String cond, String val) {
		// getActionItemsInstance().clickAction(getLoginRepoInstance().ddSearchBy);
		switch (cond) {
		case "farmerName":
			getActionItemsInstance().clickAction(getLoginRepoInstance().rdName);
			break;
		case "farmerId":
			getActionItemsInstance().clickAction(getLoginRepoInstance().rdFarmerId);
			val = val.replaceAll("....", "$0 ").replaceAll(".....(?!$)", "$0 "); // To insert space between country code
																					// & Id
			break;
		case "phoneNo":
			getActionItemsInstance().clickAction(getLoginRepoInstance().rdPhoneNo);
			break;
		default:
			getActionItemsInstance().reportStepLog("Incorrect search input: " + cond);
			break;
		}
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNext);
		getActionItemsInstance().sendKeysAction(getLoginRepoInstance().tbSearch, val);
		getActionItemsInstance().clickAction(getLoginRepoInstance().imgSearch);
		getActionItemsInstance().scrollUntilVisibleText("results");
	}

	public void verifyFarmerleadDetails(String cond, String val) {
		getActionItemsInstance().waitAction(getLoginRepoInstance().srchResultCount, 10);
		String cnt = getActionItemsInstance().getTextAction(getLoginRepoInstance().srchResultCount).split(" ")[0];
		getActionItemsInstance().reportStepLog("Search results count is: " + cnt);
		assertNotEquals("No", cnt); // Check if does not show No results
		int count = Integer.parseInt(cnt);
		switch (cond) {
		case "farmerName":

			for (int i = 1; i <= count; i++) {
				List<AndroidElement> elements = driver.findElementsById("farmer_name");
				getActionItemsInstance().reportStepLog("Farmer name is: " + elements.get(i - 1).getText());
				assertTrue(elements.get(i - 1).getText().contains(val),
						"Incorrect results fetched. Expected " + val + " actual: " + elements.get(i - 1).getText());
			}

			break;
		case "farmerId":
			assertEquals(getLoginRepoInstance().txtFarmerId.getText().replaceAll("Farmer Lead ID", "")
					.replaceAll("\\s+", ""), val);
			break;

		case "phoneNo":
			assertEquals(getLoginRepoInstance().txtPhoneNo.getText().replaceAll("(^\\+[0-9]*)|(\\s+)", ""), val);
			break;

		default:
			break;
		}

	}

	public void navigateToSearchFLScreen(String subDist, String village, String addr)
			throws InterruptedException, ParseException {

		getActionItemsInstance().waitAction(getLoginRepoInstance().txtFarmer, 30);
		getLoginActionInstance().navigateToRegisterFarmerLink();
		addPersonalDetails();
		addAddress(subDist, village, addr);
		// getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNext);
		verifyFarmerDetails();
		getActionItemsInstance().waitAction(getLoginRepoInstance().txtSuccessMsg, 15);
		getActionItemsInstance().isDisplayedAction(getLoginRepoInstance().txtSuccessMsg);
		newFarmerId = getLoginRepoInstance().txtRegisFarmerId.getText().replaceAll("\\s", "").replace("-", "");
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnOk);
		getActionItemsInstance()
				.reportStepLog("Farmer registration is successful and registered farmer id is: " + newFarmerId);

	}
	// getActionItemsInstance().reportStepLog("Navigated to search Farmerlead
	// screen"); }

}
