package com.olamnet.farmer.stepdefinition;

import static org.testng.Assert.assertTrue;

import java.util.stream.Stream;

import org.openqa.selenium.WebElement;

import com.cucumber.listener.Reporter;
import com.olamnet.farmer.utilities.BaseStepAction;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class CropFeedbackStep extends BaseStepAction {
	@Given("^the user is on crop feedback screen$")
	public void the_user_is_on_crop_feedback_screen() throws Throwable {
		
		getActionItemsInstance().clickAction(getAndroidRepoInstance().imgHomeMenu);	
		getActionItemsInstance().clickAction(getCropFeedbackRepoInstance().menuSurveyOpt);
		getActionItemsInstance().waitForProgressBar();	
		getActionItemsInstance().addLogWithScreenShot("Share with Olam screen...");			
		
		//getActionItemsInstance().clickAction(getAndroidRepoInstance().imgHomeMenu.get(0));
		//getActionItemsInstance().scrollDownViewByXpath("//*[@text='Crop Feedback']");
		//getActionItemsInstance().clickAction(getHomeRepoInstance().btnCropFeedback);
		//getActionItemsInstance().verifyText(getAndroidRepoInstance().txtTitle.getText(), "Crop Feedback");
	}

	

	@Then("^submit sample crop feedback$")
	public void submit_sample_crop_feedback() throws Throwable {

		getCropFeedbackActionInstance().submitCropFeedback();

	}
}
