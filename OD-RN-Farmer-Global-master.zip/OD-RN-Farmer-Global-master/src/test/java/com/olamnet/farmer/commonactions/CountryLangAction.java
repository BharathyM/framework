package com.olamnet.farmer.commonactions;

import com.cucumber.listener.Reporter;
import com.olamnet.farmer.utilities.AppiumUtil;
import com.olamnet.farmer.utilities.AppiumServerTest;
import com.olamnet.farmer.utilities.BaseStepAction;
import com.olamnet.farmer.utilities.Constants;

import io.appium.java_client.android.AndroidDriver;

public class CountryLangAction extends BaseStepAction {
	AndroidDriver driver;
	public static CountryLangAction inst_CountryLangAction = null;

	public CountryLangAction(AndroidDriver driver) {
		this.driver = driver;
	}
	public static CountryLangAction getInstance() {
		if (inst_CountryLangAction == null)
			inst_CountryLangAction = new CountryLangAction(AppiumUtil.driver);
		return inst_CountryLangAction;
	}
	
	//Permission popup handling method in origin selection screen
		public void allowPermissions() throws InterruptedException
		{
			getActionItemsInstance().addLogWithScreenShot("SplashScreen");
			Thread.sleep(5000);
			if(getActionItemsInstance().isDisplayedAction(getAndroidRepoInstance().permissionAllowforCamera)) 			{
				Thread.sleep(3000);
			getActionItemsInstance().clickAction(getAndroidRepoInstance().permissionAllowforCamera);
			getActionItemsInstance().reportStepLog("Allow Olam Direct - UAT to take pictures and record video?");
			
			Thread.sleep(2000);
			getActionItemsInstance().clickAction(getAndroidRepoInstance().permissionAllowforCamera);
			getActionItemsInstance().reportStepLog("Allow Olam Direct - UAT to access this device’s location?");			
			//if(getAndroidRepoInstance().permissionpopupBytext3.isDisplayed())
			//{				
				//Thread.sleep(2000);				
			getActionItemsInstance().clickAction(getAndroidRepoInstance().permissionAllowforStorage);			
			getActionItemsInstance().reportStepLog("Allow Olam Direct - UAT to access photos and media on your device?");
			}
			else
			{
				getActionItemsInstance().reportStepLog("App Permission popups are not dispalyed ");		
			}
			//}			
		}
		
		
		//popup-1 - Allow Olam Direct - UAT to take pictures and record video?
		//popup-2	- Allow Olam Direct - UAT to access this device’s location?
		//Popup-3 - Allow Olam Direct - UAT to access photos and media on your device?
			
	
	//New Origin Selection method (by default india will select in device so reslect the origin again)
		public void selectCountryLangNew() throws InterruptedException {			
			//String origin1 = "Indonesia";					
			getActionItemsInstance().clickAction(getCountryLangRepoInstance().countryDD);  
			//Constants.COUNTRY_NAME_INDIA is for India orign and COUNTRY_NAME is for Brazil origin 
			getActionItemsInstance().clickByVisibleText(AppiumUtil.country);	
			
			Thread.sleep(2000);
			getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNEXT);
			getActionItemsInstance().addLogWithScreenShot("Country & Language");
			getActionItemsInstance().reportStepLog("Country and Language are selected");
			
		}
		
		public void selectOriginLang(String origin,String lang, String Commodity) throws InterruptedException{
			
		//origin selection 
			getActionItemsInstance().clickAction(getCountryLangRepoInstance().OriginSelectedDD);
			getActionItemsInstance().clickByVisibleText(origin);
			getActionItemsInstance().reportStepLog("Country selected: "+origin);
		//language selection 
			getActionItemsInstance().clickAction(getCountryLangRepoInstance().langDD);
			getActionItemsInstance().clickByVisibleText(lang);		
			getActionItemsInstance().reportStepLog("Language selected: "+lang);
		//commodity selection (if commodity dropdown displayed like Indonesia
			if(getActionItemsInstance().isDisplayedAction(getCountryLangRepoInstance().commodityddlableText))
			{
				System.out.println("conditon1 passed:::::");
			getActionItemsInstance().clickAction(getCountryLangRepoInstance().commodityDD);
			getActionItemsInstance().clickByVisibleText(Commodity);
			getActionItemsInstance().reportStepLog("Commodity selected: "+Commodity);
			}
			Thread.sleep(1000);
			System.out.println("conditon1 failed:::::");
			getActionItemsInstance().addLogWithScreenShot("Country & Language are selected");
			getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNEXT);			
			
		}
		
	
		
}
