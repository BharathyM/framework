package com.olamnet.farmer.objectrepository;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.olamnet.farmer.utilities.AppiumUtil;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindAll;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AndroidFindBys;

public class LoginRepo extends AbstractRepository {

	public static LoginRepo inst_LoginRepo = null;

	public LoginRepo(AndroidDriver driver) {
		super(driver);
	}

	public static LoginRepo getInstance() {
		if (inst_LoginRepo == null)
			inst_LoginRepo = new LoginRepo(AppiumUtil.driver);
		return inst_LoginRepo;
	}
	
	@AndroidFindBy(xpath = "//*[@text='Select Login Type' and (./preceding-sibling::* | ./following-sibling::*)[./*[@class='android.view.ViewGroup']]]")
	public AndroidElement labelTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Select Login Type' and ./parent::*[./parent::*[@class='android.view.ViewGroup']]]/following-sibling::*")
	public AndroidElement inputHelpText;
	
	@AndroidFindBy(xpath = "//*[@text='OD ID']")
	public AndroidElement odIDLoginOption;
	
	@AndroidFindBy(xpath = "//*[@text='OFIS ID']")
	public AndroidElement ofisIdLoginOption;
	
	@AndroidFindBy(xpath = "//*[@text='Mobile number']")
	public AndroidElement mobileLoginOption;
	
	@AndroidFindBy(xpath = "//*[@text='Unique ID']")
	public AndroidElement uniqueIdLoginOpt;
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.EditText']")
	public AndroidElement inputTxt;
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.EditText']")
	public AndroidElement odIDInputtxt;
	
	@AndroidFindBy(xpath = "//*[@class='android.view.ViewGroup'] [2] /*[@class='android.widget.EditText']")
	public AndroidElement mobileInputTxt;
	
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.EditText']/../following-sibling::*[@class='android.view.ViewGroup']/*")
	public AndroidElement termsChxbox;
	
	@AndroidFindBy(xpath = "//*[@text='I have read and agree to End User License Agreement and Privacy notice']")
	public AndroidElement tocTxt;
	
	
	
	@AndroidFindBy(xpath = "//*[@text='Login with OTP']")
	public AndroidElement otpLink;
	
	@AndroidFindBy(xpath = "//*[@text='OTP']")
	public AndroidElement otppopuptxt;
	
	@AndroidFindBy(xpath = "(//*[@class='android.view.ViewGroup' and ./parent::*[@id='OTPInputView']]/*[@id='inputSlotView'])")
	public AndroidElement otpInputfields;	
	
	@AndroidFindBy(xpath = "//*[@text='Login with QR Code']")
	public AndroidElement qrCodeLink;
	
	@AndroidFindBy(xpath = "//*[@text='Invalid input/credentials, Try Again']")
	public AndroidElement invalidCredtxt;
	
	@AndroidFindBy(xpath = "//*[@text='OK']")
	public AndroidElement okBtn;
	
	@AndroidFindBy(xpath = "//*[@text='CONFIRM']")
	public AndroidElement confirmBtn;
	
	//OTP popup test 
	//*[@text='A 6 digits OTP has been sent to']
	//*[@text='A 6 digits OTP has been sent to']/following-sibling::*
	//*[@text='You can Resend OTP in 118 seconds']
	//*[@text='Resend OTP']
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.HorizontalScrollView']/../../../preceding-sibling::*[@class='android.view.ViewGroup']/*")
	public AndroidElement callImageinLogin;
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.HorizontalScrollView']/../../../preceding-sibling::*[@class='android.view.ViewGroup'][1]")
	public AndroidElement ofiLogo;	
	 
	@AndroidFindBy(xpath = "//*[@text='CALL Olam']/..//*[@class='android.view.ViewGroup']//*[@class='android.view.ViewGroup']")
	public AndroidElement closeHelpPopup;
	
	@AndroidFindBy(xpath = "//*[starts-with(text(),'Contact')]")
	public AndroidElement popupText;
	
	@AndroidFindBy(xpath = "//*[starts-with(text(),'Contact')]/preceding-sibling::*[@class='android.view.ViewGroup'][1]")
	public AndroidElement popupImage;
	
	@AndroidFindBy(xpath = "//*[starts-with(text(),'Contact')]/preceding-sibling::*[@class='android.view.ViewGroup'][1]/following-sibling::*[@class='android.view.ViewGroup']/*")
	public AndroidElement callBtnHelpline;	
	
	@AndroidFindBy(xpath = "//*[@text='A 6 digits OTP has been sent to']/following-sibling::*")
	public AndroidElement phoneNuminOTP;
	
	@AndroidFindBy(xpath = "(//*[@text='A 6 digits OTP has been sent to']/following-sibling::*/..//*[@id='OTPInputView']/*/*/*[@id='textInput'])[1]")
	public AndroidElement otpInput;
	
				
	
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'textView1')]")
	public AndroidElement txtFarmer;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'textView2')]")
	public AndroidElement txtEnterFarmerId;

	@AndroidFindBy(id = "imgLogo")
	public AndroidElement imgOlamDigitalOriginationLogo;

	@AndroidFindBy(id = "imgCall")
	public AndroidElement imgHelpline;

	@AndroidFindBy(id = "signUp")
	public AndroidElement txtSignUp;

	@AndroidFindBy(id = "txtTitle")
	public AndroidElement txtOlamHelpCenter;

	@AndroidFindBy(id = "call_olam_text")
	public AndroidElement txtCallOlam;

	@AndroidFindBy(id = "imgeClose")
	public AndroidElement imgClose;

	@AndroidFindBy(xpath = "//*[@id='signUp']")
	public AndroidElement lnkRegisterHere;
	
  //  @AndroidFindBy(xpath = "//*[contains(@text,'Register here')]")

	@AndroidFindBy(xpath = "//*[@text='LOGIN']")
	public AndroidElement btnLogin;

	@AndroidFindBy(id = "selected_image")
	public AndroidElement imgProfilePik;

	@AndroidFindBy(id = "rdoFemale")
	public AndroidElement btnMrs;

	@AndroidFindBy(id = "edit_name")
	public AndroidElement tbName;

	@AndroidFindBy(id = "edit_mobile")
	public AndroidElement tbPhoneNo;
	
	@AndroidFindBy(id = "edit_email")
	public AndroidElement tbEmail;

	@AndroidFindBy(id = "edit_ktp_id")
	public AndroidElement tbNationalId;	

	@AndroidFindBy(xpath = "//*[@*='Camera']")
	public AndroidElement btnCamera;

	@AndroidFindAll({ @AndroidBy(xpath = "//*[contains(@resource-id,'done')]"),@AndroidBy(xpath = "//*[@text='OK']"),
			@AndroidBy(xpath = "//*[contains(@resource-id,'review_ok_button')]") })
	public AndroidElement btnShutterDone;

	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'card_details')])[1]")
	public AndroidElement rdFarmerSearchFirstResult;

	@AndroidFindBy(id = "full_name_farmerlead_value")
	public AndroidElement txtFarmerLeadName;

	@AndroidFindBy(id = "farmerleadid_value")
	public AndroidElement txtFarmerLeadId;

	@AndroidFindBy(uiAutomator = "textContains(\"Successful\")")
	public AndroidElement txtSuccessMsg;

	@AndroidFindBy(id = "edit_dob")
	public AndroidElement calendarDob;

	@AndroidFindBy(id = "edit_ktp_valid_until")
	public AndroidElement calendarNationalIdExpiry;

	@AndroidFindBy(id = "txtTakeKtpPhoto")
	public AndroidElement txtAddUniqueIdPhoto;
	
	@AndroidFindBy(xpath = "//*[@text='Add KTP ID Scan copy	*	']")
	public AndroidElement txtAddUniqueIdPhotoNew;

	@AndroidFindBy(id = "subrel1")
	public List<AndroidElement> ddSubDistrict;

	@AndroidFindBy(id = "subrel2")
	public List<AndroidElement> ddVillage;

	@AndroidFindBy(id = "address_value")
	public AndroidElement tbAddress;

	@AndroidFindBy(id = "chkAgree")
	public AndroidElement chkLicense;

	@AndroidFindBy(xpath = "//*[contains(@text,'End User')]")
	public AndroidElement lnkLicense;

	@AndroidFindBy(xpath = "//*[contains(@text,'Privacy notice')]")
	public AndroidElement lnkPrivacyPolicy;

	@AndroidFindBy(id = "full_name_value")
	public AndroidElement txtFullName;

	@AndroidFindBy(id = "mobile_number_value")
	public AndroidElement txtMobileNo;

	@AndroidFindBy(id = "date_of_birth_value")
	public AndroidElement txtDob;

	@AndroidFindBy(id = "ktpid_value")
	public AndroidElement txtFarmerProgram;

	@AndroidFindBy(id = "ktpid_valid_value")
	public AndroidElement txtUniqueId;

	@AndroidFindBy(id = "farmerProg")
	public AndroidElement txtUniqueIdExpiryDate;

	@AndroidFindBy(id = "complete_address_value")
	public AndroidElement txtAddress;

	@AndroidFindBys({ @AndroidBy(xpath = "//*[@text='End User License']"), @AndroidBy(id = "toolbar_logo") })
	public WebElement titleEndUserLicense;

	@AndroidFindBys({ @AndroidBy(xpath = "//*[@text='Privacy Policy']"), @AndroidBy(id = "toolbar_logo") })
	public WebElement titlePrivacyPolicy;

	@AndroidFindBy(id = "selectedDayMonthYear")
	public AndroidElement txtCurrentMonth;

	@AndroidFindBy(id = "profile_image")
	public AndroidElement imgProfilePicture;	
	
	@AndroidFindBy(xpath = "//*[@text='Search Farmer Lead']")
	public AndroidElement searchFLheadingtext;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'searchbyet')]")
	public AndroidElement ddSearchBy;

	@AndroidFindBy(xpath = "//*[contains(@text,'Name')]")
	public AndroidElement rdName;

	@AndroidFindBy(xpath = "//*[contains(@text,'Phone')]")
	public AndroidElement rdPhoneNo;

	@AndroidFindBy(xpath = "//*[contains(@text,'ID')]")
	public AndroidElement rdFarmerId;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'searchTextId')]")
	public AndroidElement tbSearch;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'search_control')]")
	public AndroidElement imgSearch;

	@AndroidFindBy(id = "search_text_count")
	public AndroidElement srchResultCount;

	@AndroidFindBy(id = "farmer_id_txt1")
	public AndroidElement txtFarmerId;

	@AndroidFindBy(id = "displayID2")
	public AndroidElement txtRegisFarmerId;

	@AndroidFindBy(id = "phone_number1")
	public AndroidElement txtPhoneNo;

	@AndroidFindBy(id = "imgProfileQrCode")
	public AndroidElement imgQrCode;

}
