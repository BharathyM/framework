package com.olamnet.farmer.commonactions;

import java.util.Properties;
import java.util.concurrent.atomic.AtomicBoolean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.olamnet.farmer.utilities.AppiumUtil;
import com.olamnet.farmer.utilities.BaseStepAction;

import io.appium.java_client.android.AndroidDriver;

public class CreateDropoffAction extends BaseStepAction{
	
	AndroidDriver driver;
	String tranID;
	public static CreateDropoffAction inst_CreateDropoffAction = null;

	public CreateDropoffAction(AndroidDriver driver) {
		this.driver = driver;
	}

	public static CreateDropoffAction getInstance() {
		if (inst_CreateDropoffAction == null)
			inst_CreateDropoffAction = new CreateDropoffAction(AppiumUtil.driver);
		return inst_CreateDropoffAction;
	}
	
	public void createDropoff(String commodity, String purchaseType, String tradingProduct, String weightQty,String paymentMode) {
		
		//getActionItemsInstance().scrollUpViewByXpath("//*[@text='" + commodity + "']");
		getActionItemsInstance().waitForProgressBar();
		getActionItemsInstance().waitForProgressBar();
		WebElement wbCommodity = driver.findElement(By.xpath("//*[@text='" + commodity + "']"));
		getActionItemsInstance().clickAction(wbCommodity);
		
		
		if(getActionItemsInstance().isDisplayedAction(getCreateDropoffRepo().priceExpiryDetails )) 		{
				getActionItemsInstance().reportStepLog("Price Expiry Time: "+getCreateDropoffRepo().priceExpiryDateTime.getText());				
				getActionItemsInstance().reportStepLog("Drop-Off Completion Details:: "+getCreateDropoffRepo().dropoffCompletionDateTimeTxt.getText());				
				getActionItemsInstance().addLogWithScreenShot("Price Details...");
				getActionItemsInstance().clickAction(getCreateDropoffRepo().purchaseTypeDD);
				getActionItemsInstance().clickByVisibleText(purchaseType);
				getActionItemsInstance().reportStepLog("Selecteed Purchase Type: "+getCreateDropoffRepo().ddSelectedPurType.getText());
				getActionItemsInstance().addLogWithScreenShot("PurchaseType dropdown Details screen...");
				
				getActionItemsInstance().scrollDownViewByXpath("//*[@text='" + tradingProduct + "']");				
				
				String tpPrice = driver.findElement(By.xpath("//*[@text='"+tradingProduct+"']/following-sibling::*/*/*")).getText();
				String  prices = tpPrice.trim();
				//int priceF=Integer.valueOf(prices);
			//	int qty=Integer.valueOf(weightQty);				
				//int estimatedAmount = priceF * qty;
			//	System.out.println("::::::::::::::::::"+priceF+"::"+prices+":::"+qty+"::::"+estimatedAmount);				
				
				getActionItemsInstance().reportStepLog(" Price: "+prices);		
				
				WebElement wbPrice = driver.findElement(By.xpath("//*[@text='"+tradingProduct+"']/following-sibling::*/*/*/following-sibling::*"));
				getActionItemsInstance().clickAction(wbPrice);
				getActionItemsInstance().waitForProgressBar();
				
				getActionItemsInstance().verifyText(getCreateDropoffRepo().headingTxtDropoff.getText(), "Schedule Drop-off");
				enterWeight(weightQty);
				getActionItemsInstance().reportStepLog(""+getCreateDropoffRepo().estimationTPWeightDetails.getText())	;	
				getActionItemsInstance().reportStepLog(""+getCreateDropoffRepo().estimatedValue.getText())	;		
				
				selectPayment(paymentMode);
				getActionItemsInstance().clickAction(getCreateDropoffRepo().finishBtn);
				getActionItemsInstance().reportStepLog(
						"Dropoff creation is successful for: " + commodity + " " + tradingProduct + " " + paymentMode);
				
				
		}
        else if(getActionItemsInstance().isDisplayedAction(getCreateDropoffRepo().priceExpiredTxt))
		{
	   	getActionItemsInstance().reportStepLog("Price Expiry Time: "+getCreateDropoffRepo().priceExpiredTxt.getText());
		}
		
	}
	
	public void verifyDropoffCreationMsg(String paymentMode,String tranStatus) {
		
		getActionItemsInstance().verifyText(getCreateDropoffRepo().headinglblTxtInConfirmDropOff.getText(), "'Drop-off Confirmation");
		getActionItemsInstance().verifyText(getCreateDropoffRepo().confirmdropoffMessageheadigTxt.getText(), "'Drop-off Confirmation!");
		getActionItemsInstance().reportStepLog(getCreateDropoffRepo().transactionIDTxt.getText()+" : "+getCreateDropoffRepo().transactionID.getText());
		tranID = getCreateDropoffRepo().transactionID.getText();
		getActionItemsInstance().reportStepLog(getCreateDropoffRepo().descriptionTxt.getText()+" : "+getCreateDropoffRepo().descriptionDetails.getText());
		getActionItemsInstance().reportStepLog(getCreateDropoffRepo().createdOnTxt.getText()+" : "+getCreateDropoffRepo().createdOnDateTime.getText());	
		
		getActionItemsInstance().addLogWithScreenShot("Drop-off Confirmation screen...");
		switch (paymentMode) {
		case "Bank":
			getActionItemsInstance().reportStepLog("Payment Mode: "+paymentMode+" Payment In  : "+getCreateDropoffRepo().bankPaymentInConfirmDropoffMessage.getText());

			break;

		case "Half payment":
			getActionItemsInstance().reportStepLog("Payment Mode: "+paymentMode+" Payment In  : "+getCreateDropoffRepo().halfBankPaymentTxtInConfirmDropoffMessage.getText());

			break;

		case "Cash":
			getActionItemsInstance().reportStepLog("Payment Mode: "+paymentMode+" Payment In  : "+getCreateDropoffRepo().cashPaymentTxtinConfirmDropoffMessage.getText());

			break;

		default:
			getActionItemsInstance().reportStepLog("Incorrect payment mode: " + paymentMode);

			break;
		}	
		if(tranStatus.equals("Accepted")) {
		getActionItemsInstance().clickAction(getCreateDropoffRepo().Okbtn);	}
		else {
			getActionItemsInstance().clickAction(getCreateDropoffRepo().cancelDropOffBtn);
		}
		
		getActionItemsInstance().waitForProgressBar();	
		
	}
	
	private void enterWeight(String weightQty) {		
		getActionItemsInstance().reportStepLog(getCreateDropoffRepo().dropoffCompletionLabelTxt.getText());
		getActionItemsInstance().sendKeysAction(getCreateDropoffRepo().weightInput, weightQty);
		getActionItemsInstance().reportStepLog("Entered weight");		
		getActionItemsInstance().reportStepLog("Weight UOM : "+getCreateDropoffRepo().weightUOM.getText());
		
		getActionItemsInstance().clickAction(getCreateDropoffRepo().proccedBtn);
				
	}

	public void selectPayment(String paymentMode) {
		switch (paymentMode) {
		case "Bank":
			getActionItemsInstance().clickAction(getCreateDropoffRepo().radioBtnBankType);

			break;

		case "Half Payment":
			getActionItemsInstance().clickAction(getCreateDropoffRepo().radioBtnHalfPaymentType);

			break;

		case "Cash":
			getActionItemsInstance().clickAction(getCreateDropoffRepo().radioBtnCashType);

			break;

		default:
			getActionItemsInstance().reportStepLog("Incorrect payment mode: " + paymentMode);

			break;
		}
		getActionItemsInstance().reportStepLog("Selected payment mode with text : " + paymentMode);

		getActionItemsInstance().addLogWithScreenShot("Payment mode selection screen...");
	}
	
	public void verifyCreatedDropOffsInTodaysDropoffsList(String paymentMode,String tranStatus)	{
		getActionItemsInstance().clickAction(getCreateDropoffRepo().dropOffTab);		
		getActionItemsInstance().verifyText(getCreateDropoffRepo().dropOffTab.getText(), "Drop-off");	
		getActionItemsInstance().addLogWithScreenShot("Drop-off List screen...");
		getActionItemsInstance().clickAction(getCreateDropoffRepo().firstDropoff);
		getActionItemsInstance().waitForProgressBar();
		getActionItemsInstance().addLogWithScreenShot("Confirm Drop Detail screen...");
		getActionItemsInstance().verifyText(getCreateDropoffRepo().headinglblTxtInConfirmDropOff.getText(), "'Drop-off Confirmation");
		//getActionItemsInstance().verifyText(getCreateDropoffRepo().confirmdropoffMessageheadigTxt.getText(), "'Drop-off Confirmation!");
		getActionItemsInstance().reportStepLog(getCreateDropoffRepo().transacIDtxt.getText()+" : "+getCreateDropoffRepo().tranID.getText());
		
		System.out.println("confirm dropoff message tranID : "+tranID);
		
		if(tranID.equals(getCreateDropoffRepo().tranID.getText())) {
		
		getActionItemsInstance().reportStepLog(getCreateDropoffRepo().createdOnLblTxt.getText()+" : "+getCreateDropoffRepo().createdDateTime.getText());
		getActionItemsInstance().reportStepLog(getCreateDropoffRepo().descriptLblTxt.getText()+" : "+getCreateDropoffRepo().descDetails.getText());	
		
		switch (paymentMode) {
		case "Bank":
			getActionItemsInstance().reportStepLog("Payment Mode: "+paymentMode+" Payment In  : "+getCreateDropoffRepo().bankPaymentInConfirmDropoffMessage.getText());

			break;

		case "Half Payment":
			getActionItemsInstance().reportStepLog("Payment Mode: "+paymentMode+" Payment In  : "+getCreateDropoffRepo().halfBankPaymentTxtInConfirmDropoffMessage.getText());

			break;

		case "Cash":
			getActionItemsInstance().reportStepLog("Payment Mode: "+paymentMode+" Payment In  : "+getCreateDropoffRepo().cashPaymentTxtinConfirmDropoffMessage.getText());

			break;

		default:
			getActionItemsInstance().reportStepLog("Incorrect payment mode: " + paymentMode);

			break;
		}	
		}	
		
			getActionItemsInstance().clickAction(getCreateDropoffRepo().Okbtn);	
			
			
			getActionItemsInstance().waitForProgressBar();	
			
	
		
		//getActionItemsInstance().clickAction(getCreateDropoffRepo().backArrowBtn);	
	}
	
	public void cancelDropOff(){		
		//getActionItemsInstance().clickAction(getCreateDropoffRepo().cancelDropOffBtn);
		getActionItemsInstance().reportStepLog(getCreateDropoffRepo().tranIDInCancelReasons.getText());
		getActionItemsInstance().clickAction(getCreateDropoffRepo().cancelReasons);
		getActionItemsInstance().addLogWithScreenShot("Cancel Reasons screen...");
		getActionItemsInstance().reportStepLog(getCreateDropoffRepo().cancelReasons.getText());
		getActionItemsInstance().clickAction(getCreateDropoffRepo().cancelDropoffBtn);
		getActionItemsInstance().addLogWithScreenShot("Cancel Popup screen...");
		getActionItemsInstance().reportStepLog(getCreateDropoffRepo().cancelPopupTranID.getText());
		getActionItemsInstance().reportStepLog(getCreateDropoffRepo().cancelPopupTxtMsg.getText());
		getActionItemsInstance().clickAction(getCreateDropoffRepo().Okbtn);			
		
	}
	
	public void transctionSummary()
	{
		getActionItemsInstance().clickAction(getCreateDropoffRepo().transSummaryTab);
		getActionItemsInstance().reportStepLog("User switched to 'Transction Summary'");
		getActionItemsInstance().addLogWithScreenShot("Transction Summary Screen...");
		
		getActionItemsInstance().verifyText(getCreateDropoffRepo().tranSummaryLblTxt.getText(), "Transaction Summary");
		
		if(getActionItemsInstance().isDisplayedAction(getCreateDropoffRepo().noData)) {
			getActionItemsInstance().reportStepLog(getCreateDropoffRepo().noData.getText());
		}
		else
		{
			//implmentation is pending becuase of application issue 
			
		}
	}

}
