package com.olamnet.farmer.objectrepository;

import java.net.MalformedURLException;
import java.util.List;

import org.openqa.selenium.WebDriver;

import com.olamnet.farmer.utilities.AppiumUtil;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindAll;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class HomeRepo extends AbstractRepository {

	// static AndroidDriver<AndroidElement> driver;
	public static HomeRepo inst_HomeRepo = null;

	public HomeRepo(AndroidDriver driver) {
		super(driver);
	}

	public static HomeRepo getInstance() {
		if (inst_HomeRepo == null)
			inst_HomeRepo = new HomeRepo(AppiumUtil.driver);
		return inst_HomeRepo;
	}
	
	@AndroidFindBy(xpath = "(//*[@class='android.view.ViewGroup' and ./parent::*[@id='OTPInputView']]/*[@id='inputSlotView'])")
	public List<AndroidElement> otpInputfields;	

	@AndroidFindBy(xpath = "(//android.view.ViewGroup)[36]")
	public AndroidElement imgOlamLogo;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'txtDropoff')]")
	public AndroidElement txtDropOffToday;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'txtDropoffmsg')]")
	public AndroidElement txtDropOffMsg;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'home_beans_list')]")
	public AndroidElement tradingProductDropOffView;

	@AndroidFindBy(id = "price_recycler_view")
	public AndroidElement tradingProductPriceView;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'imgFarmerLead')]")
	public AndroidElement imgFarmerLead;

	@AndroidFindBy(id = "profile_image")
	public AndroidElement imgProfilePicture;

	@AndroidFindBy(id = "txtFarmerName")
	public AndroidElement txtFarmerName;

	@AndroidFindBy(id = "txtFarmerId")
	public AndroidElement txtFarmerId;

	@AndroidFindBy(id = "imgClose")
	public AndroidElement imgCloseIcon;

	@AndroidFindBy(xpath = "//*[contains(@text,'Cancel')]")
	public AndroidElement txtCancel;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'cancelBtnHeighlight')]")
	public AndroidElement txtCancelDropoff;

	@AndroidFindBy(xpath = "//*[contains(@text,'Cancelled')]")
	public AndroidElement txtCancelled;

	@AndroidFindBy(id = "txt_trans_id")
	public AndroidElement txtTxnId;

	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'cardlayout')])[1]")
	public AndroidElement txtCancelReason;

	@AndroidFindBy(xpath = "//*[@text='Home' and ./parent::*[@class='android.widget.Button']]")
	public AndroidElement btnHome;
	
	//PostLogin Helpline:::
	
	@AndroidFindBy(xpath = "//*[@class='android.view.ViewGroup'][3]//*/*")
	public AndroidElement helplineBtninHome;
	
	@AndroidFindBy(xpath = "//*[@text='CALL Olam']/../following-sibling::*[@class='android.view.ViewGroup']/following-sibling::*")
	public AndroidElement helplinepopupText;
	
	@AndroidFindBy(xpath = "//*[@text='CALL Olam']/../following-sibling::*[3]/*")
	public AndroidElement callBtnHelpline1;
	
	@AndroidFindBy(xpath = "//*[@text='CALL Olam']/following-sibling::*[@class='android.view.ViewGroup']/*")
	public AndroidElement clsButtonhelpline;
	

	@AndroidFindBy(id = "edit_weight")
	public AndroidElement tbWeight;

	@AndroidFindBy(className = "android.widget.EditText")
	public List<AndroidElement> tbOtp;

	@AndroidFindAll({ @AndroidBy(xpath = "//*[contains(@text,'Something went wrong')]"),
			@AndroidBy(xpath = "//*[contains(@text,'Error')]") })
	public List<AndroidElement> txtSomethingWentWrong;

	@AndroidFindBy(id = "txt_bank")
	public AndroidElement rdBank;

	@AndroidFindBy(id = "cashtv3")
	public AndroidElement rdCash;

	@AndroidFindBy(id = "half_bank_tv2")
	public AndroidElement rdBankCash;

	@AndroidFindBy(xpath = "//*[@text='Drop-off  Confirmation!']")
	public AndroidElement txtDropoffConfirmationMsg;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'logout')]")
	public AndroidElement btnExit;

	@AndroidFindBy(id = "license_checkbox")
	public AndroidElement chkLicense;

	@AndroidFindBy(id = "privacy_policy_checkbox")
	public AndroidElement chkPrivacyPolicy;
	
	@AndroidFindBy(xpath = "//*[@text='Home' and ./parent::*[@class='android.widget.Button']]")
	public AndroidElement homeInMenu;

	@AndroidFindBy(xpath = "//*[@text='View farmer profile' and ./parent::*[@class='android.widget.Button']]")
	public AndroidElement viewProfileMenu;

	@AndroidFindBy(xpath = "//*[@text='Weather Information']")
	public AndroidElement btnWeatherInformation;

	@AndroidFindBy(xpath = "//*[@text='Information of the Day']")
	public AndroidElement btnIod;

	@AndroidFindBy(xpath = "//*[@text='Other Feedback']")
	public AndroidElement btnOtherFeedback;

	@AndroidFindBy(xpath = "//*[@text='Crop Feedback']")
	public AndroidElement btnCropFeedback;

	@AndroidFindBy(id = "imgProfileQrCode")
	public AndroidElement imgQrCode;

	@AndroidFindBy(xpath = "//*[@text='Legal']")	
	public AndroidElement txtTermsAndConditions;

	@AndroidFindBy(xpath = "//*[contains(@text,'Privacy notice')]")
	public AndroidElement txtPrivacyPolicy;

	@AndroidFindBy(xpath = "//*[@text='End User License Agreement']")
	public AndroidElement txtEndUserLicense;
	
	@AndroidFindBy(xpath = "//*[starts-with(@text,'Last Accepted Date:')]")	
	public AndroidElement EULAPPLastAcceptedDate;
	
	@AndroidFindBy(xpath = "//*[starts-with(@text,'Version:')]")	
	public AndroidElement EULAPPVersion;
	
/* hamburger menu profile details name and id and profile image **/
	
	@AndroidFindBy(xpath = "//*[@text='Home' and ./parent::*[@class='android.widget.Button']]/../../../../preceding-sibling::*/../*[2]")	
	public AndroidElement profileImageinHamMenu;
	
	@AndroidFindBy(xpath = "//*[@text='Home' and ./parent::*[@class='android.widget.Button']]/../../../../preceding-sibling::*/../*[3]")	
	public AndroidElement proifileNameinHamMenu;
	
	@AndroidFindBy(xpath = "//*[@text='Home' and ./parent::*[@class='android.widget.Button']]/../../../../preceding-sibling::*/../*[4]")	
	public AndroidElement profileIDinHamMenu;
	
	@AndroidFindBy(xpath = "//*[@text='Home' and ./parent::*[@class='android.widget.Button']]/../../../../preceding-sibling::*/../*[5]")	
	public AndroidElement proifleQRcode;
	
	
		

}
