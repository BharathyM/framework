package com.olamnet.farmer.utilities;

import static com.olamnet.farmer.utilities.AppiumUtil.APPIUM_PORT;

import java.io.File;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.service.local.flags.ServerArgument;

public class StartAppium {

	private static AppiumDriverLocalService service;

	private static AndroidDriver driver;
	public static StartAppium startAppium = null;

	public static StartAppium getInstance() {
		if (startAppium == null)
			startAppium = new StartAppium();
		return startAppium;
	}

	public static void startAppium() {
		String osName = System.getProperty("os.name").toLowerCase();

		String nodePath = null;
		String appiumPath = null;
		if (osName.contains("windows")) {
			System.out.println("Identified os " + osName);
			nodePath = "C:/Program Files/nodejs/node.exe";
			appiumPath = System.getProperty("user.dir") + "\\node_modules\\appium\\build\\lib\\main.js";
		} else if (osName.contains("linux")) {
			nodePath = System.getenv("HOME") + "/.linuxbrew/bin/node";
			appiumPath = System.getenv("HOME") + "/.linuxbrew/lib/node_modules/appium/build/lib/main.js";
		}
		// For passing emulator : Include commented-out avd script below next to
		// AppiumServiceBuilder().
		System.out.println("Starting server on port: " + Integer.valueOf(APPIUM_PORT));

		/*
		 * service = AppiumDriverLocalService.buildService(new
		 * AppiumServiceBuilder().withArgument(new ServerArgument() { public String
		 * getArgument() { return "--avd"; } }, "Device2").usingDriverExecutable(new
		 * File(nodePath)).usingPort(Integer.valueOf(APPIUM_PORT)) .withAppiumJS(new
		 * File(appiumPath)));
		 */

		service = AppiumDriverLocalService.buildService(
				new AppiumServiceBuilder().usingDriverExecutable(new File(nodePath)).withIPAddress("127.0.0.1")
						.usingPort(Integer.valueOf(APPIUM_PORT)).withAppiumJS(new File(appiumPath)));

		// .withArgument(new ServerArgument(){ public String getArgument() {return
		// "--avd"; }}, "Device1"));
		service.start();
		System.out.println("Server started");
	}

	public static void stopAppium() {
		try {
			driver.quit();
			System.out.println("Driver quited");
			service.stop();
			System.out.println("Service stopped");
		} catch (Exception e) {
			System.out.println("Appium already stopped");
		}
	}

}
