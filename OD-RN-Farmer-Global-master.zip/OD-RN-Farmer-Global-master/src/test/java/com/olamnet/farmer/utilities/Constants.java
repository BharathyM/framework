package com.olamnet.farmer.utilities;

public class Constants {

	// -----------------------API Validation--------------------------------

	public final static String APP_ID = "";
	public final static String CONTENT_TYPE = "application/json";
	public final static String BEARER_TOKEN = "";
	public final static String POST_STRING = "Success";
	public final static String TOKEN_TYPE = "Bearer";
	public final static int PORTAL_CLIENT_ID = 3;
	public final static int FL_APP_CLIENT_ID = 2;

	/* Credentials */
	public final static String UAT_ADMIN_ID = "Admin_Indonesia";
	public final static String INDO_PROD_ADMIN_ID = "admin_indonesia";
	public final static String CAMBODIA_PROD_ADMIN_ID = "admin_cambodia";
	public final static String VIETNAM_PROD_ADMIN_ID = "admin_vietnam";
	public final static String TURKEY_PROD_ADMIN_ID = "admin_turkey";
	public final static String ADMIN_PASSWORD = "Olam123+";
	public final static String ADMIN_PASSWORD_CAMBODIA = "odadmin2019";

	/* Origin ID */
	public final static int INDO_ID = 1;
	public final static int Brazil_ID=3;
	public final static int NZD_ID=7;
	public final static int GHANA_ID = 2;
	public final static int CAMBODIA_ID = 4;
	public final static int PERU_ID = 5;
	public final static int VIETNAM_ID = 6;
	public final static int GUATEMALA_ID = 11;
	public final static int MOZAMBIQUE_ID = 10;
	public final static int TURKEY_ID = 8;
	public final static String LoginfirebasedefulatOTP = "123456";
	public final static String origin_name="Indonesia";
	public final static String lang_name="English";
	public final static String commodity_name="Cocoa";
	
	/* Commodity */
	public final static String Indo_Cocoa = "Cocoa";
	public final static String Indo_Arabica = "Arabica Sunda";
	public final static String Indo_Pepper = "Pepper";
	public final static String Indo_Aceh = "Arabica Aceh";
	public final static String Ghana_Cashew = "Cashew";
	public final static String Cambodia_Pepper= "Pepper";
	public final static String Vietnam_Cashew= "Cashew";
	public final static String Turkey_Commod= "Coffee Arbica";


	/* Farmer Login ID */
	public final static String INDO_UAT_Farmer_ID = "AJAJ-0228";
	public final static String INDO_PROD_Farmer_ID = "ZYZZ-0001";
	public final static String INDO_SIT_Farmer_ID = "OIOV-0010";
	public final static String GHANA_UAT_Farmer_ID = "NNAD-0009";
	public final static String GHANA_PROD_Farmer_ID = "NNAD-0009";
	public final static String CAMBODIA_UAT_Farmer_ID = "DBDB-0008";
	public final static String CAMBODIA_PROD_Farmer_ID = "ZYZZ-0001";
	public final static String PERU_UAT_Farmer_ID = "AJAJ-0015";
	public final static String PERU_PROD_Farmer_ID = "AJAJ-0015";
	public final static String VIETNAM_SIT_Farmer_ID = "THPC-0103";
	public final static String VIETNAM_UAT_Farmer_ID = "THPC-0191";
	public final static String VIETNAM_PROD_Farmer_ID = "THPC-0191";
	public final static String GUATEMALA_UAT_Farmer_ID = "JLGC-0011";
	public final static String GUATEMALA_PROD_Farmer_ID = "JLGC-0011";
	public final static String MOZAMBIQUE_UAT_Farmer_ID = "LKJR-0036";
	public final static String MOZAMBIQUE_PROD_Farmer_ID = "LKJR-0036";
	public final static String TURKEY_UAT_Farmer_ID = "AAAA-0064";
	public final static String TURKEY_PROD_Farmer_ID = "AAAA-0064";

	/* FarmerLead Login ID */
	public final static String INDO_UAT_FL_ID = "AJAJ-0055";
	public final static String INDO_SIT_FL_ID = "AJAJ-1320";
	public final static String INDO_PROD_FL_ID = "AJAJ-0015";
	public final static String GHANA_UAT_FL_ID = "NNAD-0008";
	public final static String GHANA_PROD_FL_ID = "NNAD-0008";
	public final static String CAMBODIA_UAT_FL_ID = "DBCS-0004";
	public final static String CAMBODIA_PROD_FL_ID = "DBCS-0004";
	public final static String PERU_UAT_FL_ID = "AJAJ-0015";
	public final static String PERU_PROD_FL_ID = "AJAJ-0015";
	public final static String VIETNAM_SIT_FL_ID = "THPC-0102";
	public final static String VIETNAM_UAT_FL_ID = "THPC-0186";
	public final static String VIETNAM_PROD_FL_ID = "THPC-0186";
	public final static String COLOMBIA_UAT_FL_ID = "AGAO-0010";
	public final static String COLOMBIA_PROD_FL_ID = "AGAO-0010";
	public final static String GUATEMALA_UAT_FL_ID = "JLGC-0010";
	public final static String GUATEMALA_PROD_FL_ID = "JLGC-0010";
	public final static String MOZAMBIQUE_UAT_FL_ID = "LKJR-0035";
	public final static String MOZAMBIQUE_PROD_FL_ID = "LKJR-0035";

	/* DB Queries */
	public final static String SQL_SELECT_TRANS_OTP = "SELECT TOP (1) [transaction_otp] FROM [purchase].[transaction_otp]  ORDER BY created_ts desc";
	public final static String SQL_SELECT_VERIFICATION_OTP = "SELECT TOP (1) [otp] FROM [farmer].[otp_management]  ORDER BY created_ts desc";
	public final static String SQL_SELECT_AUTHORIZATION_OTP = "SELECT TOP(1) [OTP] FROM [authorizationn].[users] ORDER BY updated_ts DESC;";
	public final static String SQL_SELECT_TRADPROD_ID = "select TOP(1) [TRADING_PRODUCT_ID] from [MASTER].[TRADING_PRODUCT] where name like '";
	public final static String SQL_SELECT_PRODUCT_ID = "select TOP(1) [PRODUCT_ID] from [MASTER].[PRODUCT_TYPE] where name like '";
	public final static String SQL_SELECT_DISPLAY_FARMER_ID = "select [DISPLAY_FARMER_ID] from [FARMER].[FARMER_REGISTRATION] where display_farmer_id like '%";
	public final static String SQL_SELECT_FARMER_ID = "select [FARMER_ID] from [FARMER].[FARMER_REGISTRATION] where display_farmer_id like '%";
	public final static String SQL_SELECT_DISPLAY_FARMERLEAD_ID = "select [DISPLAY_FARMER_ID] from [FARMER].[FARMER_REGISTRATION] freg  left outer join [FARMER].[FARMER_LEAD_REGISTRATION] flreg\r\n"
			+ "\r\n"
			+ "on freg.farmer_id = flreg.farmer_id left outer join farmer.farmer_farmerlead_map flmap on  flmap.farmer_lead_id = flreg.farmer_id \r\n"
			+ "\r\n" + "where freg.display_farmer_id like '%";

	/* Response Codes */
	public final static int RESPONSE_CODE_SUCCESS = 200;

	/* URLs */
	public final static String UAT_BASE_URL = "https://uat-apigateway.olamdirect.com/";
	public final static String SIT_BASE_URL = "https://manna-sit-apigateway.olamdirect.com/";
	public final static String PROD_BASE_URL = "https://app-apigateway.olamdirect.com/";
	public final static String URL_AUTHENTICATION = "authorization/login/v1";
	public final static String URL_STD_PRICE_PUBLISH_TIME = "master/standardPriceTimings/save";
	public final static String URL_COMMODITY_BASEPRICE = "pricing/basisPrice/save";
	public final static String URL_TRADPROD_BASEPRICE = "pricing/tradingProductBasisPrices/save";
	public final static String URL_PUBLISH_PRICE = "pricing/publishPrice";
	public final static String URL_FL_COMMODITY_MAPPING = "farmer/flOrgProductMap";
	public final static String URL_ACTIVE_TRAD_PROD = "master/logicReadyActiveTradingProducts?productId=";
	public final static String URL_VALUE_LIMITS = "master/originTpInputParameterValueLimits?tradingProductId=";
	public final static String URL_DEVICE_RESET = "authorization/resetDevice";
	public final static String URL_PROFILE_DETAILS = "farmer/getVerifyDetails?displayFarmerId=";
	public final static String URL_FARMER_PREMIUM_LEDGER = "ledger/getFarmerPremiumLedgerView";
	public final static String URL_FARMER_TXN_LEDGERDATAVIEW = "ledger/getfarmerTransactionLedgerDataView";
	public final static String URL_ORIGIN_BASIC_DETAILS = "master/originBasicDetails/save";
	public final static String URL_ORIGIN_CURRENCY_LIST = "master/originCurrencyList";
	public final static String URL_FARMER_LEDGER_SEARCH = "ledger/farmerLedgerSearch";
	public final static String URL_REGISTRATION_SETTINGS = "master/getOriginRegistrationSettings";
	public final static String URL_FL_INTENT_DETAILS = "mobile/getFLIntentDetails?farmerLeadId=";

	/* Others */
	public final static String ROLE_ID_FL = "2";
	public final static String ROLE_ID_FARMER = "1";
	public final static String PROPERTY_FILE_NAME = "Appium.properties";
	public final static String LANG_ISO_CODE = "en";

	/* Farmer Registration test data */
	public final static String FARMER_NAME = "sanity farmer";
	public final static String FARMER_DOB = "10-11-1999";
	public final static String SAMPLE_DATE = "15";
	public final static String NATIONAL_ID_EXPIRY = "10-01-2021";
	public final static String EMAIL_FARMER = "Autoemail22@g.com";
	

	/*-----------------------Database Connection Details--------------------------------*/
	public final static String UAT_DB_TYPE = "SQLServer";
	public final static String UAT_HOST_NAME_OR_IP_ADDRESS = "od-mdb-uat-2002.37e78b7e983e.database.windows.net";
	public final static String UAT_PORT_NUMBER = "";
	public final static String UAT_DB_NAME = "olamdirect-uat-manna";
	public final static String UAT_GLOBAL_DB_NAME = "olamdirect-globaluat-manna";
	public final static String UAT_DB_USER_NAME = "oduatmannadbuser";
	public final static String UAT_DB_PASSWORD = "kW-E%=QGW2&3uGgD";

	public final static String SIT_DB_TYPE = "SQLServer";
	public final static String SIT_HOST_NAME_OR_IP_ADDRESS = "odmssql.database.windows.net";
	public final static String SIT_PORT_NUMBER = "";
	public final static String SIT_GLOBAL_DB_NAME = "olamdirect-globalsit-db";
	public final static String SIT_DB_NAME = "olamdirect-sit-db";
	public final static String SIT_DB_USER_NAME = "odappuser";
	public final static String SIT_DB_PASSWORD = "qazWSXx987654MLPokn";

	public final static String PROD_DB_TYPE = "SQLServer";
	public final static String PROD_HOST_NAME_OR_IP_ADDRESS = "od-mdb-prd-1001.database.windows.net";
	public final static String PROD_PORT_NUMBER = "";
	public final static String PROD_DB_NAME = "olamdirect-prd-db";
	public final static String PROD_GLOBAL_DB_NAME = "olamdirect-globalprd-db";
	public final static String PROD_DB_USER_NAME = "odprddbuser";
	public final static String PROD_DB_PASSWORD = "edFDU<{W5.:xP4L\\";

}
