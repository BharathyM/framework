package com.olamnet.farmer.stepdefinition;

import com.olamnet.farmer.utilities.BaseStepAction;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class MyFarmerLeadStep extends BaseStepAction {

	@Given("^the user is on my farmerlead screen$")
	public void the_user_is_on_my_farmerlead_screen() throws Throwable {
		getHomeActionInstance().waitForHomeScreenloading();
		getActionItemsInstance().clickAction(getAndroidRepoInstance().imgHomeMenu);
		//getActionItemsInstance().scrollDownViewByXpath("//*[contains(@text,'My Farmer Leads')]");
		getActionItemsInstance().addLogWithScreenShot("My Farmer Leads in Menu");
		getActionItemsInstance().clickAction(getMyFarmerLeadRepoInstance().optioninMenu);
		getActionItemsInstance().addLogWithScreenShot("My Farmer Leads");
		getActionItemsInstance().verifyText(getMyFarmerLeadRepoInstance().TitleTxt.getText(), "My Farmer Leads");
		getHomeActionInstance().waitForHomeScreenloading();
	}

	@Then("^verify my farmerlead UI elements$") 
	public void verify_my_farmerlead_UI_elements() throws Throwable {
	    getMyFarmerLeadActionInstance().verifyMyFarmerLeadUIElements();
	}

	//@Then("^verify if farmer can call farmerlead$")
	//public void verify_if_farmer_can_call_farmerlead() throws Throwable {
	 //   getMyFarmerLeadActionInstance().callFarmerLead();
	//}

}
