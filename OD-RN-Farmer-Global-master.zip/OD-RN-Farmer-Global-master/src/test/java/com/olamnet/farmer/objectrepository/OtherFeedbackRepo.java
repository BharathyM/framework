package com.olamnet.farmer.objectrepository;

import com.olamnet.farmer.utilities.AppiumUtil;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class OtherFeedbackRepo extends AbstractRepository {
	public static OtherFeedbackRepo inst_OtherFeedbackRepo = null;

	public OtherFeedbackRepo(AndroidDriver driver) {
		super(driver);
	}

	public static OtherFeedbackRepo getInstance() {
		if (inst_OtherFeedbackRepo == null)
			inst_OtherFeedbackRepo = new OtherFeedbackRepo(AppiumUtil.driver);
		return inst_OtherFeedbackRepo;
	}
	
	@AndroidFindBy(xpath = "//*[@text='Share with Olam']")
	public AndroidElement shareWithOlamMenuOpt;
	
	@AndroidFindBy(xpath = "//*[@text='Share with OFI']")
	public AndroidElement titleTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Select Feedback Category']")
	public AndroidElement ddLblTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Select Feedback Category']/following-sibling::*/*/*/following-sibling::*")
	public AndroidElement categoryDD;
	
	@AndroidFindBy(xpath = "//*[@text='Description']")
	public AndroidElement descLblTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Description']/following-sibling::*/*")
	public AndroidElement descInput;	
	
	@AndroidFindBy(xpath = "//*[@text='SUBMIT']")
	public AndroidElement submitBtn;
	
	@AndroidFindBy(xpath = "//*[@text='Thank you for valuable feedback!']")
	public AndroidElement feedbackSubmitMsgTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Back to Home']")
	public AndroidElement backHomeBtn;
	
	@AndroidFindBy(xpath = "//*[@text='Share with OFI']/../following-sibling::*/*/*")
	public AndroidElement historyIcon;
	
	@AndroidFindBy(xpath = "//*[@text='History']")
	public AndroidElement historyTxtTitle;	

	@AndroidFindBy(xpath = "//*[@text='History']/../../../../following-sibling::*/*/*/*[1]/*/*/*[1]")
	public AndroidElement StatusinfirstcardinHistory;	

	@AndroidFindBy(xpath = "//*[@text='Share with OFI']/../following-sibling::*/*/*/*")
	public AndroidElement responseCountonHistoryicon;	
	
	@AndroidFindBy(xpath = "//*[@text='History']/../../../../following-sibling::*/*/*/*/*/*")
	public AndroidElement firstCardinHistory;	
	
	

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'txt_past_feedback')]")
	public AndroidElement txtPastFeedbackAndReponse;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'txtFeedbackCategory')]")
	public AndroidElement ddSelectFeedbackCategory;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'etDescription')]")
	public AndroidElement feedbackDescription;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'dottedBox')]")
	public AndroidElement imgAddPhoto;

	@AndroidFindBy(xpath = "//*[@text='Feedback Submitted Successfully']")
	public AndroidElement txtSuccessMessage;

	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'recycler_past_feedback')]/*[./*[./*[contains(@resource-id,'txtPastFeedbackCategory')]]])[1]")
	public AndroidElement pastFeedbackCard;

	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'recycler_past_feedback')]/*/*/*[contains(@resource-id,'txtPastFeedbackDate')])[1]")
	public AndroidElement datePastFeedbackCard;

	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'recycler_past_feedback')]/*/*/*[contains(@resource-id,'txtPastFeedbackCategory')])[1]")
	public AndroidElement categoryPastFeedbackCard;

	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'recycler_past_feedback')]/*/*/*[contains(@resource-id,'txtPastFeedbackView')])[1]")
	public AndroidElement lnkClickToView;

	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'recycler_past_feedback')]/*/*/*[contains(@resource-id,'txtPastFeebackRespose')])[1]")
	public AndroidElement txtResponsePastFeedbackCard;

	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'recycler_past_feedback')]/*/*/*[contains(@resource-id,'txtPastFeedbackStatus')])[1]")
	public AndroidElement txtResponseStatusPastFeedbackCard;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'feedback_status')]")
	public AndroidElement txtResponseStatusInsideFeedbackCard;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'feedback_date')]")
	public AndroidElement dateInsideFeedbackCard;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'feedback_response_category')]")
	public AndroidElement categoryInsideFeedbackCard;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'feedback_description')]")
	public AndroidElement descInsideFeedbackCard;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'feedback_image')]")
	public AndroidElement imgInsideFeedbackCard;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'camera_image')]")
	public AndroidElement imgCamera;
	
	@AndroidFindBy(xpath = "//*[@id='normal_center_button']")
	public AndroidElement photoClickbtn;

	@AndroidFindBy(xpath = "//*[@text='OK']")
	public AndroidElement phtoOkButton;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'menu_crop')]")
	public AndroidElement editPhotoTickMark;
	
		
}
