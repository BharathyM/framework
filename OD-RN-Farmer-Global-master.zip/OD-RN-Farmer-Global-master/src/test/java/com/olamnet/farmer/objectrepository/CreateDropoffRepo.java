package com.olamnet.farmer.objectrepository;

import com.olamnet.farmer.utilities.AppiumUtil;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class CreateDropoffRepo extends AbstractRepository {
	
	public static CreateDropoffRepo inst_CreateDropoffRepository = null;

	public CreateDropoffRepo(AndroidDriver driver) {
		super(driver); 	}

	public static CreateDropoffRepo getInstance() {
		if (inst_CreateDropoffRepository == null)
			inst_CreateDropoffRepository = new CreateDropoffRepo(AppiumUtil.driver);
		return inst_CreateDropoffRepository; 	}
	
	@AndroidFindBy(xpath = "//*[@text='Price Expiry Time: ']")
	public AndroidElement priceExpiryDetails;	
	
	@AndroidFindBy(xpath = "//*[@text='Price Expiry Time: ']/following-sibling::*")
	public AndroidElement priceExpiryDateTime;		
	
	@AndroidFindBy(xpath = "//*[@text='Price Expiry Time: ']/../following-sibling::*")
	public AndroidElement dropoffCompletionDateTimeTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Price Expired ']")
	public AndroidElement priceExpiredTxt;	
	
	@AndroidFindBy(xpath = "//*[@text='Drop-off']")
	public AndroidElement dropOffTab;
	
	@AndroidFindBy(xpath = "//*[@text='Olam Price' and ./parent::*[./parent::*[./parent::*[@contentDescription='Olam Price']]]]")
	public AndroidElement olamPriceTab;
	
	@AndroidFindBy(xpath = "//*[@text='Transaction Summary']")
	public AndroidElement transSummaryTab;
	
	@AndroidFindBy(xpath = "//*[@text='SELECT PURCHASE TYPE']")
	public AndroidElement purchaseTypeheadingTxt;	
	
	@AndroidFindBy(xpath = "//*[@text='SELECT PURCHASE TYPE']/following-sibling::*/*")
	public AndroidElement clsBtnPurchaseType;	

	@AndroidFindBy(xpath = "//*[@text='Spot Purchase']")
	public AndroidElement ddSelectedPurType;
	
	@AndroidFindBy(xpath = "//*[@text='Spot Purchase']/following-sibling::*")
	public AndroidElement purchaseTypeDD;
	
	@AndroidFindBy(xpath = "//*[@text='Olam Price' and (./preceding-sibling::* | ./following-sibling::*)[@class='android.view.ViewGroup']]/following-sibling::*/following-sibling::*/*/*/*/*")
	public AndroidElement priceTagArrow;
	
	@AndroidFindBy(xpath = "//*[@text='Schedule Drop-off']")
	public AndroidElement headingTxtDropoff;	
	
	@AndroidFindBy(xpath = "//*[@text='Enter weight']/preceding-sibling::*")
	public AndroidElement dropoffCompletionLabelTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Enter weight']/following-sibling::*/*")
	public AndroidElement weightInput;
	
	@AndroidFindBy(xpath = "//*[@text='Enter weight']/following-sibling::*/*/following-sibling::*")
	public AndroidElement weightUOM;

	@AndroidFindBy(xpath = "//*[@text='Proceed']")
	public AndroidElement proccedBtn;
	
	@AndroidFindBy(xpath = "//*[@text='Estimation']/following-sibling::*")
	public AndroidElement estimationTPWeightDetails;
	
	@AndroidFindBy(xpath = "//*[@text='Estimation']/following-sibling::*/following-sibling::*")
	public AndroidElement estimatedValue;
	
	@AndroidFindBy(xpath = "//*[@text='Half payment - Bank']")
	public AndroidElement labelTxtHalfPaymentType;
	
	@AndroidFindBy(xpath = "//*[@text='Half payment - Cash']/following-sibling::*/*")
	public AndroidElement radioBtnHalfPaymentType;
	
	@AndroidFindBy(xpath = "//*[@text='Total Payment - Cash']")
	public AndroidElement labelTxtCashType;
	
	@AndroidFindBy(xpath = "//*[@text='Total Payment - Cash']/following-sibling::*/*")
	public AndroidElement radioBtnCashType;
	
	@AndroidFindBy(xpath = "//*[@text='Total payment - Bank \n (in 24 hours)']")
	public AndroidElement labelTxtBankType;

	@AndroidFindBy(xpath = "//*[@text='Total payment - Bank \n (in 24 hours)']/following-sibling::*/*")
	public AndroidElement radioBtnBankType;
	
	@AndroidFindBy(xpath = "//*[@text='FINISH']")
	public AndroidElement finishBtn;
	
	@AndroidFindBy(xpath = "//*[@text='Drop off Confirmation']")
	public AndroidElement headinglblTxtInConfirmDropOff;
	
	@AndroidFindBy(xpath = "//*[@text='Drop-off  Confirmation!']")
	public AndroidElement confirmdropoffMessageheadigTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Summary of drop off']")
	public AndroidElement dropoffSummaryTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Drop-off  Confirmation!']/following-sibling::*/*[2]")
	public AndroidElement transactionIDTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Drop-off  Confirmation!']/following-sibling::*/*[4]")
	public AndroidElement transactionID;
	
	@AndroidFindBy(xpath = "//*[@text='Drop-off  Confirmation!']/following-sibling::*/*[5]")
	public AndroidElement createdOnTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Drop-off  Confirmation!']/following-sibling::*/*[7]")
	public AndroidElement createdOnDateTime;
	
	@AndroidFindBy(xpath = "//*[@text='Drop-off  Confirmation!']/following-sibling::*/*[8]")
	public AndroidElement descriptionTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Drop-off  Confirmation!']/following-sibling::*/*[10]")
	public AndroidElement descriptionDetails;
	
	@AndroidFindBy(xpath = "//*[@text='Estimated Value']/following-sibling::*")
	public AndroidElement estimiatedValue;
	
	@AndroidFindBy(xpath = "//*[@text='Cancel Drop off']")
	public AndroidElement cancelDropOffBtn;
	
	@AndroidFindBy(xpath = "//*[@text='OK']")
	public AndroidElement Okbtn;
	
	@AndroidFindBy(xpath = "//*[@text='Half payment']")
	public AndroidElement halfPaymentTxtInConfirmDropoffMessage;
	
	@AndroidFindBy(xpath = "//*[@text='to Bank Account (in 24 hours)\n\n+']")
	public AndroidElement halfBankPaymentTxtInConfirmDropoffMessage;	
	
	@AndroidFindBy(xpath = "//*[@text='in Cash']")
	public AndroidElement cashPaymentTxtinConfirmDropoffMessage;
	
	@AndroidFindBy(xpath = "//*[@text='Total payment - Bank\n(in 24 hours)']")
	public AndroidElement bankPaymentInConfirmDropoffMessage;	
	
	@AndroidFindBy(xpath = "//*[@text='Drop-off' and (./preceding-sibling::* | ./following-sibling::*)[@class='android.widget.ScrollView']]/following-sibling::*/*/*/*/*/following-sibling::*")
	public AndroidElement firstDropoffInList;	
	
	@AndroidFindBy(xpath = "//*[@text='Summary of drop off']/following-sibling::*[1]")
	public AndroidElement transacIDtxt;
	
	@AndroidFindBy(xpath = "//*[@text='Summary of drop off']/following-sibling::*[3]")
	public AndroidElement tranID;
	
	@AndroidFindBy(xpath = "//*[@text='Summary of drop off']/following-sibling::*[4]")
	public AndroidElement createdOnLblTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Summary of drop off']/following-sibling::*[6]")
	public AndroidElement createdDateTime;
	
	@AndroidFindBy(xpath = "//*[@text='Summary of drop off']/following-sibling::*[7]")
	public AndroidElement descriptLblTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Summary of drop off']/following-sibling::*[9]")
	public AndroidElement descDetails;
	
	@AndroidFindBy(xpath = "//*[@text='Drop off Confirmation']/../preceding-sibling::*/*")
	public AndroidElement backArrowBtn;	
	
	@AndroidFindBy(xpath = "//*[@text='Select reason']/../following-sibling::*/*")
	public AndroidElement cancelDropoffBtn;
	
	@AndroidFindBy(xpath = "//*[@text='Transaction ID : ']/following-sibling::*")
	public AndroidElement tranIDInCancelReasons;
	
	@AndroidFindBy(xpath = "//*[@text='Select reason']/following-sibling::*/*/*")
	public AndroidElement cancelReasons;
	
	@AndroidFindBy(xpath = "//*[@text='Transaction Cancelled']/../following-sibling::*/following-sibling::*[1]")
	public AndroidElement cancelPopupTranID;
	
	@AndroidFindBy(xpath = "//*[@text='Transaction Cancelled']/../following-sibling::*/following-sibling::*[2]")
	public AndroidElement cancelPopupTxtMsg;
		
	@AndroidFindBy(xpath = "//*[@text='Error']")
	public AndroidElement cancelPopupHeadText;		
	
	@AndroidFindBy(xpath = "//*[@text='Transaction has been cancelled by Farmer']")
	public AndroidElement errorCancelPoupTxtMsg;
	
	@AndroidFindBy(xpath = "//*[@text='Drop-off' and (./preceding-sibling::* | ./following-sibling::*)[@class='android.widget.ScrollView']]/following-sibling::*/*/*/*/*[3]")
	public AndroidElement firstDropoff;	
	
	@AndroidFindBy(xpath = "//*[@text='Transaction Summary' and (./preceding-sibling::* | ./following-sibling::*)[@class='android.widget.ScrollView']]")
	public AndroidElement tranSummaryLblTxt;		
	
	@AndroidFindBy(xpath = "//*[@text='No data available!']")
	public AndroidElement noData;		
	
	
	
	
	
	
	
	
}
