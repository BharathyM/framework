package com.olamnet.farmer.stepdefinition;
import com.olamnet.farmer.utilities.BaseStepAction;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class MyAccountStep extends BaseStepAction {

	@Given("^the user is on my account screen$")
	public void the_user_is_on_my_account_screen() throws Throwable {
		getMyAccountActionInstance().navigateToMyAccount();
	}
	@Then("^verify account details$")
	public void verify_account_details() throws Throwable {
		getMyAccountActionInstance().verifyMyAccountDetails();
}

	@Then("^edit personal details and verify status \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void edit_personal_details_and_verify_status(String gender,String fullName,String dob,String email) throws Throwable {
		getMyAccountActionInstance().editPersonalDetails(gender,fullName,dob,email);
	}
	
	 @Then("^edit address and verify status$")
		public void edit_address_and_verify_status() throws Throwable {
		getMyAccountActionInstance().editAddress();
		}

	@Then("^edit phone no and verify status \"([^\"]*)\" \"([^\"]*)\"$")
	public void edit_phone_no_and_verify_status(String phoneNum,String OTP) throws Throwable {
		getMyAccountActionInstance().editPhoneNo(phoneNum,OTP);
	}   

	//@Then("^edit bank account details and verify status$")
	//public void edit_bank_account_details_and_verify_status() throws Throwable {
		//getMyAccountActionInstance().editBankAccountDetails();
	//}

	//@Then("^upload other documents and verify status$")
	//public void upload_other_documents_and_verify_status() throws Throwable {
	//	getMyAccountActionInstance().verifyOtherDocuments();
	//}

	//@Then("^add signature and verify status$")
	//public void add_signature_and_verify_status() throws Throwable {
		//getMyAccountActionInstance().verifySignature();
//	}

}
