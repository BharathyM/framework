package com.olamnet.farmer.commonactions;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.Year;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Stream;

import org.json.JSONException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cucumber.listener.Reporter;
import com.olamnet.farmer.utilities.AppiumServerTest;
import com.olamnet.farmer.utilities.AppiumUtil;
import com.olamnet.farmer.utilities.BaseStepAction;
import com.olamnet.farmer.utilities.Constants;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.PointOption;


public class SignupActions extends BaseStepAction{
	
	AndroidDriver driver;
	public static SignupActions inst_SignupActions = null;
	//public static String farmerLoginId;
	public static String FULL_RESET_VALUE;
	public static String newFarmerId;
	AtomicBoolean alreadyExecuted = new AtomicBoolean(false);
	AtomicBoolean alreadyInstalled = new AtomicBoolean(false);
	private static Properties appiumProp = new Properties();
	private static Properties farmerProp = new Properties();
	WebElement ele;
	String flname;
	List<WebElement> myElements;

	public SignupActions(AndroidDriver driver) {
		this.driver = driver;
	}

	public static SignupActions getInstance() {
		if (inst_SignupActions == null)
			inst_SignupActions = new SignupActions(AppiumUtil.driver);
		return inst_SignupActions;
	}
	public void navigateToRegisterFarmerLink() {
		getActionItemsInstance().clickByVisibleText("Signup");
		
		}
	
	public void registerFarmer(String Commodity,String gender,String fullName,String phoneNum,String dob,String email,
			String proviance,String dist,String subDist, String city, String address,String FLId)
			throws InterruptedException, ParseException {
		
		//commodity selection
		getActionItemsInstance().clickAction(getSingupRepoInstance().commdDD);
		getActionItemsInstance().clickByVisibleText(Commodity);
		getActionItemsInstance().reportStepLog("Commodity selected: "+Commodity);
		
		addPersonalDetails(gender,fullName,phoneNum,dob,email);		
		addAddress(proviance,dist,subDist, city,address);
		selectFarmerLead(FLId);
		
		if(getActionItemsInstance().isDisplayedAction(getSingupRepoInstance().tcTxt))
		{
			getActionItemsInstance().reportStepLog("Terms&condiotins checkbox enabled and text displayed");
		}
		
		getActionItemsInstance().clickAction(getSingupRepoInstance().submit);
	
		//verifyFarmerDetails();
		getActionItemsInstance().waitAction(getSingupRepoInstance().successMsginPopup, 15);
		getActionItemsInstance().isDisplayedAction(getSingupRepoInstance().successMsginPopup);
		getActionItemsInstance().addLogWithScreenShot("FarmerRegisteration success popup");
		
		newFarmerId = getSingupRepoInstance().newFarmerID.getText();//.replaceAll("\\s", "").replace("-", "");
		//getActionItemsInstance().reportStepLog("Newly Registered Farmer ID : "+newFarmerId);
		getActionItemsInstance().clickAction(getSingupRepoInstance().popupOkbtn);
		getActionItemsInstance().
				reportStepLog("Farmer registration is successful and registered farmer id is: " + newFarmerId);
		getActionItemsInstance().addLogWithScreenShot("Farmer registeration success & switch to Login Screen");
	}

	public void addPersonalDetails(String gender,String fullName,String phoneNum,String dob, String email) throws InterruptedException, ParseException {
		getActionItemsInstance().clickAction(getSingupRepoInstance().profilePic);	
		getActionItemsInstance().uploadImage();
		getActionItemsInstance().clickAction(getSingupRepoInstance().genderSelect);
		getActionItemsInstance().clickByVisibleText(gender);
		getActionItemsInstance().reportStepLog("Gender selected: "+gender);	
		getActionItemsInstance().sendKeysAction(getSingupRepoInstance().fullNameInput,fullName);
		getActionItemsInstance().reportStepLog("FullName Entered: "+fullName);
		getActionItemsInstance().addLogWithScreenShot("Singup Screen-1");
		
getActionItemsInstance().scrollDownViewByXpath("//*[@text='Phone Number*']");
		//getActionItemsInstance().touchandScroll();
		//getActionItemsInstance().scrollUntilVisibleText("Date Of Birth*");
		//getActionItemsInstance().scroll(0,250,0,250);
		Thread.sleep(2000);
		getActionItemsInstance().sendKeysAction(getSingupRepoInstance().PhoneNumbInput,phoneNum);
		getActionItemsInstance().reportStepLog("PhoneNumber entered: "+phoneNum);
		//fillMobileNumber();		
		getActionItemsInstance().clickAction(getSingupRepoInstance().DOBInput);
		// TODO to be checked in all origins
		// selectDate(Constants.FARMER_DOB);
		//selectDate();
		selectCompleteDate(dob);
		getActionItemsInstance().reportStepLog("DOB selected: "+dob);
		getActionItemsInstance().sendKeysAction(getSingupRepoInstance().emailInput, email);
		getActionItemsInstance().reportStepLog("Email entered: "+email);//need to implement random email
		//getActionItemsInstance().scrollUntilVisibleText("Unique ID");
		//getActionItemsInstance().scrollUntilVisibleText("Email Address");
				getActionItemsInstance().sendKeysAction(getSingupRepoInstance().uniqueIDInput,
				String.valueOf(getActionItemsInstance().getRandomNumber(10)));
				getActionItemsInstance().reportStepLog("UniqueID entered: ");
		//getActionItemsInstance().scrollUntilVisibleText("copy");
		// if National ID Expiry date present
		//if (getActionItemsInstance().isDisplayedAction(getLoginRepoInstance().calendarNationalIdExpiry)) {
			//getActionItemsInstance().clickAction(getLoginRepoInstance().calendarNationalIdExpiry);
			// TODO to be checked in all origins
			// selectDate(Constants.NATIONAL_ID_EXPIRY);
			// selectDate();
			//selectCompleteDate(Constants.NATIONAL_ID_EXPIRY);
		//}
				getActionItemsInstance().addLogWithScreenShot("SignUp screen-2");
				getActionItemsInstance().scrollDownViewByXpath("//*[@text='Country*']");
		getActionItemsInstance().clickAction(getSingupRepoInstance().uniqueIDScanCopyPic);
		getActionItemsInstance().uploadImage();
				getActionItemsInstance().reportStepLog("Personal details are filled in successfully");
	}

	private void fillMobileNumber() {
		String startDigit = "";
		int randomDigitCount = 0;
		switch (AppiumUtil.country) {
		case "Cambodia":
			startDigit = "96";
			randomDigitCount = 7;
			break;

		case "Peru":
			startDigit = "9";
			randomDigitCount = 8;
			break;

		case "Colombia":
			startDigit = "31";
			randomDigitCount = 9;
			break;

		case "Guatemala":
			startDigit = "22";
			randomDigitCount = 6;
			break;

		case "Honduras":
			startDigit = "3";
			randomDigitCount = 7;
			break;

		case "Mozambique":
			startDigit = "800";
			randomDigitCount = 6;
			break;

		case "Indonesia":
			startDigit = "812";
			randomDigitCount = 7;
			break;

		case "Vietnam":
			startDigit = "81";
			randomDigitCount = 9;
			break;

		}

		getActionItemsInstance().reportStepLog("Country: " + AppiumUtil.country + " Starting digit: " + startDigit
				+ " Random digit count: " + randomDigitCount);

		String PhoneNumberSetting = getApiActions().getRegistrationSettings();
		if (PhoneNumberSetting.equals("WITHOUT_ZERO")) {
			getActionItemsInstance()
					.reportStepLog("Admin portal is configured with  without-zero option in phone number");
			getActionItemsInstance().sendKeysAction(getLoginRepoInstance().tbPhoneNo,
					startDigit.concat(String.valueOf(getActionItemsInstance().getRandomNumber(randomDigitCount))));
		} else if (PhoneNumberSetting.equals("WITH_ZERO")) {
			getActionItemsInstance().reportStepLog("Admin portal is configured with zero option in phone number");
			getActionItemsInstance().sendKeysAction(getLoginRepoInstance().tbPhoneNo, "0".concat(
					startDigit.concat(String.valueOf(getActionItemsInstance().getRandomNumber(randomDigitCount)))));
		} else {
			getActionItemsInstance()
					.reportStepLog("Admin portal is configured with remove zero option in phone number");
			getActionItemsInstance().sendKeysAction(getLoginRepoInstance().tbPhoneNo, "0".concat(
					startDigit.concat(String.valueOf(getActionItemsInstance().getRandomNumber(randomDigitCount)))));
		}
	}

	public void selectFarmerLead(String FLId) {
	
		getActionItemsInstance().clickAction(getSingupRepoInstance().flIdDD);
		//getActionItemsInstance().clickByVisibleText(FLId);		
		 myElements = driver.findElements(By.xpath("//*[@text='Farmer Lead ID']/../following-sibling::*/*/*/*/*"));
        System.out.println("Size of List: "+myElements.size());
        for(WebElement e : myElements) 
        {        
            if(e.getText().equals(FLId))
            {
            	e.click();          
            	 System.out.println("Size of List: "+e.getText());
            } 
            else
            {
            	getActionItemsInstance().reportStepLog("FL Not avialible in the list");
            	
            }
                  }
      flname=  getSingupRepoInstance().flName.getText();
      getActionItemsInstance().addLogWithScreenShot("Signup screen-3");
		getActionItemsInstance().reportStepLog("Selected FLID:  "+FLId+" FL Name :  "+flname);
		}

	public void addAddress(String proviance,String dist,String subDist,String city,String address) {
		
		
		getSingupRepoInstance().provinceDD.getText();
		getActionItemsInstance().clickAction(getSingupRepoInstance().provinceDD);
		getActionItemsInstance().clickByVisibleText(proviance);
		getActionItemsInstance().reportStepLog("Province selected: "+proviance);
		getActionItemsInstance().scrollDownViewByXpath("//*[@text='Sub District*']");
		getActionItemsInstance().clickAction(getSingupRepoInstance().distDD);
		getActionItemsInstance().clickByVisibleText(dist);
		getActionItemsInstance().reportStepLog("dist selected: "+dist);
		getActionItemsInstance().clickAction(getSingupRepoInstance().subDistDD);
		getActionItemsInstance().clickByVisibleText(subDist);
		getActionItemsInstance().reportStepLog("subdist selected: "+subDist);
	
		getActionItemsInstance().clickAction(getSingupRepoInstance().cityDD);
		getActionItemsInstance().clickByVisibleText(city);
		getActionItemsInstance().reportStepLog("city selected: "+city);	
		
		
		getActionItemsInstance().sendKeysAction(getSingupRepoInstance().addrInput, address);
		getActionItemsInstance().addLogWithScreenShot("Signup screen-5");
		getActionItemsInstance().scrollDownViewByXpath("//*[@text='Farmer Lead Name*']");
		getActionItemsInstance().sendKeysAction(getSingupRepoInstance().zipcodeInput, String.valueOf(getActionItemsInstance().getRandomNumber(5)));		
		
				getActionItemsInstance().reportStepLog("Address details are filled in successfully");
	}

	public void verifyFarmerDetails() {
		/* verify personal data & farmerlead details */
		Stream.of(getLoginRepoInstance().imgProfilePicture, getLoginRepoInstance().txtFullName,
				getLoginRepoInstance().txtMobileNo, getLoginRepoInstance().txtDob,
				getLoginRepoInstance().txtFarmerProgram, getLoginRepoInstance().txtUniqueId,
				getLoginRepoInstance().txtUniqueIdExpiryDate, getLoginRepoInstance().txtFarmerLeadName,
				getLoginRepoInstance().txtFarmerLeadId).forEach(ele -> getActionItemsInstance().isDisplayedAction(ele));
		getActionItemsInstance().reportStepLog("Personal data verified");
		/* verify address details */
		getActionItemsInstance().isDisplayedAction(getLoginRepoInstance().txtAddress);
		getActionItemsInstance().reportStepLog("Address is verified");
		/* accept license and policy */
		getActionItemsInstance().scrollUntilVisibleText("Privacy Policy");
		getActionItemsInstance().clickAction(getLoginRepoInstance().lnkLicense);
		getActionItemsInstance().isDisplayedAction(getLoginRepoInstance().titleEndUserLicense);
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNavigateUp);
		// getActionItemsInstance().clickAction(getLoginRepoInstance().lnkPrivacyPolicy);
		// getActionItemsInstance().isDisplayedAction(getLoginRepoInstance().titlePrivacyPolicy);
		// getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNavigateUp);
		getActionItemsInstance().clickAction(getLoginRepoInstance().chkLicense);
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnConfirm);
		getActionItemsInstance().reportStepLog("Policies are verified and accepted");
	}

	public void selectCompleteDate(String dateString) throws ParseException {

		LocalDate date = LocalDate.parse(dateString, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
		String formattedDate = DateTimeFormatter.ofPattern("d-MMMM-yyyy").format(date);
		getActionItemsInstance().reportStepLog("Given date is: " + dateString + " formatted date is: " + formattedDate);
		String targetDate = formattedDate.split("-")[0];
		String targetMonth = formattedDate.split("-")[1];
		String targetYear = formattedDate.split("-")[2];

		getActionItemsInstance().clickAction(getSingupRepoInstance().calyearlist);
		getActionItemsInstance().scrollAndClick(targetYear);
		
		//int currentMonth = getMonthNumber( 				getActionItemsInstance().getTextAction(getLoginRepoInstance().txtCurrentMonth));
		//int monthOffset = getMonthNumber(targetMonth) - currentMonth;
		//getActionItemsInstance().reportStepLog("Month offset: " + monthOffset);
		//if (monthOffset != 0) {
		//	WebElement directionEle = (monthOffset > 0) ? getSingupRepoInstance().calNextMonth
			//		: getSingupRepoInstance().calPrevMonth;
			//selectMonth(targetMonth, directionEle);
		//} else {
		//	getActionItemsInstance().reportStepLog("Target month is already selected in calendar");
		//}

		getActionItemsInstance().clickByVisibleText(targetDate);
		getActionItemsInstance().clickAction(getSingupRepoInstance().CalenderokBtn);
	
	}

	public void selectDate() {
		getActionItemsInstance().clickAction(getSingupRepoInstance().CalenderokBtn);
		getActionItemsInstance().clickByVisibleText(Constants.SAMPLE_DATE);
		//getActionItemsInstance().clickAction(getAndroidRepoInstance().btnFinish);
	}

	public int getMonthNumber(String month) throws ParseException {

		Date date = new SimpleDateFormat("MMM").parse(month);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int monthNumber = cal.get(Calendar.MONTH) + 1;
		return monthNumber;
	}

	public void selectMonth(String month, WebElement swipeDirection) {
		boolean found = false;

		while (found == false) {
			boolean isPresent = driver.findElementsByXPath("//*[@text='" + month + "']").size() > 0;
			if (isPresent == true) {
				found = true;
				getActionItemsInstance().clickAction(driver.findElementByXPath("//*[@text='" + month + "']"));
				getActionItemsInstance().reportStepLog(month + " Month is selected");
			} else
				getActionItemsInstance().clickAction(swipeDirection);
		}
	}


}
