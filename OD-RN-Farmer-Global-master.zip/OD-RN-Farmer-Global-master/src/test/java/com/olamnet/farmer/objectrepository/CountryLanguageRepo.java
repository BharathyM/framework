package com.olamnet.farmer.objectrepository;

import com.olamnet.farmer.utilities.AppiumUtil;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class CountryLanguageRepo extends AbstractRepository {

	public static CountryLanguageRepo inst_CountryLangRepo = null;

	public CountryLanguageRepo(AndroidDriver driver) {
		super(driver);
	}

	public static CountryLanguageRepo getInstance() {
		if (inst_CountryLangRepo == null)
			inst_CountryLangRepo = new CountryLanguageRepo(AppiumUtil.driver);
		return inst_CountryLangRepo;
	}

	@AndroidFindBy(xpath = "//*[@text='Select'][1]")
	public AndroidElement dd_countryLanguage;

	@AndroidFindBy(xpath = "//*[@text='India']")
	public AndroidElement countryDDIndia;
	
	
	@AndroidFindBy(xpath = "//*[@text='Choose your country']")
	public AndroidElement countrylableText;
	
	@AndroidFindBy(xpath = "//*[@text='Select your country']")
	public AndroidElement countryDD;
	
	@AndroidFindBy(xpath = "//*[@text='Choose your language']")
	public AndroidElement langDDlableText;
	
	@AndroidFindBy(xpath = "//*[@text='India']")
	public AndroidElement OriginSelectedDD;

	@AndroidFindBy(xpath = "//*[@text='English']")
	public AndroidElement langDD;
	
	@AndroidFindBy(xpath = "//*[@text='Choose your commodity']")
	public AndroidElement commodityddlableText;

	@AndroidFindBy(xpath = "//*[@class='android.view.ViewGroup' and ./*[@text='Select your commodity']]")
	public AndroidElement commodityDD;

	@AndroidFindBy(xpath = "//*[@text='Next']")
	public AndroidElement nextButton;

	

	
	
	
	

			//*[@class='android.view.ViewGroup' and ./*[@text='India']]
			 
			//*[@class='android.view.ViewGroup' and ./*[@text='Portuguese']]
			
			//*[@text='Coffee']
			
	//*[@text='Select your country']/following-sibling::*

}
