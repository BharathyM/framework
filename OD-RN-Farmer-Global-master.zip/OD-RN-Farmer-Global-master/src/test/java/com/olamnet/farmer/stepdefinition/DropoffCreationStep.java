package com.olamnet.farmer.stepdefinition;

import com.olamnet.farmer.utilities.BaseStepAction;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class DropoffCreationStep extends BaseStepAction{	
	@Given("^the user is on create dropoff screen$")
	public void the_user_is_on_create_dropoff_screen() throws Throwable {
	//getActionItemsInstance().clickAction(getAndroidRepoInstance().imgHomeMenu);
		//getActionItemsInstance().clickAction(getHomeRepoInstance().btnHome);
		//getHomeActionInstance().waitForHomeScreenloading();
	}
	
	@Then("^create a dropoff with following inputs \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void create_a_dropoff_with_following_inputs(String commodity,String purchaseType,String tradingProd,String weightQty,String paymentMode) throws Throwable {		
		getCreateDropoffAction().createDropoff(commodity, purchaseType, tradingProd, weightQty, paymentMode);	
	}
	
	@Then("^verify dropoff creation message \"([^\"]*)\" \"([^\"]*)\"$")
	public void verify_dropoff_creation_message(String paymentMode,String tranStatus) throws Throwable {
		getCreateDropoffAction().verifyDropoffCreationMsg(paymentMode,tranStatus);
	}
	
	@Then("^verify dropoff created with \"([^\"]*)\" \"([^\"]*)\" is present in dropoffs for today$")
	public void verify_dropoff_created_with_and_is_present_in_dropoffs_for_today(String paymentMode,String tranStatus) throws Throwable {
		getCreateDropoffAction().verifyCreatedDropOffsInTodaysDropoffsList(paymentMode,tranStatus);
	}
	
	@Then("^verify cancel dropoff in the confirm dropoff$")
	public void verify_cancel_dropoff_in_the_confirm_dropoff() throws Throwable {		
		getCreateDropoffAction().cancelDropOff();
	}
	
	@Then("Verify transaciton summary details with following inputs \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" ")
	public void verify_transaciton_summary_details_with_following_inputs() {
		getCreateDropoffAction().transctionSummary();
	}
	
}
