package com.olamnet.farmer.commonactions;

import org.openqa.selenium.WebElement;

import com.olamnet.farmer.utilities.AppiumUtil;
import com.olamnet.farmer.utilities.BaseStepAction;

import io.appium.java_client.android.AndroidDriver;

public class PromotionsAction extends BaseStepAction{
	AndroidDriver driver;
	public static PromotionsAction inst_PromotionsAction = null;	

	public PromotionsAction(AndroidDriver driver) {
		this.driver = driver;
	}

	public static PromotionsAction getInstance() {
		if (inst_PromotionsAction == null)
			inst_PromotionsAction = new PromotionsAction(AppiumUtil.driver);
		return inst_PromotionsAction;
	}
	
	public void verifyUIElemtnsinPromotions() {
		getActionItemsInstance().verifyText(getPromotionsRepoInstance().promotionListTitleTxt.getText(),"Promotion List");
		getActionItemsInstance().waitForProgressBar();	
		getActionItemsInstance().addLogWithScreenShot("Promotions List screen...");	
		getActionItemsInstance().reportStepLog("Promotion Status:: "+getPromotionsRepoInstance().enrollStatusTxt.getText());
		if(getActionItemsInstance().isDisplayedAction(getPromotionsRepoInstance().promotionImage)) 		{
			getActionItemsInstance().reportStepLog("Image is dispalyed"); 		}		
		getActionItemsInstance().reportStepLog("Promotion Title:: "+getPromotionsRepoInstance().promotionTitle.getText());		
		getActionItemsInstance().reportStepLog(getPromotionsRepoInstance().startDateLblTxt.getText()+":: "+getPromotionsRepoInstance().startDateValue.getText());
		getActionItemsInstance().reportStepLog(getPromotionsRepoInstance().endDateLabTxt.getText()+":: "+getPromotionsRepoInstance().endDateValue.getText());
		getActionItemsInstance().reportStepLog(getPromotionsRepoInstance().tranTypeLblTxt.getText()+":: "+getPromotionsRepoInstance().tranNumValue.getText());		
		getActionItemsInstance().reportStepLog(getPromotionsRepoInstance().joinedOnLblTxt.getText()+":: "+getPromotionsRepoInstance().joinedOnValue.getText());		
		getActionItemsInstance().reportStepLog(getPromotionsRepoInstance().tranOnLablTxt.getText()+":: "+getPromotionsRepoInstance().tranOnValue.getText());		
		getActionItemsInstance().reportStepLog(getPromotionsRepoInstance().tranNumLblTxt.getText()+":: "+getPromotionsRepoInstance().tranNumValue.getText());		
		getActionItemsInstance().reportStepLog(getPromotionsRepoInstance().userTypeLblTxt.getText()+":: "+getPromotionsRepoInstance().userTypeValue.getText());
		getActionItemsInstance().clickAction(getPromotionsRepoInstance().viewDetialLink);
		getActionItemsInstance().waitForProgressBar();	
		getActionItemsInstance().acceptError();
		//currently facing application error it is throwing internal sever error so need to implment few script
		//getActionItemsInstance().clickAction(getPromotionsRepoInstance().beginBtn);	
		getActionItemsInstance().clickAction(getPromotionsRepoInstance().backArrow);				
	}
}
