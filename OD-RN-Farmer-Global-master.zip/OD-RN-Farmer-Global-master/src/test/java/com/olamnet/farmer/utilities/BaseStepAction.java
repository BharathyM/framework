package com.olamnet.farmer.utilities;


import com.olamnet.farmer.commonactions.CountryLangAction;
import com.olamnet.farmer.commonactions.CreateDropoffAction;
import com.olamnet.farmer.commonactions.CropFeedbackAction;
import com.olamnet.farmer.commonactions.HomeAction;

import com.olamnet.farmer.commonactions.LoginAction;
import com.olamnet.farmer.commonactions.MyAccountAction;
import com.olamnet.farmer.commonactions.MyFarmerLeadAction;
import com.olamnet.farmer.commonactions.NewsInfoAction;
import com.olamnet.farmer.commonactions.OtherFeedbackAction;
import com.olamnet.farmer.commonactions.PromotionsAction;
import com.olamnet.farmer.commonactions.SignupActions;
import com.olamnet.farmer.commonactions.WeatherInformationAction;
import com.olamnet.farmer.objectrepository.AndroidRepo;
import com.olamnet.farmer.objectrepository.CountryLanguageRepo;
import com.olamnet.farmer.objectrepository.CreateDropoffRepo;
import com.olamnet.farmer.objectrepository.CropFeedbackRepo;
import com.olamnet.farmer.objectrepository.HomeRepo;
import com.olamnet.farmer.objectrepository.InformationOfTheDayRepo;
import com.olamnet.farmer.objectrepository.LoginRepo;
import com.olamnet.farmer.objectrepository.MyAccountRepo;
import com.olamnet.farmer.objectrepository.MyFarmerLeadRepo;
import com.olamnet.farmer.objectrepository.OtherFeedbackRepo;
import com.olamnet.farmer.objectrepository.PromotionsRepository;
import com.olamnet.farmer.objectrepository.SignupRepo;
import com.olamnet.farmer.objectrepository.WeatherInformationRepo;


public class BaseStepAction {

	// ------------objectRepository----------

	// Country Language Repo
	protected CountryLanguageRepo getCountryLangRepoInstance() {
		return CountryLanguageRepo.getInstance();
	}

	// LoginRepo
	protected LoginRepo getLoginRepoInstance() {
		return LoginRepo.getInstance();
	}

	// HomeRepo
	protected HomeRepo getHomeRepoInstance() {
		return HomeRepo.getInstance();
	}

	// MyAccountRepo
		protected MyAccountRepo getMyAccountRepoInstance() {
			return MyAccountRepo.getInstance();
		}

	// MyFarmerLeadRepo
	protected MyFarmerLeadRepo getMyFarmerLeadRepoInstance() {
		return MyFarmerLeadRepo.getInstance();
			}
   //SignupRepo
	protected SignupRepo getSingupRepoInstance() {
		return SignupRepo.getInstance();
			}
	
	// AndroidRepo repo
	protected AndroidRepo getAndroidRepoInstance() {
		return AndroidRepo.getInstance();
	}
	
	// WeatherInformationRepo
			protected WeatherInformationRepo getWeatherInformationRepoInstance1() {
				return WeatherInformationRepo.getInstance();
			}
			
			// News&Info repo
			protected InformationOfTheDayRepo getInformationOfTheDayRepoInstance() {
				return InformationOfTheDayRepo.getInstance();
			}

			// Survey repo
			protected CropFeedbackRepo getCropFeedbackRepoInstance() {
				return CropFeedbackRepo.getInstance();
			}

			// SharwithOlam repo
			protected OtherFeedbackRepo getOtherFeedbackRepoInstance() {
				return OtherFeedbackRepo.getInstance();
			}
			
			// Promotions repo
						protected PromotionsRepository getPromotionsRepoInstance() {
							return PromotionsRepository.getInstance();
						}

						//create Dropoff Repo
						protected CreateDropoffRepo getCreateDropoffRepo() {
							return CreateDropoffRepo.getInstance();
						}
	
	// --------------Utilities package---------------

	/*
	 * // AppiumServerTest protected AppiumServerTest
	 * get_AppiumServerTest_Instance() { return AppiumServerTest.getInstance(); }
	 */

	// ActionItems repo
	protected ActionItems getActionItemsInstance() {
		return ActionItems.getInstance();
	}

	// StartAppium
	protected StartAppium getBaseStartAppium() {
		return StartAppium.getInstance();
	}

	// DatabaseUtil
	protected DatabaseUtil getDatabaseUtil() {
		return DatabaseUtil.getInstance();
	}

	// Api Actions
	protected static ApiActions getApiActions() {
		return ApiActions.getInstance();
	}

	// --------------CommonAction Package-------------

	protected CountryLangAction getCountryLangActionInstance() {

		return CountryLangAction.getInstance();
	}

	protected LoginAction getLoginActionInstance() {
		return LoginAction.getInstance();
	}
	
	protected HomeAction getHomeActionInstance() {
		return HomeAction.getInstance();
	}
	protected MyAccountAction getMyAccountActionInstance() {
		return MyAccountAction.getInstance();
	}

	protected MyFarmerLeadAction getMyFarmerLeadActionInstance() {
		return MyFarmerLeadAction.getInstance();
	}

	protected SignupActions getSignupActionInstance() {
		return SignupActions.getInstance();
	}
	
	protected WeatherInformationAction getWeatherInformationActionInstance() {
		return WeatherInformationAction.getInstance();
	}
	
	protected NewsInfoAction getNewsInfoActionInstance()
	{
		return NewsInfoAction.getInstance();
	}
	

	protected OtherFeedbackAction getOtherFeedbackActionInstance() {
		return OtherFeedbackAction.getInstance();
	}

	protected CropFeedbackAction getCropFeedbackActionInstance() {
		return CropFeedbackAction.getInstance();
	}
	
	protected PromotionsAction getPromotionsActionInstance() {
		return PromotionsAction.getInstance();
	}
	
	protected CreateDropoffAction getCreateDropoffAction() {
		return CreateDropoffAction.getInstance();
	}

}
