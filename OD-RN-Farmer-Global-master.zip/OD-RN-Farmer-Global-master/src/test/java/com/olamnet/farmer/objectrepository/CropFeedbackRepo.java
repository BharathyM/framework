package com.olamnet.farmer.objectrepository;

import java.util.List;

import com.olamnet.farmer.utilities.AppiumUtil;
import com.olamnet.farmer.utilities.BaseStepAction;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class CropFeedbackRepo extends AbstractRepository {
	public static CropFeedbackRepo inst_CropFeedbackRepo = null;

	public CropFeedbackRepo(AndroidDriver driver) {
		super(driver);
	}

	public static CropFeedbackRepo getInstance() {
		if (inst_CropFeedbackRepo == null)
			inst_CropFeedbackRepo = new CropFeedbackRepo(AppiumUtil.driver);
		return inst_CropFeedbackRepo;
	}
	
	@AndroidFindBy(xpath = "//*[@text='Surveys']")
	public AndroidElement menuSurveyOpt;
	
	@AndroidFindBy(xpath = "//*[@text='Survey']")
	public AndroidElement titleTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Click on a survey to continue']")
	public AndroidElement labelTxtinSurveyList;	

	@AndroidFindBy(xpath = "//*[@text='Click on a survey to continue']/following-sibling::*/*/*")
	public List<AndroidElement> surveyListSize;	
	
	@AndroidFindBy(xpath = "//*[@text='Click on a survey to continue']/following-sibling::*/*/*[1]/*/*/*[2]")
	public AndroidElement surveryTitle;
	
	@AndroidFindBy(xpath = "//*[@text='Click on a survey to continue']/following-sibling::*/*/*[1]/*/*/*[3]")
	public AndroidElement paidSurveryRpTxtinList;
	
	@AndroidFindBy(xpath = "//*[@text='Click on a survey to continue']/following-sibling::*/*/*[1]/*/*/*[3]")
	public AndroidElement nonPaidSurveryNavigationlink;
	
	@AndroidFindBy(xpath = "//*[@text='Click on a survey to continue']/following-sibling::*/*/*[1]/*/*/*[4]")
	public AndroidElement paidSurveryNavigationLink;		

	@AndroidFindBy(xpath = "//*[@text='Sample Remarks']/following-sibling::*/*")
	public AndroidElement sampleRemarksInput;
	
	@AndroidFindBy(xpath = "//*[@text='*required fields']/../../*/*/*/following-sibling::*/*/*/*/*")
	public AndroidElement backArrow;
	
	@AndroidFindBy(xpath = "//*[@text='SUBMIT']")
	public AndroidElement submitBtn;
	
	@AndroidFindBy(xpath = "//*[@text='Take another survey']/../preceding-sibling::*[1]")
	public AndroidElement successMsgTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Take another survey']")
	public AndroidElement takeAnotherSurveryBtn;
	
	@AndroidFindBy(xpath = "//*[@text='Back to Home']")
	public AndroidElement backToHomeBtn;
	
	@AndroidFindBy(xpath = "//*[@text='*required fields']/preceding-sibling::*")
	public AndroidElement paidSurveylabelTxt;
	
	@AndroidFindBy(xpath = "//*[@text='EXIT']")
	public AndroidElement exitPopuHeadingTxt;
	
	@AndroidFindBy(xpath = "//*[@text='EXIT']/../following-sibling::*[2]")
	public AndroidElement exitPopupTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Continue']")
	public AndroidElement continueBtn;
	
	@AndroidFindBy(xpath = "//*[@text='Continue']/../following-sibling::*/*")
	public AndroidElement ExitBtn;
		  
	//*[@text='Click on a survey to continue']/following-sibling::*/*/*[1]/*/*/*[2] --- cardText and click action
	//*[@text='Click on a survey to continue']/following-sibling::*/*/*[1]/*/*/*[3] - Rp text
	
	//*[contains(text(), 'Q["+i+"]. ')]	
	
	
	
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'txtFeedbackTitle')]")
	public List<AndroidElement> lstCropFeedbackTitle;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'txtDate')]")
	public List<AndroidElement> lstCropFeedbackDate;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'txtListTitle')]")
	public AndroidElement feedbackTitleInCard;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'comments')]")
	public AndroidElement comments;

	@AndroidFindBy(xpath = "//*[@text='Feedback Submitted Successfully']")
	public AndroidElement txtFeedbackSuccessMsg;

	@AndroidFindBy(xpath = "//*[@text='*required fields']/following-sibling::*/*/*") 
	public List<AndroidElement> lstQuery;
	
	@AndroidFindBy(xpath = "//*[@text='Select']/../following-sibling::*/*/*/*/*")
	public AndroidElement selectDDOption;
	
	//*[@text='Sample Remarks']/following-sibling::*/*
	
	
}
