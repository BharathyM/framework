package com.olamnet.farmer.stepdefinition;

import java.sql.SQLException;

import com.cucumber.listener.Reporter;
import com.olamnet.farmer.utilities.AppiumUtil;
import com.olamnet.farmer.utilities.BaseStepAction;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hooks extends BaseStepAction {

	@Before({ "~@01CountryLangSelection", "~@03Login", "~@04Home","~@07Logout","~@02FarmerSignUp","~@08WeatherInfo","~@05MyAccount", "~@06MyFarmerLead","~@10Survey",
		"~@09NewsInfo","~@UpgradeTest","~@11SharewithOlam","~@12Promotions","~@20CreateDropOff"})
	public void before() {
		getActionItemsInstance().reLaunchCurrentApp();
		getHomeActionInstance().waitForHomeScreenloading();
	}

	@Before({ "@UpgradeTest" })
	public void upgradeTestSetup() {
		getActionItemsInstance().reInstallApp(AppiumUtil.BASE_PKG);
	}
	
	@Before({ "~@01CountryLangSelection","~@02FarmerSignUp","~@03Login","~@04Home","~@05MyAccount","~@06MyFarmerLead","~@08WeatherInfo","~@09NewsInfo","~@10Survey","~@11SharewithOlam","~@12Promotions","~@07Logout","~@20CreateDropOff" })
	public void setUpForProfileVerification() throws ClassNotFoundException, SQLException {
	//	getMyAccountActionInstance().getProfileDetailsFromWebService();
		Reporter.addScenarioLog("Profile details fetched");
	}
}
