package com.olamnet.farmer.stepdefinition;

import com.cucumber.listener.Reporter;
import com.olamnet.farmer.utilities.BaseStepAction;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStep extends BaseStepAction {

	@Given("^user navigates to login screen on farmer app$")
	public void user_navigates_to_login_screen_on_farmer_app() throws Throwable {
		getLoginActionInstance().verifyLoginScreen();
	}	

	@When("^user logs in with valid farmerId \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_logs_in_with_valid_farmerId(String loginType,String ODID,String OFISID,String MobileNum,String UniqueID,String OTP) throws Throwable {
		getLoginActionInstance().loginWithValidFarmerIdNew(loginType,ODID,OFISID,MobileNum,UniqueID,OTP);
	}

	@Then("^login should be successful$")
	public void login_should_be_successful() throws Throwable {
		//TODO license appears sometimes
		getLoginActionInstance().verifyLoginSuccessStatus();
		getActionItemsInstance().assertTitle(getHomeRepoInstance().imgOlamLogo);
	}
	
	

}
