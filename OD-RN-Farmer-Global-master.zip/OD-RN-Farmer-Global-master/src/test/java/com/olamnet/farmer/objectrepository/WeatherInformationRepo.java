package com.olamnet.farmer.objectrepository;

import java.util.List;

import com.olamnet.farmer.utilities.AppiumUtil;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class WeatherInformationRepo extends AbstractRepository {
	public static WeatherInformationRepo inst_WeatherInformationRepo = null;

	public WeatherInformationRepo(AndroidDriver driver) {
		super(driver);
	}

	public static WeatherInformationRepo getInstance() {
		if (inst_WeatherInformationRepo == null)
			inst_WeatherInformationRepo = new WeatherInformationRepo(AppiumUtil.driver);
		return inst_WeatherInformationRepo;
	}
	
	
	@AndroidFindBy(xpath = "//*[@class='android.view.View' and ./*[@text='Weather']]/*/following-sibling::*")
	public AndroidElement weatherBtmMenu;
	
	@AndroidFindBy(xpath = "//*[@text='Weather Information']")
	public AndroidElement titleTxt;
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ScrollView'][1]/*[@class='android.view.ViewGroup'][1]/*[1]")
	public AndroidElement dateTxt;
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ScrollView'][1]/*[@class='android.view.ViewGroup'][1]/*[2]")
	public AndroidElement imageCloudy;
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ScrollView'][1]/*[@class='android.view.ViewGroup'][1]/*[3]")
	public AndroidElement tempWeather;	
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ScrollView'][1]/*[@class='android.view.ViewGroup'][1]/*[4]")
	public AndroidElement cloudyStatus;	
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ScrollView'][1]/*[@class='android.view.ViewGroup'][1]/*[5]")
	public AndroidElement lastObservedtime;	
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ScrollView'][1]/*[@class='android.view.ViewGroup'][1]/*[6]")
	public AndroidElement humadityLabTxt;	
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ScrollView'][1]/*[@class='android.view.ViewGroup'][1]/*[7]")
	public AndroidElement lowLabTxt;	
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ScrollView'][1]/*[@class='android.view.ViewGroup'][1]/*[8]")
	public AndroidElement highLabTxt;	
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ScrollView'][1]/*[@class='android.view.ViewGroup'][1]/*[9]")
	public AndroidElement humadityValue;	
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ScrollView'][1]/*[@class='android.view.ViewGroup'][1]/*[10]")
	public AndroidElement lowValue;	
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ScrollView'][1]/*[@class='android.view.ViewGroup'][1]/*[11]")
	public AndroidElement highValue;	
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ScrollView'][1]/*[@class='android.view.ViewGroup'][1]/*[12]")
	public AndroidElement pressureLabTxt;	
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ScrollView'][1]/*[@class='android.view.ViewGroup'][1]/*[13]")
	public AndroidElement preceipitLabTxt;	
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ScrollView'][1]/*[@class='android.view.ViewGroup'][1]/*[14]")
	public AndroidElement windDireTxt;	
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ScrollView'][1]/*[@class='android.view.ViewGroup'][1]/*[15]")
	public AndroidElement pressureValue;	
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ScrollView'][1]/*[@class='android.view.ViewGroup'][1]/*[16]")
	public AndroidElement preciptationLabValue;	
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ScrollView'][1]/*[@class='android.view.ViewGroup'][1]/*[17]")
	public AndroidElement windDireValue;	
	 	
	@AndroidFindBy(xpath = "//*[@text='Hourly Forecast']")
	public AndroidElement hourlyForCast;
	
	@AndroidFindBy(xpath = "//*[@text='View full report']")
	public AndroidElement viewFullReportLink;

	@AndroidFindBy(xpath = "//*[@text='Detailed Report']")
	public AndroidElement detailedReportTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Hourly Forecast']")
	public AndroidElement hourlyFCTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Next 24 Hours']")
	public AndroidElement nextHrsTxt;	

	@AndroidFindBy(xpath = "//*[@text='Weekly Forecast']")
	public AndroidElement weeklyFCTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Next 24 Hours']/following-sibling::*/*/*")
	public AndroidElement hrFCTHorizScroll;
	
	
	@AndroidFindBy(xpath = "//*[contains(@resource-id,'edit_text_search')]")
	public AndroidElement tbSearch;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'search_control')]")
	public AndroidElement imgSearchIcon;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'txtWeatherDate')]")
	public AndroidElement txtCurrentDate;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'unit')]")
	public AndroidElement txtSearchLocation;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'today_weather')]")
	public AndroidElement txtTodaysWeather;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'imgWeather')]")
	public AndroidElement imgCloud;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'txtTemperature')]")
	public AndroidElement txtTemperature;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'txtDaySummary')]")
	public AndroidElement txtWeather;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'txtVeryOften')]")
	public AndroidElement txtRain;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'txtHumidityLabel')]")
	public AndroidElement txtHumidity;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'txtRain')]")
	public AndroidElement txtRainPercentage;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'txtHumidity')]")
	public AndroidElement txtHumidityPercentage;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'forecast_list')]/*[./*[./*[./*[contains(@resource-id,'weather_image')]]]]")
	public List<AndroidElement> lstWeeklyForecast;
}
