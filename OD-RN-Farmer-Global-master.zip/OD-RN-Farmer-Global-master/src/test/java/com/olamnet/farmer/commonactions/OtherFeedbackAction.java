package com.olamnet.farmer.commonactions;

import static org.testng.Assert.assertTrue;

import java.util.stream.Stream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.olamnet.farmer.utilities.AppiumUtil;
import com.olamnet.farmer.utilities.BaseStepAction;

import io.appium.java_client.android.AndroidDriver;

public class OtherFeedbackAction extends BaseStepAction {
	AndroidDriver driver;
	public static OtherFeedbackAction inst_OtherFeedbackAction = null;

	public OtherFeedbackAction(AndroidDriver driver) {
		this.driver = driver;
	}

	public static OtherFeedbackAction getInstance() {
		if (inst_OtherFeedbackAction == null)
			inst_OtherFeedbackAction = new OtherFeedbackAction(AppiumUtil.driver);
		return inst_OtherFeedbackAction;
	}

	public void submitFeedack(String feedbackCategory, String desc) {
		getActionItemsInstance().verifyText(getOtherFeedbackRepoInstance().titleTxt.getText(), "Share with OFI");
		getActionItemsInstance().clickAction(getOtherFeedbackRepoInstance().categoryDD);
		getActionItemsInstance().addLogWithScreenShot("Category Dropdown options screen...");
		getActionItemsInstance().clickByVisibleText(feedbackCategory);
		getActionItemsInstance().reportStepLog(getOtherFeedbackRepoInstance().ddLblTxt.getText()+" : "+feedbackCategory);
		getActionItemsInstance().sendKeysAction(getOtherFeedbackRepoInstance().descInput,desc);
		getActionItemsInstance().reportStepLog(getOtherFeedbackRepoInstance().descLblTxt.getText()+" : "+desc);
		//getActionItemsInstance().clickAction(getOtherFeedbackRepoInstance().imgAddPhoto);
		//uploadImage();
		getActionItemsInstance().addLogWithScreenShot("Feedback Description screen...");
		getActionItemsInstance().clickAction(getOtherFeedbackRepoInstance().submitBtn);
		// TODO success msg disappears before asserting
		/*
		 * assertTrue(getActionItemsInstance().isDisplayedAction(
		 * getOtherFeedbackRepoInstance().txtSuccessMessage),
		 * "Feedback not submitted successfully");
		 * getActionItemsInstance().clickAction(getAndroidRepoInstance().btnOk);
		 */
		getActionItemsInstance().reportStepLog("Feedback Submitted Message : "+getOtherFeedbackRepoInstance().feedbackSubmitMsgTxt.getText());
		getActionItemsInstance().addLogWithScreenShot("Feedback Submitted scree...");
		getActionItemsInstance().clickAction(getOtherFeedbackRepoInstance().backHomeBtn);		
		getActionItemsInstance().reportStepLog("Feedback submitted successfully");
	}
	
	public void verifyPendingFeedbackandResponse()
	{			
		if(getActionItemsInstance().isDisplayedAction(getOtherFeedbackRepoInstance().responseCountonHistoryicon)) {
		getActionItemsInstance().reportStepLog("AdminResponse latest count:  "+getOtherFeedbackRepoInstance().responseCountonHistoryicon.getText());
		}
		getActionItemsInstance().clickAction(getOtherFeedbackRepoInstance().historyIcon);	
		getActionItemsInstance().verifyText(getOtherFeedbackRepoInstance().historyTxtTitle.getText(), "History");	
		getActionItemsInstance().addLogWithScreenShot("Pending&AdminResponse Feeback list screen...");
		String status = getOtherFeedbackRepoInstance().StatusinfirstcardinHistory.getText();
		if(status.equalsIgnoreCase("Pending")) 		{	
			getActionItemsInstance().clickAction(getOtherFeedbackRepoInstance().firstCardinHistory);	
			getActionItemsInstance().addLogWithScreenShot("Pending Feedback History screen...::::");
			for(int j=1;j<=3;j++) {			          
		      getActionItemsInstance().reportStepLog(driver.findElement(By.xpath("//*[@text='History']/../../../../following-sibling::*/*["+j+"]")).getText());			
					}	}		
		else {	
			getActionItemsInstance().clickAction(getOtherFeedbackRepoInstance().firstCardinHistory);	
			getActionItemsInstance().addLogWithScreenShot("Feedback with Admin Response screen...::::");
			for(int j=1;j<=7;j++) {			
			   if(j==1||j==2||j==3||j==5||j==6||j==7) {
			getActionItemsInstance().reportStepLog(driver.findElement(By.xpath("//*[@text='History']/../../../../following-sibling::*/*["+j+"]")).getText());	
		}
	}
		}
		driver.navigate().back();
		driver.navigate().back();
		}
		
			
		

	/*private void verifyElementsInPastFeedbackCard(String feedbackCategory, String desc) {
		Stream.of(getOtherFeedbackRepoInstance().datePastFeedbackCard,
				getOtherFeedbackRepoInstance().txtResponsePastFeedbackCard,
				getOtherFeedbackRepoInstance().lnkClickToView, getAndroidRepoInstance().imgHelpline)
				.forEach(WebElement::isDisplayed);

		assertTrue(getOtherFeedbackRepoInstance().categoryPastFeedbackCard.getText().equals(feedbackCategory),
				"Feedback Category displayed is not the original category submitted");
		assertTrue(getOtherFeedbackRepoInstance().txtResponseStatusPastFeedbackCard.getText().equals("Pending"),
				"Status should be pending once submitted, but it is incorrect ");
		getActionItemsInstance().clickAction(getOtherFeedbackRepoInstance().lnkClickToView);

	//	getActionItemsInstance().verifyText(getAndroidRepoInstance().txtTitle.getText(), "PAST FEEDBACK AND RESPONSE");
		assertTrue(getOtherFeedbackRepoInstance().categoryInsideFeedbackCard.getText().equals(feedbackCategory),
				"Feedback Category displayed is not the original category submitted");
		assertTrue(getOtherFeedbackRepoInstance().descInsideFeedbackCard.getText().equals(desc),
				"Description displayed is not the original description submitted");
		assertTrue(getActionItemsInstance().isDisplayedAction(getOtherFeedbackRepoInstance().dateInsideFeedbackCard));
		assertTrue(getActionItemsInstance().isDisplayedAction(getOtherFeedbackRepoInstance().imgInsideFeedbackCard));
		assertTrue(
				getOtherFeedbackRepoInstance().txtResponseStatusInsideFeedbackCard.getText().equals("Response Pending"),
				"Response Status should be pending once submitted, but it is incorrect ");

	}*/

	/*private void uploadImage() {

		getActionItemsInstance().clickAction(getOtherFeedbackRepoInstance().imgCamera);
		getActionItemsInstance().keyEvent(27);
		getActionItemsInstance().keyEvent(24);
		try {
					getActionItemsInstance().clickAction(getLoginRepoInstance().btnShutterDone);
				
		} catch (Exception e) {
			e.printStackTrace();
		}
		getActionItemsInstance().clickAction(getOtherFeedbackRepoInstance().editPhotoTickMark);
		getActionItemsInstance().waitForProgressBar();
		getActionItemsInstance().reportStepLog("Image uploaded successfuly");
	}*/
}
