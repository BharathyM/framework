package com.olamnet.farmer.objectrepository;

import com.olamnet.farmer.utilities.AppiumUtil;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class PromotionsRepository extends AbstractRepository{
	
	public static PromotionsRepository inst_PromotionsRepository = null;

	public PromotionsRepository(AndroidDriver driver) {
		super(driver); 	}

	public static PromotionsRepository getInstance() {
		if (inst_PromotionsRepository == null)
			inst_PromotionsRepository = new PromotionsRepository(AppiumUtil.driver);
		return inst_PromotionsRepository; 	}	
	
	@AndroidFindBy(xpath = "//*[@text='Promotions']")
	public AndroidElement promotionsInMenu;
	
	@AndroidFindBy(xpath = "//*[@class='android.view.ViewGroup' and ./*[@text='Promotion List']]")
	public AndroidElement promotionListTitleTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Promotion List']/../../../../following-sibling::*/*/*[1]/*[1]/*")
	public AndroidElement enrollStatusTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Promotion List']/../../../../following-sibling::*/*/*[1]/*[2]")
	public AndroidElement promotionImage;
	
	@AndroidFindBy(xpath = "//*[@text='Promotion List']/../../../../following-sibling::*/*/*[1]/*[3]")
	public AndroidElement promotionTitle;
	
	@AndroidFindBy(xpath = "//*[@text='Promotion List']/../../../../following-sibling::*/*/*[1]/*[4]")
	public AndroidElement startDateLblTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Promotion List']/../../../../following-sibling::*/*/*[1]/*[5]")
	public AndroidElement endDateLabTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Promotion List']/../../../../following-sibling::*/*/*[1]/*[6]")
	public AndroidElement startDateValue;
	
	@AndroidFindBy(xpath = "//*[@text='Promotion List']/../../../../following-sibling::*/*/*[1]/*[7]")
	public AndroidElement endDateValue;
	
	@AndroidFindBy(xpath = "//*[@text='Promotion List']/../../../../following-sibling::*/*/*[1]/*[8]")
	public AndroidElement tranTypeLblTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Promotion List']/../../../../following-sibling::*/*/*[1]/*[9]")
	public AndroidElement joinedOnLblTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Promotion List']/../../../../following-sibling::*/*/*[1]/*[10]")
	public AndroidElement tranTypeValue;
	
	@AndroidFindBy(xpath = "//*[@text='Promotion List']/../../../../following-sibling::*/*/*[1]/*[11]")
	public AndroidElement joinedOnValue;
	
	@AndroidFindBy(xpath = "//*[@text='Promotion List']/../../../../following-sibling::*/*/*[1]/*[12]")
	public AndroidElement tranOnLablTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Promotion List']/../../../../following-sibling::*/*/*[1]/*[13]")
	public AndroidElement tranNumLblTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Promotion List']/../../../../following-sibling::*/*/*[1]/*[14]")
	public AndroidElement tranOnValue;
	
	@AndroidFindBy(xpath = "//*[@text='Promotion List']/../../../../following-sibling::*/*/*[1]/*[15]")
	public AndroidElement tranNumValue;
	
	@AndroidFindBy(xpath = "//*[@text='Promotion List']/../../../../following-sibling::*/*/*[1]/*[16]")
	public AndroidElement userTypeLblTxt;
	
	@AndroidFindBy(xpath = "//*[@text='Promotion List']/../../../../following-sibling::*/*/*[1]/*[18]")
	public AndroidElement userTypeValue;
	
	@AndroidFindBy(xpath = "//*[@text='Promotion List']/../../../../following-sibling::*/*/*[1]/*[20]/*")
	public AndroidElement viewDetialLink;
	
	@AndroidFindBy(xpath = "//*[@text='Begin']")
	public AndroidElement beginBtn;
	
	@AndroidFindBy(xpath = "//*[@text='Promotions']/../preceding-sibling::*/*/*")
	public AndroidElement backArrow;
	
	}
