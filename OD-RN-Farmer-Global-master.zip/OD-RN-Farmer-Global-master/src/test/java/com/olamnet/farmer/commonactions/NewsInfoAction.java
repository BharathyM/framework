package com.olamnet.farmer.commonactions;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.olamnet.farmer.utilities.AppiumUtil;
import com.olamnet.farmer.utilities.BaseStepAction;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class NewsInfoAction extends BaseStepAction{
	
	AndroidDriver driver;
	public static NewsInfoAction inst_NewsInfoAction = null;

	public NewsInfoAction(AndroidDriver driver) {
		this.driver = driver;
	}
	List<AndroidElement> listElement;
	WebElement ele;
	public static NewsInfoAction getInstance() {
		if (inst_NewsInfoAction == null)
			inst_NewsInfoAction = new NewsInfoAction(AppiumUtil.driver);
		return inst_NewsInfoAction;
	}
	
	public void verifyNewsInfoUI() throws InterruptedException
	{
		getActionItemsInstance().reportStepLog("Tab Heading text :: "+getInformationOfTheDayRepoInstance().otherTabTxt.getText());
		Thread.sleep(3000);
		getActionItemsInstance().addLogWithScreenShot("News&Info Screen..");
		getActionItemsInstance().clickAction(getInformationOfTheDayRepoInstance().firstCardinOtherTab);	
		getActionItemsInstance().waitForProgressBar();
		getActionItemsInstance().addLogWithScreenShot("News Details Screen..");
		//Inside card details...
		if(getActionItemsInstance().isDisplayedAction(getInformationOfTheDayRepoInstance().imageInNewsDetails)) {
							getActionItemsInstance().reportStepLog("News Banner images is displayed"); 				}
		getActionItemsInstance().reportStepLog("Heading Text in the NewsCard:: "+getInformationOfTheDayRepoInstance().headingTxtInNewsDetails.getText());
		getActionItemsInstance().reportStepLog("Date of News:: "+getInformationOfTheDayRepoInstance().dateInNewsDetails.getText());
		getActionItemsInstance().reportStepLog("Content of News: "+getInformationOfTheDayRepoInstance().contentInNewsDetails.getText());
		getActionItemsInstance().clickAction(getInformationOfTheDayRepoInstance().viewDetailslink);
		getActionItemsInstance().reportStepLog("View Details link clicked ");
		getActionItemsInstance().waitForProgressBar();
		getActionItemsInstance().addLogWithScreenShot("Web Page of Respective News...");
		driver.navigate().back();
		getActionItemsInstance().clickAction(getInformationOfTheDayRepoInstance().shareLinkInNewsDetails);
		getActionItemsInstance().reportStepLog("Share link clicked ");
		getActionItemsInstance().waitForProgressBar();
		getActionItemsInstance().addLogWithScreenShot("Share Link Screen..");
		driver.navigate().back();
		driver.navigate().back();	
		
		getActionItemsInstance().scrollDownViewByXpath("//*[@text='OFI News']/../preceding-sibling::*/../../following-sibling::*/*/*/*[6]");
		getActionItemsInstance().waitForProgressBar();
		getActionItemsInstance().addLogWithScreenShot("news list Screen..");
		ofiNewsTab();
	}
	
	public void ofiNewsTab()
	{
		getActionItemsInstance().clickAction(getInformationOfTheDayRepoInstance().ofiNewsTab);
		getActionItemsInstance().reportStepLog("Tab Heading text :: "+getInformationOfTheDayRepoInstance().ofiNewsTab.getText());
		getActionItemsInstance().addLogWithScreenShot("OFI Tab Screen..");		
		if(getActionItemsInstance().isDisplayedAction(getInformationOfTheDayRepoInstance().noDataAvil))
		{
			getActionItemsInstance().reportStepLog(getInformationOfTheDayRepoInstance().noDataAvil.getText());
		}
		else
		{
			//need to implement and complete now data is not avalible so commenting this part 
			//getActionItemsInstance().clickAction(getInformationOfTheDayRepoInstance().firstCardinOtherTab);
			
			getActionItemsInstance().reportStepLog("Implementation of this is In-Progress");
			
		}
		
	}
}
