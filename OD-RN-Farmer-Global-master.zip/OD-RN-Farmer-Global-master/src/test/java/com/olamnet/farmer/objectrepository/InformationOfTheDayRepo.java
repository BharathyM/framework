package com.olamnet.farmer.objectrepository;

import java.util.List;

import com.olamnet.farmer.utilities.AppiumUtil;
import com.olamnet.farmer.utilities.BaseStepAction;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class InformationOfTheDayRepo extends AbstractRepository {
	public static InformationOfTheDayRepo inst_IodRepo = null;

	public InformationOfTheDayRepo(AndroidDriver driver) {
		super(driver);
	}

	public static InformationOfTheDayRepo getInstance() {
		if (inst_IodRepo == null)
			inst_IodRepo = new InformationOfTheDayRepo(AppiumUtil.driver);
		return inst_IodRepo;
	}
	
	@AndroidFindBy(xpath = "//*[@text='News & Info' and @class='android.view.View']")
	public AndroidElement newsInfoTitleTxt;

	@AndroidFindBy(xpath = "//*[@text='News & Info' and @class='android.widget.TextView']")
	public AndroidElement newsInfoBottomOpt;
	
	@AndroidFindBy(xpath = "//*[@text='OFI News']")
	public AndroidElement ofiNewsTab;
	
	@AndroidFindBy(xpath = "//*[@text='OFI News']/../preceding-sibling::*/*")
	public AndroidElement otherTab;
	
	@AndroidFindBy(xpath = "//*[@text='OFI News']/../preceding-sibling::*/*")
	public AndroidElement otherTabTxt;	
	
	@AndroidFindBy(xpath = "//*[@text='OFI News']/../preceding-sibling::*/../../following-sibling::*/*/*/*/*")
	public AndroidElement firstCardinOtherTab;
	
	@AndroidFindBy(xpath = "//*[@text='No data available!']")
	public AndroidElement noDataAvil;
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ImageView' and ./parent::*[@class='android.view.ViewGroup']]")
	public AndroidElement imageInNewsDetails;
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ImageView' and ./parent::*[@class='android.view.ViewGroup']]/following-sibling::*")
	public AndroidElement headingTxtInNewsDetails;
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ImageView' and ./parent::*[@class='android.view.ViewGroup']]/following-sibling::*/following-sibling::*")
	public AndroidElement dateInNewsDetails;
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ImageView' and ./parent::*[@class='android.view.ViewGroup']]/following-sibling::*/*")
	public AndroidElement shareLinkInNewsDetails;
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ImageView' and ./parent::*[@class='android.view.ViewGroup']]/following-sibling::*[4]")
	public AndroidElement contentInNewsDetails;
	
	@AndroidFindBy(xpath = "//*[@class='android.widget.ImageView' and ./parent::*[@class='android.view.ViewGroup']]/following-sibling::*[5]/*")
	public AndroidElement viewDetailslink;
	
	@AndroidFindBy(xpath = "//*[@text='News & Info']/../preceding-sibling::*/*/*")
	public AndroidElement backArrowInNewsDetails;
	
	
	
	
	
	
	

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'txtDate')]")
	public AndroidElement currentDate;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'infoImg')]")
	public List<AndroidElement> iodCard;

}
