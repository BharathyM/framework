package com.olamnet.farmer.stepdefinition;

import static org.testng.Assert.assertTrue;

import java.util.stream.Stream;

import org.openqa.selenium.WebElement;

import com.olamnet.farmer.utilities.BaseStepAction;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class OtherFeedbackStep extends BaseStepAction {
	@Given("^the user is on other feedback screen$")
	public void the_user_is_on_other_feedback_screen() throws Throwable {
		getActionItemsInstance().clickAction(getAndroidRepoInstance().imgHomeMenu);	
		getActionItemsInstance().clickAction(getOtherFeedbackRepoInstance().shareWithOlamMenuOpt);
		getActionItemsInstance().waitForProgressBar();	
		getActionItemsInstance().addLogWithScreenShot("Share with Olam screen...");		
	}	

	@Then("^submit feedback for feedback category \"([^\"]*)\" with description \"([^\"]*)\"$")
	public void submit_feedback_for_feedback_category_with_description(String feedbackCategory, String desc)
			throws Throwable {
		getOtherFeedbackActionInstance().submitFeedack(feedbackCategory, desc);
	}	
	
	@Then("^verify pending feedback and admin response$")
	public void verify_pending_feedback_and_admin_response()
	{
		getOtherFeedbackActionInstance().verifyPendingFeedbackandResponse();
	
	}

}
