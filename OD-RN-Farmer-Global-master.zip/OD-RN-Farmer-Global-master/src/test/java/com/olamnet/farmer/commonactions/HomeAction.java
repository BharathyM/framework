package com.olamnet.farmer.commonactions;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.net.MalformedURLException;
import java.sql.SQLException;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Stream;

import org.json.JSONException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cucumber.listener.Reporter;
import com.olamnet.farmer.utilities.AppiumUtil;
import com.olamnet.farmer.utilities.BaseStepAction;
import com.olamnet.farmer.utilities.AppiumServerTest;

import io.appium.java_client.android.AndroidDriver;

public class HomeAction extends BaseStepAction {

	public static HomeAction inst_HomeAction = null;
	private AtomicBoolean appStartUp = new AtomicBoolean(false);
	private static Properties farmerProp = new Properties();
	WebElement wbInputParam;
	AndroidDriver driver;

	public HomeAction(AndroidDriver driver) {
		this.driver = driver;
	}

	public static HomeAction getInstance() {
		if (inst_HomeAction == null)
			inst_HomeAction = new HomeAction(AppiumUtil.driver);
		return inst_HomeAction;
	}

	public void navigateToHome() {

		if (appStartUp.compareAndSet(false, true)) {
			System.out.println("App is loading ...");
			waitForHomeScreenloading();
		}
		getActionItemsInstance().acceptErrorPopup();
		getActionItemsInstance().waitAction(getAndroidRepoInstance().imgHomeMenu,20);

		//navigate until Menu is found 
		while (!(getActionItemsInstance().getSizeOfElementById("toolbar_logo") > 0)) {
			driver.navigate().back();
		}
		//assertTrue(getActionItemsInstance().isDisplayedAction(getHomeRepoInstance().imgOlamLogo));
		Reporter.addScenarioLog("Navigated to home successfully");
	}

	public void waitForHomeScreenloading() {
		getActionItemsInstance().waitForProgressBar();
		getActionItemsInstance().sleepAction(5000);
		getActionItemsInstance().isDisplayedAction(getHomeRepoInstance().imgOlamLogo);

	}

	public void verifyHomeScreenElements() throws JSONException, ClassNotFoundException, SQLException, InterruptedException {
		
		postLoginHelpline();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		/* verify elements under each commodity 
		String displayFarmerLeadId = "";
		try {
			farmerProp.load(ClassLoader.getSystemResource("farmer.properties").openStream());
			displayFarmerLeadId = getDatabaseUtil().getDisplayFarmerLeadId(farmerProp.getProperty("farmerId"));
		} catch (Exception e) {
			e.printStackTrace();
		}

		List<String> commodities = getApiActions().getCommoditiesMappedToFL(displayFarmerLeadId);
		commodities.stream().forEach(getHomeActionInstance()::verifySubElementsForCommodity);*/

		//verify elements under menu 
		getActionItemsInstance().clickAction(getAndroidRepoInstance().imgHomeMenu);

		Stream.of(getHomeRepoInstance().profileImageinHamMenu, getHomeRepoInstance().profileIDinHamMenu,
				getHomeRepoInstance().proifileNameinHamMenu, getHomeRepoInstance().proifleQRcode)
				.forEach(getActionItemsInstance()::isDisplayedAction);

		Stream.of("Weather", "Crop Feedback").forEach(menuTxt -> {
					getActionItemsInstance().scrollDownViewByXpath("//*[contains(@text,'" + menuTxt + "')]");
					getActionItemsInstance().isDisplayedAction(menuTxt,
							driver.findElementByXPath("//*[@text='" + menuTxt + "']"));
				});
		verifyTermsAndConditions();			
		getActionItemsInstance().reportStepLog("Home screen elements are verified");
		
		
	}
	
	public void logout() {
		getActionItemsInstance().clickAction(getAndroidRepoInstance().imgHomeMenu);
		//getActionItemsInstance().scrollDownViewByXpath("//*[contains(@text,'LOGOUT')]");
		getActionItemsInstance().clickAction(getAndroidRepoInstance().logoutlink);
		getActionItemsInstance().addLogWithScreenShot("User is navigated to Home screen");
		getActionItemsInstance().verifyText(getAndroidRepoInstance().logoutPopup .getText(), "Are you sure you want to exit the application?");
			/*getActionItemsInstance().clickAction(getAndroidRepoInstance().logoutYes);
		getActionItemsInstance().reportStepLog("User is logged out successfully");*/
				getActionItemsInstance().clickAction(getAndroidRepoInstance().logoutNo);	
		getActionItemsInstance().reportStepLog("User closed the logout popup");
	}
	
	public void postLoginHelpline() throws InterruptedException {		
		getActionItemsInstance().addLogWithScreenShot("User is navigated to Home screen");
		//getActionItemsInstance().isDisplayedAction("OFI Logo", getLoginRepoInstance().ofiLogo);
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);
		getActionItemsInstance().isDisplayedAction("Helpline Image", getHomeRepoInstance().helplineBtninHome);		
		getActionItemsInstance().clickAction(getHomeRepoInstance().helplineBtninHome);			
		getActionItemsInstance().verifyText(getHomeRepoInstance().helplinepopupText.getText(),"Contact Olam's help center");	
		getActionItemsInstance().reportStepLog(getHomeRepoInstance().helplinepopupText.getText());		
		// Boolean Status = getActionItemsInstance().isDisplayedAction(getHomeRepoInstance().callBtnHelpline);			
		getActionItemsInstance().addLogWithScreenShot("Helpline Popup");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// if (Status == true) {
		getActionItemsInstance().clickAction(getHomeRepoInstance().clsButtonhelpline);
				// }
		getActionItemsInstance().reportStepLog("Helpline popup is verified");
		getActionItemsInstance().reportStepLog("UI elements verified");		
	}


	private void verifyTermsAndConditions() {
		getActionItemsInstance().clickAction(getAndroidRepoInstance().imgHomeMenu);
		getActionItemsInstance().clickAction(getHomeRepoInstance().txtTermsAndConditions);
		//getActionItemsInstance().verifyText(getAndroidRepoInstance().txtTitle.getText(), "Legal");
		
		//EULA
		getActionItemsInstance().clickAction(getHomeRepoInstance().txtPrivacyPolicy);
		getActionItemsInstance().addLogWithScreenShot("PrivacyPolicyScreen");
		getActionItemsInstance().clickAction(getHomeRepoInstance().EULAPPLastAcceptedDate);
		getActionItemsInstance().clickAction(getHomeRepoInstance().EULAPPVersion);		
		//getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNavigateback);
		driver.navigate().back();
		//PP		
		getActionItemsInstance().clickAction(getHomeRepoInstance().txtEndUserLicense);
		getActionItemsInstance().addLogWithScreenShot("End User License Agreement screen");
		getActionItemsInstance().clickAction(getHomeRepoInstance().EULAPPLastAcceptedDate);
		getActionItemsInstance().clickAction(getHomeRepoInstance().EULAPPVersion);
		//getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNavigateback);
		driver.navigate().back();
		
		getActionItemsInstance().reportStepLog("EULA and PP Verified in Legal section");
	}

	public void verifySubElementsForCommodity(String commodity) {
		try {
			getActionItemsInstance().scrollUntilVisibleText(commodity);
			WebElement wbEleCommodity = driver.findElementByXPath(
					"(//*[contains(@class,'RecyclerView')])[1]/descendant::*[@text='" + commodity + "']");
			getActionItemsInstance().isDisplayedAction(wbEleCommodity);
			getActionItemsInstance().clickAction(wbEleCommodity);
			Stream.of(getHomeRepoInstance().imgFarmerLead, getHomeRepoInstance().txtDropOffToday,
					getHomeRepoInstance().txtDropOffMsg, getHomeRepoInstance().tradingProductDropOffView)
					.forEach(getActionItemsInstance()::isDisplayedAction);
			getActionItemsInstance().scrollUntilVisibleText("Today's Price");
			getActionItemsInstance().isDisplayedAction(getHomeRepoInstance().tradingProductPriceView);
			getActionItemsInstance().reportStepLog("Sub elememts verified for commodity - " + commodity);
		} catch (Exception e) {
			getActionItemsInstance().reportStepLog("Sub elememts verification failed for commodity - " + commodity);
			e.printStackTrace();
		}

	}

	public void createDropoff(String commodity, String tradingProduct, String paymentMode) {
		getActionItemsInstance().scrollUpViewByXpath("//*[@text='" + commodity + "']");
		WebElement wbCommodity = driver.findElement(By.xpath("//*[@text='" + commodity + "']"));
		getActionItemsInstance().clickAction(wbCommodity);
		waitForHomeScreenloading();
		getActionItemsInstance().scrollDownViewByXpath("//*[*[@text='" + tradingProduct + "']]/following-sibling::*");
		WebElement wbPrice = driver
				.findElement(By.xpath("//*[*[@text='" + tradingProduct + "']]/following-sibling::*"));
		getActionItemsInstance().clickAction(wbPrice);
		getActionItemsInstance().verifyText(getAndroidRepoInstance().txtHeadTitle.getText(), "Schedule Drop-off");
		enterWeight();
		selectPayment(paymentMode);
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnFinish);
		getActionItemsInstance().reportStepLog(
				"Dropoff creation is successful for: " + commodity + " " + tradingProduct + " " + paymentMode);
	}

	public void verifyDropoffCreationMsg() {
		assertTrue(getActionItemsInstance().isDisplayedAction(getHomeRepoInstance().txtDropoffConfirmationMsg));
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnOk);
		getActionItemsInstance().reportStepLog("Dropoff creation success message is verified");
	}

	private void enterWeight() {
		getActionItemsInstance().sendKeysAction(getHomeRepoInstance().tbWeight, "5");
		getActionItemsInstance().clickAction(getAndroidRepoInstance().btnNext);
		getActionItemsInstance().reportStepLog("Entered weight");
	}

	public void selectPayment(String paymentMode) {

		switch (paymentMode) {
		case "Bank":
			getActionItemsInstance().clickAction(getHomeRepoInstance().rdBank);

			break;

		case "Half payment":
			getActionItemsInstance().clickAction(getHomeRepoInstance().rdBankCash);

			break;

		case "Cash":
			getActionItemsInstance().clickAction(getHomeRepoInstance().rdCash);

			break;

		default:
			getActionItemsInstance().reportStepLog("Incorrect payment mode: " + paymentMode);

			break;
		}
		getActionItemsInstance().reportStepLog("Selected payment mode with text : " + paymentMode);
	}

	public void verifyDropoffInDropoffsForToday(String commodity, String tradingProduct, String cancelAction) {
		if (!getActionItemsInstance().isDisplayedAction(driver.findElementByXPath("//*[@text='" + commodity + "']"))) {
			getActionItemsInstance().scrollUpViewByXpath("//*[@text='" + commodity + "']");
		}
		getActionItemsInstance().clickByVisibleText(commodity);
		waitForHomeScreenloading();

		getActionItemsInstance().clickAction(driver.findElementByXPath(
				"(//*[contains(@resource-id,'card_layout') and ./*[contains(@text,'" + tradingProduct + "')]])[1]"));
		getActionItemsInstance().verifyText(getAndroidRepoInstance().txtHeadTitle.getText(), "Summary of drop off");
		if (cancelAction.contains("yes")) {
			getActionItemsInstance().clickAction(getHomeRepoInstance().txtCancel);
			getActionItemsInstance().verifyText(getAndroidRepoInstance().txtHeadTitle.getText(), "Cancel Drop off");
			getActionItemsInstance().isDisplayedAction("Transaction ID ", getHomeRepoInstance().txtTxnId);
			getActionItemsInstance().clickAction(getHomeRepoInstance().txtCancelReason);
			getActionItemsInstance().clickAction(getHomeRepoInstance().txtCancelDropoff);
			getActionItemsInstance().isDisplayedAction(getHomeRepoInstance().txtCancelled);
			getActionItemsInstance().clickAction(getAndroidRepoInstance().btnOk);
			waitForHomeScreenloading();
			assertTrue(getActionItemsInstance().isDisplayedAction(getHomeRepoInstance().imgOlamLogo),
					"Transaction is not cancelled completely");
			getActionItemsInstance().reportStepLog("Transaction cancelled successfully");
		} else if (cancelAction.contains("no")) {
			getActionItemsInstance().clickAction(getAndroidRepoInstance().btnOk);
			waitForHomeScreenloading();
			assertTrue(getActionItemsInstance().isDisplayedAction(getHomeRepoInstance().imgOlamLogo),
					"Transaction isn't completed successfully");
			getActionItemsInstance().reportStepLog("Transaction completed successfully");
		}

		else {
			getActionItemsInstance().reportStepLog("Invalid input for complete action: " + cancelAction);
		}

	}

	public void verifyIfDropoffPresentInFLApp() {
		// TODO check if txn id captured in dropoff is present in FL app via api
	}

	public void completeTransaction(String commodity, String tradingProduct, String completeAction) {
		if (!getActionItemsInstance().isDisplayedAction(driver.findElementByXPath("//*[@text='" + commodity + "']"))) {
			getActionItemsInstance().scrollUpViewByXpath("//*[@text='" + commodity + "']");
		}
		getActionItemsInstance().clickByVisibleText(commodity);
		waitForHomeScreenloading();

		getActionItemsInstance().clickAction(driver.findElementByXPath(
				"(//*[contains(@resource-id,'card_layout') and ./*[contains(@text,'" + tradingProduct + "')]])[1]"));
		getActionItemsInstance().verifyText(getAndroidRepoInstance().txtHeadTitle.getText(), "Summary of drop off");
		if ("Cancel".equals(completeAction)) {
			getActionItemsInstance().clickAction(getHomeRepoInstance().txtCancel);
			getActionItemsInstance().verifyText(getAndroidRepoInstance().txtHeadTitle.getText(), "Cancel Drop off");
			getActionItemsInstance().isDisplayedAction("Transaction ID ", getHomeRepoInstance().txtTxnId);
			getActionItemsInstance().clickAction(getHomeRepoInstance().txtCancelReason);
			getActionItemsInstance().clickAction(getHomeRepoInstance().txtCancelDropoff);
			getActionItemsInstance().isDisplayedAction(getHomeRepoInstance().txtCancelled);
			getActionItemsInstance().clickAction(getAndroidRepoInstance().btnOk);
			waitForHomeScreenloading();
			assertTrue(getActionItemsInstance().isDisplayedAction(getHomeRepoInstance().imgOlamLogo),
					"Transaction is not cancelled completely");
			getActionItemsInstance().reportStepLog("Transaction cancelled successfully");
		} else if ("Accept".equals(completeAction)) {
			getActionItemsInstance().clickAction(getAndroidRepoInstance().btnOk);
			waitForHomeScreenloading();
			assertTrue(getActionItemsInstance().isDisplayedAction(getHomeRepoInstance().imgOlamLogo),
					"Transaction isn't completed successfully");
			getActionItemsInstance().reportStepLog("Transaction completed successfully");
		}

		else {
			getActionItemsInstance().reportStepLog("Invalid input for complete action: " + completeAction);
		}

	}

	public void verifyExit() throws MalformedURLException {
		getActionItemsInstance().clickAction(getAndroidRepoInstance().imgHomeMenu);
		getActionItemsInstance().clickAction(getHomeRepoInstance().btnExit);
		assertFalse(getActionItemsInstance().isDisplayedAction(getHomeRepoInstance().btnExit));
		getActionItemsInstance().launchCurrentApp();
		getActionItemsInstance().reportStepLog("App is exited and re-lauched");
	}

}
