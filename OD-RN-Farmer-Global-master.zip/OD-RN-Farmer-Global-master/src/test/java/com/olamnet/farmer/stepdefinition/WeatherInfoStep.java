package com.olamnet.farmer.stepdefinition;

import com.olamnet.farmer.utilities.BaseStepAction;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class WeatherInfoStep extends BaseStepAction{
	
	@Given("^the user is on weather information screen$")
	public void the_user_is_on_weather_information_screen() throws Throwable {	
		getActionItemsInstance().clickAction(getAndroidRepoInstance().imgHomeMenu);		
		getActionItemsInstance().clickAction(getHomeRepoInstance().btnHome);
		getActionItemsInstance().waitForProgressBar();		
		getActionItemsInstance().clickAction(getWeatherInformationRepoInstance1().weatherBtmMenu);
		getActionItemsInstance().waitForProgressBar();
		getActionItemsInstance().verifyText(getWeatherInformationRepoInstance1().titleTxt.getText(), "Weather Information");
	}

	@Then("^verify the UI elements$")
	public void verify_the_UI_elements() throws Throwable {		
		getWeatherInformationActionInstance().verifyWeatherInfoUIElements();
	}
}
