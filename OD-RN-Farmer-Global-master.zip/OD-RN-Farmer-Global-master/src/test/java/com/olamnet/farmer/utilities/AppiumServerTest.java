package com.olamnet.farmer.utilities;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.cucumber.listener.ExtentProperties;
import com.cucumber.listener.Reporter;
import com.olamnet.farmer.utilities.AppiumUtil;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import io.appium.java_client.android.AndroidDriver;

@CucumberOptions(features = { "src/test/resources/features/" }, glue = {
		"com.olamnet.farmer.stepdefinition" }, plugin = { "pretty:src\\Reports\\PrettyReport\\STDOUT",
				"html:src\\Reports\\PrettyReport\\install", "json:src\\Reports\\JSONReport\\cucumber.json",
				"com.cucumber.listener.ExtentCucumberFormatter:" }, tags = { "@01CountryLangSelection,@03Login,@04Home",
						"@uat", "@indo" })

//@01CountryLangSelection,@02Login,@03Home,@04LedgersAndPremium,@05LoansAndSchemes,@06MyFarmerLead,@07PriceCalculator,@08WeatherInfo,@09Iod,@10CropFeedback,@11OtherFeedback,@07Logout,@04FarmerSignUp,@14MyAccount

public class AppiumServerTest extends AbstractTestNGCucumberTests {

	public static String testEnv;
	public static String country;
	public AndroidDriver driver;

	@BeforeSuite
	public void startAppium() throws IOException, InterruptedException {

		/* Kill the existing node.exe service & start Appium server */
		Runtime.getRuntime().exec("taskkill /f /im node.exe ");
		Runtime.getRuntime().exec("taskkill /f /im adb.exe ");
		ActionItems.getInstance().sleepAction(3000);
		AppiumUtil.loadRunConfigProperties("config.properties");
		AppiumUtil.loadAppiumConfigProp("Appium.properties");
		System.out.println("Launching Appium Server");
		StartAppium.startAppium();
		AppiumUtil.setEnvironmentOriginSettings();
	}

	@BeforeTest
	public void initializeDriver() throws InterruptedException, IOException {

		System.out.println("Launched Appium properties");
		AppiumUtil.setCapabilities();
		driver = AppiumUtil.getDriver();
		System.out.println("Launch driver before test");

	}

	@BeforeClass
	public void initializeReport() {
		ExtentProperties extentProperties = ExtentProperties.INSTANCE;
		extentProperties.setProjectName("Project name: " + AppiumUtil.projectName + " Env: " + AppiumUtil.testEnv
				+ " Origin: " + AppiumUtil.country);
		extentProperties.setReportPath("src/Reports/ExtentReports/Report.html");
		System.out.println("Initialized reports");
	}

	@AfterClass
	public void afterClass() {
		Reporter.loadXMLConfig(new File("src/test/resources/extent-config.xml"));
		System.out.println("Report being generated");
		Reporter.setSystemInfo("User Name", System.getProperty("user.name"));
		Reporter.setSystemInfo("Time Zone", System.getProperty("user.timezone"));
		Reporter.setSystemInfo("64 Bit", "Windows 10");
		Reporter.setSystemInfo("2.53.0", "Selenium");
		Reporter.setSystemInfo("3.3.9", "Maven");
		Reporter.setSystemInfo("1.8.0_66", "Java Version");
		Reporter.setTestRunnerOutput("Cucumber TestNG Test Runner");
		System.out.println("Launch driver after class");
		System.out.println("Report generation completed");
		System.out.print("Stop service");
	}

	@AfterSuite
	public void reportSetup() {
		System.out.print("Stop service");
		StartAppium.stopAppium();
		ActionItems.getInstance().sleepAction(3000);
		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
		new File(System.getProperty("user.dir") + "/src/Reports/ExtentReports/Report.html");
		new File(System.getProperty("user.dir") + "/src/Reports/ExtentReports/" + timeStamp + ".html");
	}
	
}
