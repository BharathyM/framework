package com.olamnet.farmer.commonactions;

import static org.testng.Assert.assertFalse;

import java.util.List;
import java.util.stream.Stream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cucumber.listener.Reporter;
import com.olamnet.farmer.utilities.AppiumUtil;
import com.olamnet.farmer.utilities.BaseStepAction;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class MyFarmerLeadAction extends BaseStepAction {
	AndroidDriver driver;
	public static MyFarmerLeadAction inst_MyFarmerLeadAction = null;

	public MyFarmerLeadAction(AndroidDriver driver) {
		this.driver = driver;
	}
	List<AndroidElement> listElement;
	WebElement ele;
	public static MyFarmerLeadAction getInstance() {
		if (inst_MyFarmerLeadAction == null)
			inst_MyFarmerLeadAction = new MyFarmerLeadAction(AppiumUtil.driver);
		return inst_MyFarmerLeadAction;
	}
	
	//to get the total number of FLs 
	public void getNoOfFLs()
	{
		listElement = getMyFarmerLeadRepoInstance().NoOfFLCards;
		getActionItemsInstance().scrollDownViewByXpath("//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*");
		System.out.println("My Farmer Leads :: "+ listElement.size());
		getActionItemsInstance().reportStepLog("Total Number of FLs mapped to this Farmer : "+listElement.size());
	}

	//to get the first 3 cards data and UI Elements verify 
	public void verifyMyFarmerLeadUIElements() throws InterruptedException {			
				
		getActionItemsInstance().addLogWithScreenShot("My Farmer Leads");
		String elementsText="";		
		for(int i=1;i<=3;i++) {							
				for(int j=1;j<=10;j++) {
					
					if(j==2 || j==3 || j==6) {			
				elementsText = driver.findElement(By.xpath("//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*["+i+"]/*/*["+j+"]")).getText();
					                                 }					
					if(j==4) {
						 driver.findElement(By.xpath("//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*["+i+"]/*/*["+j+"]")).click();
						 if(getActionItemsInstance().isDisplayedAction(getMyFarmerLeadRepoInstance().whatsappErrorPopupHText))
						 {
							 getActionItemsInstance().getTextAction(getMyFarmerLeadRepoInstance().whatsAppPopupMsg);
							 getActionItemsInstance().addLogWithScreenShot("WhatsApp popup displayed");
							 getActionItemsInstance().clickAction(getMyFarmerLeadRepoInstance().whatsAppOkbtn);
							 getActionItemsInstance().reportStepLog("WhatsApp icon clicked and closed ");
						 }						 
					         }
					if(j==5)
					{
						 driver.findElement(By.xpath("//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*["+i+"]/*/*["+j+"]")).click();
						 if(getActionItemsInstance().isDisplayedAction(getMyFarmerLeadRepoInstance().callPopupTxt))
						 {
							 getActionItemsInstance().getTextAction(getMyFarmerLeadRepoInstance().callPopupMsgText);
							 getActionItemsInstance().addLogWithScreenShot("FL Helpline popup displayed");
							 getActionItemsInstance().clickAction(getMyFarmerLeadRepoInstance().clsBtnCallPopup);
							 getActionItemsInstance().reportStepLog("Helpline icon clicked and closed ");
						 }
					}
					
					if(j==7 || j==8 || j==9 || j==10)	
						
					{						
						if(driver.findElement(By.xpath("//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*["+i+"]/*/*["+j+"]/following-sibling::*")).isDisplayed())
						{
							elementsText=driver.findElement(By.xpath("//*[@text='My Farmer Leads']/../../../../following-sibling::*/*/*/*/*/*/*/*/*/*/*/*["+i+"]/*/*["+j+"]/following-sibling::*")).getText();
						}
						break;
					}				
				getActionItemsInstance().reportStepLog("FL-"+i+" : "+elementsText);
					}
				}	
		
		
			}			 
		}		







